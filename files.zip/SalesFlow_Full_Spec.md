# SalesFlow — Complete Build Specification

> **Purpose of this document.** This is a feature-by-feature, rule-by-rule description of the **SalesFlow** project (a sales-team CRM / "Unified Sales Management Platform"). It is written so that an AI (or a developer) who has **only this document** can rebuild the same application: same data model, same business rules, same screens, same texts, same colours, same behaviours — including small quirks.
>
> **How to read it.** Sections 1–3 give the foundation (stack, folders, architecture). Section 4 is the data model. Section 5 is every business rule. Section 6 describes the store (persistence, reducers, scheduler, seed data). Sections 7–9 describe the UI (app shell, shared components, every page). Section 10 is the design system, section 11 the permission matrix, section 12 end-to-end flows to test, section 13 quirks that **must be preserved**, and section 14 a build order + acceptance checklist.
>
> **Companion file.** `SalesFlow_Source_Appendix.md` contains the verbatim source of every file. If both are given to the AI, the appendix is the ground truth for exact strings/classes and this document is the explanation. If only this document is given, everything needed is here, but class names and wording should be copied exactly as written.
>
> **Language note.** The application UI is entirely **English** (left-to-right). The original project's own docs were written in Egyptian Arabic; this spec is in English because identifiers, UI strings and code are English.

---

## 1. What the product is

SalesFlow is a **front-end-only** CRM prototype for an outbound sales / call-centre operation.

* There is **no backend and no real database**. The entire application data lives in **one Redux object (`AppState`)**, which is saved to **`localStorage`** under the key **`sales-mgmt-state-v4`**.
* There is **no real authentication**: the login screen lets you *pick a user from a list* (a password box exists but is visual only).
* Business model: **leads** are created by an **Admin** into a shared **pool**. **Agents** take leads from the pool; each lead then walks through a campaign **workflow** of **touch points** (alternating phone calls and emails, with day offsets). Agents log call results (NVM / LVM / Discovery), the system sends email steps automatically, meetings can be scheduled, a **Quality** user records **sales**, and **Team Leaders / Operation Managers** supervise through dashboards, analytics, tasks, announcements and team management.
* Timed rules (reminders, 15-day expiry, auto-emails, meeting-day end) run in the browser every 30 seconds while someone is signed in.

### 1.1 Five roles

| Role value | Label on screen | Short | What they do |
|---|---|---|---|
| `admin` | Admin | — | Creates / deletes leads in the shared pool. Only sees Lead Pool + Teams. |
| `operation_manager` | Operation Manager | OM | Manages several teams; dashboards, analytics, calendar, sales, updates, tasks, email, can move agents between teams, can reassign leads. |
| `team_leader` | Team Leader | TL | Leads one team; dashboards, analytics, sales, updates, tasks, email, can reassign leads of own agents. |
| `agent` | Agent | — | Works leads: Work Queue, Leads, Calendar, Email, Dashboard, Analytics, Sales, Updates, Tasks. |
| `quality` | Quality | — | Only records / deletes **sales**; sees Sales + Teams. |

### 1.2 Pages (11)

`adminleads` (label **Lead Pool**), `dashboard`, `analytics`, `teams`, `workqueue` (**Work Queue**), `calendar`, `leads` (**Leads**), `sales`, `updates` (**Team Updates**), `tasks`, `emails` (**Email Center**). Details in §8–§10.

---

## 2. Tech stack and scaffolding

The uploaded archive contains only `src/` and `docs/`. The tooling files below are **inferred from the imports and CSS** and must be created to make the project run.

### 2.1 Dependencies (inferred from imports)

| Package | Why |
|---|---|
| `react`, `react-dom` (18.x) | UI. `react-dom/client` `createRoot` is used. `StrictMode` wraps the app. |
| `@reduxjs/toolkit` (2.x), `react-redux` (9.x) | State: `configureStore`, `createSlice`, `PayloadAction`, `Store`, `useDispatch`, `useSelector`, `TypedUseSelectorHook`. |
| `lucide-react` | All icons (see list below). |
| `typescript` (5.x), `vite` (5.x), `@vitejs/plugin-react` | Build/dev. `vite/client` types referenced in `src/vite-env.d.ts`. |
| `tailwindcss` **3.x** (not 4: the CSS uses `@tailwind base/components/utilities` and `@layer`), `postcss`, `autoprefixer` | Styling. **Tailwind only** — no component library, no CSS modules. |

No router (pages are switched with a `useState<PageId>`), no date library, no chart library (all bars are plain divs), no Google Fonts (system font stack).

**Lucide icons used (exact names):** AlertCircle, AlertTriangle, ArrowDownWideNarrow, ArrowRightLeft, ArrowUpNarrowWide, Ban, BarChart3, Bell, Building2, Calendar, CalendarPlus, Check, CheckCircle2, ChevronDown, ChevronLeft, ChevronRight, Circle, Clock, Crown, Database, Download, FileText, Hash, History, Hourglass, Inbox, Info, LayoutDashboard, LogOut, Mail, MoreVertical, Network, PauseCircle, PenSquare, Phone, PhoneOutgoing, Play, Plus, RefreshCw, Search, Send, Shield, SkipForward, Sun, Target, Trash2, TrendingUp, Trophy, Undo2, Upload, User, UserCheck, Users, Voicemail, X, XCircle. (`Calendar` is also imported `as CalendarIcon`, `Users` `as UsersIcon`.)

### 2.2 Config files to create

* **Path alias:** `@` → `./src` (used everywhere as `@/domain/...`, `@/store`, `@/shared/...`, `@/features/...`, `@/app/...`). Configure in `vite.config.ts` (`resolve.alias`) **and** `tsconfig.json` (`"baseUrl": "."`, `"paths": { "@/*": ["src/*"] }`).
* `tsconfig.json`: strict mode, `jsx: "react-jsx"`, `target ES2020+`, `moduleResolution: "bundler"`, `lib: ["ES2020","DOM","DOM.Iterable"]`, `types: ["vite/client"]`. The code uses unicode property regexes (`\p{L}`, `\p{N}` with the `u` flag), `crypto.randomUUID()`, `Array.prototype.flatMap`, `Object.fromEntries`.
* `tailwind.config.js`: `content: ['./index.html', './src/**/*.{ts,tsx}']`, no theme extension needed (all colours are stock Tailwind palette: slate, blue, emerald, amber, rose, violet, cyan, plus `white`, `black`). Arbitrary values used: `w-[72px]`, `text-[15px]`, `text-[11px]`, `text-[10px]`, `w-[18px] h-[18px]`, `w-[46%]`, `w-[26rem] h-[26rem]`, `w-[28rem] h-[28rem]`, `text-[2.6rem]`, `leading-[1.15]`, `min-h-[100px]`, `min-w-[130px]`, `min-w-[20px]`, `max-h-[90vh]`, `w-[min(92vw,34rem)]`, `z-[60]`, `z-[70]`, `z-[80]`, `z-[100]`.
* `postcss.config.js`: `tailwindcss`, `autoprefixer`.
* `index.html`: a `<div id="root"></div>` and `<script type="module" src="/src/main.tsx">`. (Title is not specified in the source; use "SalesFlow".)
* Scripts: `dev`, `build` (`tsc && vite build`), `preview`.
* `crypto.randomUUID()` needs a secure context (localhost or https).

### 2.3 Entry point (`src/main.tsx`)

```
createRoot(#root).render(
  <StrictMode>
    <Provider store={store}>
      <ErrorBoundary>
        <App />
        <StorageBanner />
      </ErrorBoundary>
    </Provider>
  </StrictMode>)
```
and it imports `./index.css`.

---

## 3. Folder structure and architecture rules

```
src/
├─ main.tsx
├─ index.css                       Tailwind layers + design tokens + animations
├─ vite-env.d.ts                   /// <reference types="vite/client" />
├─ app/
│  ├─ App.tsx                      page switch + role guard + login gate
│  ├─ navigation.ts                NAV_ITEMS, PageId, homePageFor, canOpenPage
│  ├─ useSchedulerTick.ts          30-second timer → runScheduledJobs
│  └─ layout/ AppShell, Sidebar, NotificationsMenu, UserMenu, notificationIcon.ts
├─ domain/                         PURE rules (no React, no Redux)
│  ├─ types/                       lead, workflow, callLog, meeting, email, notification, sale, task, team, teamUpdate, user, index
│  ├─ workflow/                    touchPoints, callClassification, leadQueue, leadExpiry, campaignLabel, workflowRules
│  ├─ lead/                        leadCode, leadPool, leadImport, createPoolLead
│  ├─ sales/                       saleTypes, salesTargets, salesLeaderboard, saleMigration
│  ├─ analytics/                   performanceMetrics, dateRange, commentClassifier, dataQuality
│  ├─ email/fillEmailTemplate.ts
│  ├─ meeting/meetingTime.ts
│  └─ user/roleLabel.ts
├─ store/
│  ├─ index.ts                     configureStore + startStatePersistence + re-exports
│  ├─ hooks.ts                     useAppDispatch, useAppSelector, useStore()
│  ├─ state/AppState.ts
│  ├─ seed/                        createInitialState, seedUsers, seedTeams, seedWorkflows, seedLeads, seedEmailTemplates
│  ├─ persistence/                 storageKey, loadInitialState, persistState, persistenceEvents, startStatePersistence, storedStateParser
│  └─ crm/
│     ├─ crmSlice.ts               assembles reducers only
│     ├─ reducers/                 session, touchPoint, leadWorkflow, leadPool, callLog, leadTransfer, team, meeting, teamUpdate, task, email, sales, scheduler, notification
│     ├─ helpers/                  currentUserGuards, leadHistory, callLogRecording, meetingState, touchPointScheduling
│     └─ scheduler/                autoEmailJob, leadExpiryJob, meetingDayEndJob, meetingReminderJob
├─ features/                       one folder per screen
│  ├─ auth/LoginPage.tsx
│  ├─ dashboard/                   DashboardPage, AgentDashboard, TeamLeaderDashboard, OperationManagerDashboard, dashboardCallStats, components/
│  ├─ work-queue/                  WorkQueuePage, buildWorkQueue, queueHandlers, queueStyles, useCollapsibleSections, components/
│  ├─ take-leads/                  TakeLeadsModal, ClaimResultRow
│  ├─ my-leads/MyLeadsPage.tsx
│  ├─ lead-pool/                   LeadPoolPage, formStyles, components/ (AddSingleLeadModal, PasteLeadsModal, LeadImportModalShell)
│  ├─ calendar/                    CalendarPage, meetingStatusStyles, components/ (CreateMeetingModal, MeetingDetailModal)
│  ├─ sales/                       SalesPage, salesTypes, components/
│  ├─ analytics/                   AnalyticsPage, analyticsStyles, components/
│  ├─ email-center/                EmailCenterPage, components/ (BulkEmailModal, CustomEmailModal, TemplatedEmailModal)
│  ├─ tasks/                       TasksPage, components/CreateTaskModal
│  ├─ team-updates/                TeamUpdatesPage, components/CreateUpdateModal
│  └─ teams/                       TeamsPage, components/MoveAgentModal
└─ shared/
   ├─ components/                  AgentPicker, ConfirmDialog (+useConfirm), ErrorBoundary, LeadPicker, StorageBanner, UserAvatar
   ├─ lib/dates.ts
   └─ ui/leadStatusStyles.ts
```

### 3.1 Dependency rules (SOLID)

* `features → store / domain / shared`; `store → domain`; `domain` knows **nothing** about React or Redux (it may import `@/shared/lib/dates`).
* One file answers one question (e.g. `leadExpiryJob.ts` = the 15-day rule only). The slice is only an assembler: `reducers: { ...sessionReducers, ...touchPointReducers, ...leadWorkflowReducers, ...leadPoolReducers, ...callLogReducers, ...leadTransferReducers, ...teamReducers, ...meetingReducers, ...teamUpdateReducers, ...taskReducers, ...emailReducers, ...salesReducers, ...schedulerReducers, ...notificationReducers }`.
* Components receive **small props** (e.g. `QueueHandlers`) instead of the whole state where practical, but most pages call `useStore()` which returns `{ state: s.crm, dispatch }`.
* **Permissions are enforced twice:** the UI hides buttons, **and the reducers re-check** the actor (role / ownership). A reducer that fails a check simply `return`s (silent no-op).
* **Renamed-action table** (for readers of old code): `setUser→setCurrentUser`, `claimLeads→takeLeadsFromPool`, `addPoolLeads→addLeadsToPool`, `logCall→logCallAndCompleteTouchPoint`, `addCallLog→addCallLogWithoutCompletingTouchPoint`, `markTouchpoint/skipTouchpoint/restoreTouchpoint→completeTouchPoint/skipTouchPoint/restoreSkippedTouchPoint`, `stopLead/resumeLead→stopLeadWorkflow/resumeLeadWorkflow`, `removeLead→removeLeadFromAgentQueue`, `deleteLead→deleteLeadPermanently`, `transferLead→transferLeadToAgent`, `tickScheduler→runScheduledJobs`, `hydrate→applyStateFromOtherTab`, `sendEmail/bulkEmail/sendCustomEmail→sendEmailForLead/sendBulkEmailForLeads/sendStandaloneEmail`, `addMeeting/addUpdate/ackUpdate/addTask/toggleTask/addSale→createMeeting/postTeamUpdate/acknowledgeTeamUpdate/createTask/toggleTaskCompletion/recordSale`. Component renames: `Layout→AppShell`, `WorkQueue→WorkQueuePage`, `Leads→MyLeadsPage`, `AdminLeads→LeadPoolPage`.
* **Names deliberately left unchanged** because they are persisted: fields `removedFromQueue`, `expiredAt`, `previousAssignments`, …; values `'nvm'`, `'lvm'`, …; storage key.

### 3.2 Public API of `@/store`

`@/store` (`store/index.ts`) exports: `store`, types `RootState`, `AppDispatch`, `AppState`; everything from `crmSlice` (all action creators + `crmActions` + default reducer); everything from `hooks` (`useAppDispatch`, `useAppSelector`, `useStore`); and `PERSIST_FAILED_EVENT`, `PERSIST_OK_EVENT`.

Root reducer shape: `{ crm: <AppState> }`. `store/index.ts` calls `startStatePersistence(store)` immediately after creating the store.

Action creators exported from the slice (exactly these 33): `setCurrentUser, applyStateFromOtherTab, logCallAndCompleteTouchPoint, completeTouchPoint, skipTouchPoint, restoreSkippedTouchPoint, stopLeadWorkflow, resumeLeadWorkflow, removeLeadFromAgentQueue, deleteLeadPermanently, addLeadsToPool, deleteLeadsAsAdmin, takeLeadsFromPool, moveAgentToTeam, addCallLogWithoutCompletingTouchPoint, editCallLog, transferLeadToAgent, createMeeting, updateMeeting, postTeamUpdate, acknowledgeTeamUpdate, createTask, toggleTaskCompletion, sendEmailForLead, sendBulkEmailForLeads, sendStandaloneEmail, recordSale, deleteSale, runScheduledJobs, markNotificationRead, markAllNotificationsRead, addNotification, resetToSeedData`.

> Present in the store but **not wired to any UI**: `completeTouchPoint`, `addCallLogWithoutCompletingTouchPoint`, `editCallLog`, `resetToSeedData` (and `applyStateFromOtherTab` is used only by the persistence layer). Keep them — they are part of the store API and docs.

---

## 4. Data model (TypeScript types, `src/domain/types/*`)

`src/domain/types/index.ts` re-exports: user, team, workflow, callLog, lead, meeting, teamUpdate, task, email, notification, sale. Consumers import `import type { Lead } from '@/domain/types'`.

### 4.1 `AppState` (`store/state/AppState.ts`) — the one object that is saved

```ts
interface AppState {
  currentUserId: string;        // '' = nobody signed in
  users: User[];
  teams: Team[];
  workflows: Workflow[];
  leads: Lead[];
  meetings: Meeting[];
  updates: TeamUpdate[];
  tasks: Task[];
  emailTemplates: EmailTemplate[];
  emailLogs: EmailLog[];
  notifications: Notification[];
  sales: Sale[];
}
```
11 arrays + `currentUserId`. Relationships are by `id` (see ER summary in §4.13).

### 4.2 `User` and `UserRole`
```ts
type UserRole = 'admin' | 'operation_manager' | 'team_leader' | 'agent' | 'quality';
interface User { id; username; name; email; role: UserRole; teamId?: string; initials; color /* hex used as avatar background */; dailyCallTarget: number }
```
`dailyCallTarget` is 90 for agents, 0 for everyone else (seed).

### 4.3 `Team`
`{ id, name, leaderId, agentIds: string[], managerId }` — one leader, many agents, one operation manager. (Note: `User.teamId` is also kept in sync by `moveAgentToTeam` for the agent; leaders have `teamId` of their own team.)

### 4.4 Workflow types (`workflow.ts`)
```ts
type TouchPointType = 'call' | 'email';
interface TouchPointTemplate { order: number; type: TouchPointType; label: string; dayOffset: number }
interface Workflow { id; campaignCode; name; touchPoints: TouchPointTemplate[] }   // the TEMPLATE for a campaign
type TouchPointStatus = 'pending' | 'overdue' | 'completed' | 'skipped';
interface TouchPoint { order; type; label; dayOffset; status: TouchPointStatus; completedAt: string|null; dueDate: string|null; skippedAt?: string|null }  // the lead's COPY
```
`dayOffset` values are **cumulative** (0, 1, 2, 4, 5, 7 …), not gaps. `order` is 0-based and unique per lead.

### 4.5 `CallLog` (`callLog.ts`)
```ts
type CallType = 'nvm' | 'lvm' | 'discovery';
type CallReason = 'interested'|'callback'|'price'|'timing'|'not_interested'|'wrong_contact'|'no_answer'|'voicemail'|'other';  // optional, never set by the current UI
interface CallLog { id; type: CallType; reason?: CallReason; description: string; timestamp: string /*ISO, real time of call*/; editedAt?: string; touchPointOrder: number;
  // filled by the store: agentId?, agentName?, touchPointLabel?, round? }
```
Meaning on screen: **NVM = "No Voicemail"**, **LVM = "Left Voicemail"**, **Discovery = "Client Responded"**.

### 4.6 `Lead` (`lead.ts`) — the heart of the system
```ts
type LeadStatus = 'new' | 'discovery' | 'lvm' | 'nvm' | 'no_response' | 'arranged_meeting';
interface LeadHistoryEntry { id; action: string; timestamp; userId; userName; detail?; round?; agentId?; touchPointOrder?; touchPointLabel?; touchPointType?; meta?: Record<string,unknown> }
interface LeadAssignment { round; agentId; agentName; assignedAt; endedAt; endedBy; endedByName; touchPoints: TouchPoint[] /* frozen deep copy */ }
interface Lead {
  id; leadCode; campaignCode; companyName; contactName; phone; email;
  status: LeadStatus;
  agentId: string;                 // '' while in the shared pool
  assignedAt: string;
  touchPoints: TouchPoint[];
  currentTouchPoint: number;       // order of the open step; -1 = none / finished / in pool
  callLogs: CallLog[];
  history: LeadHistoryEntry[];     // activity log (lives INSIDE the lead)
  stopped: boolean;
  removedFromQueue: boolean;
  removedAt: string | null;
  round?: number;                  // defaults to 1; +1 on every new agent
  previousAssignments?: LeadAssignment[];
  expiredAt?: string | null;       // set by the 15-day rule
  lastActivityAt?: string;
  discoveryReached?: boolean;      // a meeting was arranged ⇒ "reached"
}
```
Touch points, call logs, history and previous assignments are **nested inside the lead** (not separate tables). `status 'no_response'` exists in the type and the colour map but is never assigned by any code path.

### 4.7 `Meeting`
```ts
type MeetingStatus = 'arranged'|'completed'|'no_show'|'cancelled'|'rescheduled';
type MeetingType = 'lead_meeting' | 'internal_meeting';
interface Meeting { id; type; leadId?; leadName? /*contact name*/; companyName?; agentId?; participantIds: string[]; participantNames: string[]; title; date /*YYYY-MM-DD*/; time /*HH:mm*/; duration /*minutes*/; notes /*agenda*/; outcome?; status; priority: 'high'|'normal'; createdBy; reminderSentAt?: string|null }
```
`outcome` is **required** (non-empty after trim) when a meeting that has a `leadId` is set to `completed`.

### 4.8 `TeamUpdate`
`UpdateAudience = 'all' | 'team_leaders' | 'specific_team'`. `{ id, audience, teamId: string|null, authorId, authorName, title, content, createdAt, acknowledgedBy: string[] }`.

### 4.9 `Task`
`{ id, authorId, authorName, title, description, createdAt, deadline /*ISO or YYYY-MM-DD string*/, assignedTo: string[], completedBy: string[] }`.

### 4.10 Email
```ts
interface EmailTemplate { id; name; type: 'discovery'|'no_response'; subject; body }
interface EmailLog { id; leadId /* '' for standalone */; leadName; to; subject; body; templateType: 'discovery'|'no_response'|'custom'; sentAt; sentBy; sentByName; auto?: boolean; idempotencyKey?: string }
```
Email "sending" is **simulated**: it only writes an `EmailLog`.

### 4.11 `Notification`
`{ id, type: 'meeting'|'update'|'task'|'overdue'|'email', title, message, timestamp, read: boolean, leadId?, meetingId?, userId? }` — when `userId` is set only that user sees it; when absent everybody sees it.

### 4.12 `Sale`
`SaleType = 'BP'|'PPI'|'MUA'|'ATEP'|'Activation'|'Retention'|'Transition'`. `{ id, agentId, leadId /*REQUIRED*/, leadName /*snapshot of company name*/, saleType, date /*YYYY-MM-DD*/, createdBy /*quality user*/, createdAt }`.

### 4.13 Relationships
USER→LEAD by `lead.agentId`; TEAM→USER by `agentIds/leaderId/managerId`; WORKFLOW→LEAD by `campaignCode`; LEAD→MEETING by `meeting.leadId`; LEAD→EMAILLOG by `emailLog.leadId`; LEAD→SALE by `sale.leadId`; USER→NOTIFICATION by `userId`.

---

## 5. Business rules and constants

### 5.1 Constants
| Constant | Value | File |
|---|---|---|
| `LEAD_EXPIRY_DAYS` | **15** calendar days | `domain/workflow/workflowRules.ts` |
| `MEETING_REMINDER_MINUTES` | **15** | same |
| `AUTO_EMAIL_ENABLED` | **true** | same |
| `SCHEDULER_INTERVAL_MS` | **30000** | `app/useSchedulerTick.ts` |
| `STORAGE_KEY` | `'sales-mgmt-state-v4'` | `store/persistence/storageKey.ts` |
| `AGENT_SALES_TARGET` | **28** sales/agent/month | `domain/sales/salesTargets.ts` |
| `MAX_ROWS_PER_IMPORT` | **1000** | `domain/lead/leadCode.ts` |
| `WEEK_STARTS_ON` | **6** (Saturday) | `domain/analytics/dateRange.ts` |
| persistence debounce | **150 ms** | `startStatePersistence.ts` |
| LeadPicker `MAX_RESULTS` | **50** | `shared/components/LeadPicker.tsx` |
| Lead Pool page row cap | **300** | `LeadPoolPage.tsx` |
| Lead-ID/problem list caps | 50 shown, then "…and N more" | Take Leads / Paste Leads |
| `teamSalesTarget(team)` | `team.agentIds.length × 28`; OM target = sum over own teams | |

### 5.2 Lead code rules (`domain/lead/leadCode.ts`)
* `cleanLeadCode(code)`: remove invisible chars (`[\u200B-\u200F\u202A-\u202E\u2060\uFEFF\u00AD]`), `normalize('NFKC')`, `trim`, strip surrounding quotes (`" ' “ ” ‘ ’`) at both ends, `trim`, collapse whitespace runs to one space. **This is what is stored.**
* `normalizeLeadCode(code)` = `cleanLeadCode(code).toUpperCase().replace(/[^\p{L}\p{N}]/gu, '')`. **This is the identity**: `"acd123" = "AcD123" = "ACD-123" = "acd 123"`, but `"LD-001" ≠ "LD-1"` and `"ABC12" ≠ "ABC21"`. Campaign, company, phone and email are **not** part of identity.
* `isValidLeadCode(code)` = `/^[\p{L}\p{N}]+$/u.test(cleanLeadCode(code))` (letters and digits only — no spaces, dashes, symbols).
* `isValidEmail(email)` = `/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/`.
* **Uniqueness:** a lead code must be unique across the **whole system** (every agent, the pool, and removed leads that went back to the pool).

### 5.3 Pool ownership (`domain/lead/leadPool.ts`)
* `isInPool(l) = !l.agentId || l.removedFromQueue` — nobody owns it (created by Admin, or the agent removed it).
* `splitLeadIds(text)`: line by line; blank lines skipped; if a line contains a **tab**, only its **first cell** counts; otherwise split on `,` or `;`; each piece goes through `cleanLeadCode`; empty pieces skipped; a leading header cell matching `/^(lead\s*)?(code|id)$/i` is skipped (only when it is the very first id). Returns `{ line /*1-based*/, code }[]`.
* `planTakeFromPool(ids, leads, agentId, agentNameOf)` returns one `ClaimResult { line, code, status, leadId?, holderName? }` per id:
  1. normalized key empty → `invalid`
  2. key already seen in this list → `duplicate`
  3. find holder: iterate leads whose normalized code equals key; if any lead **is not in pool** → that is the **holder** (an active lead always wins over an older removed copy), else remember the last in-pool one as `pool`
  4. holder exists → `mine` (holder.agentId === me, with `leadId`) or `taken` (with `holderName` = agent name or `'another agent'`)
  5. no pool lead → `not_found`
  6. `ready` count already ≥ 1000 → `over_limit`
  7. else `ready` (with `leadId` of the pool lead)
* `CLAIM_STATUS_TEXT`: ready "Ready to add"; mine "Already in your leads"; taken "Held by another agent"; not_found "Not found in the pool"; invalid "Not a valid lead ID"; duplicate "Repeated in this list"; over_limit "Over the limit of 1000 leads at once".

### 5.4 Bulk lead import (`domain/lead/leadImport.ts`)
`splitPastedRow(line)`: tab → split on tab (trim each); else if it contains `,` or `;` → split on those; else `^(\S+)\s+(.*)$` → `[firstWord, rest]` ("AB12 Nile Trading" → id AB12, company "Nile Trading"); else `[line.trim()]`.

`parseAdminRows(text, existingCodes, workflows, defaultCampaign)` → `{ accepted: ParsedAdminRow[], rejected: RejectedRow[] }`. Columns: **Lead ID | Company | Contact | Phone | Email | Campaign (optional, code or name, case-insensitive)**. For each non-blank line, in order (rejection reasons, exact text):
1. header row (first data row, code matches header regex) → ignored silently
2. `dataRows > 1000` → `Over the limit of 1000 leads per import`
3. empty code → `Lead code is missing`
4. invalid code → `Lead ID must contain letters and numbers only`
5. repeated in this paste → `Repeated in this paste`
6. already exists anywhere → `This lead ID already exists`
7. email given but invalid → `Invalid email "<email>"`
8. campaign cell given but unknown → `Unknown campaign "<cell>"`; empty cell → default campaign
Accepted row: `companyName = parts[1] || code`, `contactName = parts[2] || ''`, `phone = parts[3] || ''`, `email`, `campaignCode`.
There is also an agent-side `parseLeadRows(...)` (same idea with owner map, "Already in your leads" / "Already assigned to <name|another agent>") — it exists in the source but is **not used by any screen**.

`dropTakenLeadCodes(incoming, existing)` — reducer safety net: keeps only leads with a valid code whose normalized code is not taken (and also dedupes inside `incoming`).

`createPoolLead(adminId, adminName, fields)` builds a lead: `id = crypto.randomUUID()`, `status 'new'`, `agentId ''`, `assignedAt = now`, `touchPoints []`, `currentTouchPoint -1`, `callLogs []`, one history row `{action:'created', userId: adminId, userName: adminName, detail:'Lead created by the Admin (in the pool)'}`, `stopped false`, `removedFromQueue false`, `removedAt null`.

### 5.5 Touch-point rules (`domain/workflow/touchPoints.ts`)
* `isOpenTouchPoint(tp)` = status `pending` or `overdue`.
* `findCurrentTouchPoint(lead)` = the touch point whose `order === lead.currentTouchPoint`.
* `scheduleNextTouchPoint(touchPoints)`: index of the first open one; if none → `{ touchPoints, next: undefined }`. Else `prev` = the touch point with the highest `order` lower than this one; `gapDays = max(0, tp.dayOffset − (prev?.dayOffset ?? 0))`; new `dueDate = now + gapDays × 86400000 ms` (ISO). Returns the updated array and `next`. **Because offsets are cumulative, the wait is the *gap* from the previous step, counted forward from the moment the previous step was completed** — not from the assignment day.
* `describeDueDate(tp)` → `{label, tone}`: no tp/dueDate → `''`/`none`; due before start-of-today → `Overdue Nd` (N = `max(1, round(days))`) tone `overdue`; due ≤ end-of-today → `Due today` tone `today`; else `Due in Nd` (N = `ceil((due − endOfToday)/day)`) tone `later`.
* `lastTouchTimestamp(lead)` = max `completedAt` over completed touch points, or `null`.
* `stepLabel(order, type)` = `"{order+1}: {TYPE}"` e.g. `1: CALL`, `2: EMAIL`.
* `pointLeadAtFirstOpenTouchPoint(lead)` (store helper): `first` = first open touch point; none → `currentTouchPoint = -1`, stop. If `first.order === currentTouchPoint` → **do nothing** (so skipping a *future* step never resets the current step's due date). Else call `scheduleNextTouchPoint`, assign result and set `currentTouchPoint = next.order`.

### 5.6 Call classification (`domain/workflow/callClassification.ts`)
* `currentRoundCalls(lead)`: call logs with `(cl.round ?? 1) === (lead.round ?? 1)`.
* Rank: discovery 3 > lvm 2 > nvm 1. `highestCallType(lead)` = best type among current-round calls, or `null`.
* `effectiveCallType(lead)` = `'discovery'` if `lead.discoveryReached` else `highestCallType`.
* `queueCategory(lead)`: `status === 'arranged_meeting'` → `'meeting'`; else `effectiveCallType ?? 'new'`. Categories: `new | discovery | lvm | nvm | meeting`.
* `statusFromCalls(lead)`: unchanged if `arranged_meeting`; else `effectiveCallType ?? 'new'`.

### 5.7 Work-queue bucket (`domain/workflow/leadQueue.ts`)
`queueBucket(lead, now)`: `stopped` → `'stop'`; no current touch point or it is not open → `'finished'`; no `dueDate` → `'today'`; `due ≤ endOfDay(now)` → `'today'` else `'next'`. `becomesTodayAt(tp)` = start of the due day (ms) or `null`.

### 5.8 15-day rule (`leadExpiry.ts`)
`expiryReferenceMs(lead)` = max of `assignedAt`, `lastActivityAt`, and every completed touch point's `completedAt` (NaN ignored). `daysUntilExpiry(lead, now)` = `max(0, ceil((reference + 15 days − now)/day))`.

### 5.9 Campaign label
`campaignLabel(workflows, code)`: workflow name for the code (fallback: the code) with a trailing `" campaign"` (case-insensitive) removed and trimmed. `"Activation Campaign"` → **Activation**; `"Retention Campaign"` → **Retention**.

### 5.10 Email templating
`fillEmailTemplate(text, lead, agentName)` replaces globally `[Name]` → `lead.contactName || 'there'`, `[Company Name]` → `lead.companyName`, `[Agent Name]` → agent name.

### 5.11 Meetings
`meetingStartMs(m) = new Date(`${m.date}T${m.time}:00`).getTime()`.

### 5.12 Sales
* `SALE_TYPES` (value = label): BP `bg-emerald-100 text-emerald-700`; PPI `bg-violet-100 text-violet-700`; MUA `bg-blue-100 text-blue-700`; ATEP `bg-amber-100 text-amber-700`; Activation `bg-cyan-100 text-cyan-700`; Retention `bg-rose-100 text-rose-700`; Transition `bg-slate-100 text-slate-700` (the `chip` class). `saleTypeConfig(t)` falls back to the first. `countByType(sales)` → record with all 7 keys initialised to 0.
* `migrateSale(x)`: if `saleType` is not a valid type, map legacy `new→Activation`, `upsell→Activation`, `renewal→Retention`, anything else → `Activation`; drop legacy `product` field.
* Leaderboard `topAgentsOfMonth(agents, sales, leads, month 'YYYY-MM', limit=5)`: per agent: sales in that month, plus `discovery` and `lvm` call counts that agent logged in that month (`(cl.agentId ?? lead.agentId) === agent.id`, local month of `cl.timestamp`). Drop agents with 0 sales. Sort: sales desc, then discovery desc, then lvm desc, then name `localeCompare`. Slice to limit.

### 5.13 Analytics rules (`domain/analytics/*`)
* `pct(n, d) = d>0 ? round(n/d*1000)/10 : 0` (one decimal).
* `hasReachedPerson(lead)` = `discoveryReached || status 'discovery' || status 'arranged_meeting' || any call of type discovery`.
* `callStats(leads)` → `{calls, nvm, lvm, discovery, answerRate = pct(lvm+discovery, calls), reachRate = pct(discovery, calls)}`.
* `funnel(leads, meetings, sales)` → `{ leads: n, contacted: leads with ≥1 call, reached: hasReachedPerson, meetings: distinct leads (in set) having a lead_meeting, sold: distinct leads (in set) with a sale }`.
* `GroupRow` = callStats + `{key,label,leads,reached,sold (distinct sold leads), sales (count), conversion = pct(sold, leads), reachToSale = pct(sold, reached), callsPerLead = round(calls/leads*10)/10}`. `byCampaign(leads, sales, labelFn)` (campaign codes sorted alphabetically), `byAgent(leads, sales, agents)` (grouped by `lead.agentId`).
* `byHour(leads)`: per local hour of call timestamp: `{hour, calls, answered (type ≠ nvm), reached (discovery), reachRate = pct(reached, calls)}` sorted by hour.
* `resolveRange(preset, custom, now)`: `today` → today..today; `week` → starts on Saturday: `back = (day − 6 + 7) % 7`, from = now−back days, to = from+6; `month` → first..last day of the current month; `custom` → from = `custom.from || custom.to || today`, to = `custom.to || from`, swapped if reversed. `dayOf(iso)` = local YYYY-MM-DD; `isInRange(day, r)` inclusive.
* `leadsForPeriod(leads, range, keepIds)`: for each lead keep only call logs whose local day is in range; include the lead if it has such calls, **or** `assignedAt` day in range, **or** its id is in `keepIds` (sold in period); the returned copy has `callLogs` filtered, `status: 'new'`, `discoveryReached: callLogs.some(discovery)`.
* `REASON_LABEL`: interested "Interested", callback "Call back later", price "Price", timing "Timing", not_interested "Not interested", wrong_contact "Wrong contact", no_answer "No answer", voicemail "Voicemail / third person", other "Other".
* `classifyComment(text, type)`: first matching rule in this order wins (case-insensitive; includes Arabic keywords):
  1. wrong_contact `/wrong (number|contact|person)|left the company|رقم غلط|مش هو|ساب الشركة/i`
  2. not_interested `/not interested|no interest|refus|declin|مش مهتم|مش عايز|رفض/i`
  3. price `/pric|cost|expensive|discount|budget|سعر|غالي|تكلف|خصم/i`
  4. callback `/call ?back|later|ring back|كلمني|بعدين|اتصل تاني/i`
  5. timing `/next (week|month|quarter)|not now|busy|الشهر الجاي|مشغول|مش دلوقتي/i`
  6. interested `/interest|agree|wants|requested|confirm|great|مهتم|موافق|عايز/i`
  7. no_answer `/no answer|nobody|didn.t answer|مفيش رد|محدش رد/i`
  8. voicemail `/voicemail|assistant|secretary|message|سكرتير/i`
  fallback by call type: nvm→`no_answer`, lvm→`voicemail`, discovery→`other`.
  `reasonCounts(leads)` uses `call.reason ?? classifyComment(description, type)`, returns `{reason,count,share=pct}` sorted by count desc.
* `findDataQualityIssues(leads, sales)` → list of `{id, level, text}` (in this order, each only if non-empty):
  * `sale-no-lead` (warn): `"N sale(s) are not linked to a lead, so they are missing from campaign and agent analysis."`
  * `sale-unreached` (warn): `"N sale(s) belong to leads nobody has reached yet (<leadName, …>)."`
  * `sale-agent` (info): `"N sale(s) are credited to a different agent than the lead's current owner (usually after a transfer)."`
  * `no-reason` (info): `"X of Y calls have no structured reason; they are classified from the comment text."`
  * `dup-sale` (warn): `"N possible duplicate sale(s): same lead, type and date."` (key `leadId|saleType|date`)

### 5.14 Date helpers (`shared/lib/dates.ts`)
`localDay(d=now)` and `localDateStr(d=new Date())` → local `YYYY-MM-DD`; `startOfDay`, `endOfDay` (23:59:59.999); `formatDuration(ms)`: `mins = max(1, round(ms/60000))`; `<60` → `"{m} min"`; `<24h` → `"{h}h"` or `"{h}h {m}m"`; else `"{d}d"` or `"{d}d {h}h"`. `currentMonthKey()` = `localDateStr().slice(0,7)`; `shiftMonth('YYYY-MM', delta)`; `monthLabel('YYYY-MM')` = `toLocaleDateString('en-US',{month:'long',year:'numeric'})`.

### 5.15 Lead-status colours (`shared/ui/leadStatusStyles.ts`) — `LEAD_STATUS_STYLE`
| status | label | `color` | `dot` |
|---|---|---|---|
| new | New | `bg-slate-100 text-slate-700` | `bg-slate-400` |
| discovery | Discovery | `bg-emerald-100 text-emerald-700` | `bg-emerald-500` |
| lvm | LVM | `bg-amber-100 text-amber-700` | `bg-amber-500` |
| nvm | NVM | `bg-amber-100 text-amber-700` | `bg-amber-500` |
| no_response | No Response | `bg-rose-100 text-rose-700` | `bg-rose-500` |
| arranged_meeting | Meeting | `bg-violet-100 text-violet-700` | `bg-violet-500` |

`roleLabel(role)`: Admin / Operation Manager / Team Leader / Agent / Quality (unknown → the raw value).

---

## 6. The store

### 6.1 Persistence ("the database")

* **Key:** `sales-mgmt-state-v4`. The whole `AppState` (including `currentUserId`) is `JSON.stringify`-ed into it.
* **Initial state** (`loadInitialState`): read `localStorage[KEY]`; if present run `parseStoredState`; valid → use it. If the text exists but is unusable, **copy it to `sales-mgmt-state-v4-corrupt-<Date.now()>`** (inside try/catch) and fall back to `createInitialState()`. Any storage exception (private mode) → run in memory with seed data.
* **`parseStoredState(raw)`** (defensive reader/migrator): `JSON.parse`; reject (return `null`) unless it is an object with array `leads` and array `users`. Merge `{...freshSeed, ...parsed}`; for each of the 11 array keys (`users, teams, workflows, leads, meetings, updates, tasks, emailTemplates, emailLogs, notifications, sales`) that is not an array, take the seed's. `currentUserId` not a string → `''`. Every lead gets `touchPoints ?? []`, `callLogs ?? []`, `history ?? []`. Sales without `leadId` are linked by matching `leadName === lead.companyName` (else `''`); then every sale goes through `migrateSale`. If no `quality` user exists, push the seed quality user; if no `admin` exists, **unshift** the seed admin.
* **`persistState(state)`**: `localStorage.setItem(KEY, JSON.stringify(state))`; returns `true`, or `false` after `console.error('Could not save the data to localStorage', err)`.
* **`startStatePersistence(store)`**:
  * `store.subscribe` → mark `dirty = true`, restart a **150 ms** timer that calls `flush()`. (Ignored while `applyingRemote`.)
  * `flush()`: clear timer; if not dirty return (never overwrite another tab's newer data with a stale copy); `dirty=false`; `persistState`; dispatch `window` event `crm:persist-ok` or `crm:persist-failed`.
  * `window 'pagehide'` and `document 'visibilitychange'` (when hidden) → `flush()`.
  * `window 'storage'` event: ignore other keys / null values; `parseStoredState(e.newValue)`; if valid → clear timer, `dirty=false`, set `applyingRemote=true`, dispatch `applyStateFromOtherTab(next)`, reset flag. (Prevents ping-pong between tabs.)
* **`applyStateFromOtherTab`** reducer returns `{ ...payload, currentUserId: state.currentUserId }` — a tab keeps *its own* logged-in user.
* Events: `PERSIST_FAILED_EVENT = 'crm:persist-failed'`, `PERSIST_OK_EVENT = 'crm:persist-ok'`.

### 6.2 Reducer-level helpers

* `findCurrentUser(state)`; `isOwnedByCurrentUser(state, lead)` = signed-in and `lead.agentId === currentUserId`; `leadsHoldingTheirCode(state)` = leads with `!removedFromQueue`; `isLeadWorkable(lead)` = `!stopped && !removedFromQueue && !expiredAt`; `findLeadById`.
* `createUserHistoryEntry(state, lead, action, detail?, tp?, meta?)` → `{ id: randomUUID, action, timestamp: now ISO, userId: currentUserId, userName: user.name or '', detail, round: lead.round ?? 1, agentId: lead.agentId, [touchPointOrder, touchPointLabel, touchPointType if tp], [meta if given] }`.
* `createSystemHistoryEntry(lead, action, detail?, tp?, meta?)` → same but `userId:'system'`, `userName:'System'`.
* `recordCallLogOnLead(state, lead, rawLog)`: finds the touch point by `rawLog.touchPointOrder`; pushes `{...raw, agentId: currentUserId, agentName: actor name or '', touchPointLabel: tp?.label, round: lead.round ?? 1}` to `lead.callLogs`; sets `lead.status = statusFromCalls(lead)`; pushes history `call_logged` with detail `"<TYPE>: <description>"` and meta `{callLogId, callType}` (with `tp`); returns `tp`.
* `returnLeadToQueueWhenMeetingEnds(state, lead, reason, byUser)`: only if `lead.status === 'arranged_meeting'`. `today = localDay()`. If any meeting with `leadId === lead.id && status === 'arranged' && date >= today` exists → stay. Else `lead.status = lead.discoveryReached ? 'discovery' : (highestCallType(lead) ?? 'new')`; `lastActivityAt = now` (15-day count restarts); push history `meeting_ended` with detail `"<reason> - back in the Discovery queue"` (user entry if `byUser`, else system entry).

### 6.3 Reducers (every action, exact guards and effects)

**Session** — `setCurrentUser(id)`: sets `currentUserId`. `applyStateFromOtherTab` (above). `resetToSeedData()`: returns `createInitialState()`.

**Touch points**
* `completeTouchPoint({leadId, order})`: lead must exist, be owned by me and **workable**; touch point must exist and be open (a double click can't complete twice). Set `completed`, `completedAt = now`, `pointLeadAtFirstOpenTouchPoint(lead)`, history `mark_complete` / `"Touch point {order+1} completed"` (with tp).
* `skipTouchPoint({leadId, order})`: lead exists, owned by me, **not removed** (a stopped lead *can* be skipped by the reducer; the UI only offers skip when not stopped). Touch point open → `skipped`, `skippedAt = now`, re-point, history `touchpoint_skipped` / `"Touch point {n} ({label}) skipped"`.
* `restoreSkippedTouchPoint({leadId, order})`: owned, not removed; tp must be `skipped` → `pending`, `skippedAt = null`, re-point (the due date of a restored step is re-based only if it becomes the first open step), history `touchpoint_restored` / `"Touch point {n} ({label}) restored"`.

**Lead workflow**
* `stopLeadWorkflow(leadId)`: owned, not already stopped, not removed → `stopped = true`, `lastActivityAt = now`, history `workflow_stopped` (no detail).
* `resumeLeadWorkflow(leadId)`: owned, `stopped`, **not expired**, not removed (an expired lead returns only via transfer) → `stopped = false`, `lastActivityAt = now`, re-point, history `workflow_resumed`.
* `removeLeadFromAgentQueue(leadId)`: owned, not already removed → `removedFromQueue = true`, `removedAt = now`, `stopped = true`; history `removed_from_queue` / `"Removed from the agent's leads - history kept, the lead is back in the shared pool and its id is free"`.
* `deleteLeadPermanently(leadId)`: owned by me; **refused if any sale has `leadId`**; removes the lead from `state.leads`; every meeting with that `leadId` and status `arranged` becomes `cancelled`.

**Lead pool**
* `addLeadsToPool(Lead[])`: only if current user role is `admin`. Run `dropTakenLeadCodes(payload, state.leads)`, then force each to `agentId '', touchPoints [], currentTouchPoint -1, callLogs [], status 'new', stopped false, removedFromQueue false, removedAt null, expiredAt null`; `unshift` them (newest first).
* `deleteLeadsAsAdmin(ids[])`: admin only. Leads that have a sale are skipped (kept). Remaining are removed; their `arranged` meetings → `cancelled`. Does nothing if the set is empty.
* `takeLeadsFromPool(ids[])`: current user must be an **agent**. `taken` = set of normalized codes of leads that have an agent and are not removed. For each unique id: lead must exist and `isInPool`; if its normalized code is in `taken` skip; the campaign **workflow must exist** else skip. `firstTime = !lead.agentId`. If **not** first time (a removed lead coming back): archive a `LeadAssignment { round, agentId, agentName: previous agent name, assignedAt: lead.assignedAt, endedAt: lead.removedAt ?? now, endedBy: previous agentId, endedByName, touchPoints: deep copy }` into `previousAssignments`, and `round = round + 1`; else `round = lead.round ?? 1`. Then: `agentId = me`, `assignedAt = now`, `touchPoints` = copy of workflow template where each is `{order,type,label,dayOffset,status:'pending',completedAt:null,dueDate}` with **`dueDate = now` for order 0 and `now + dayOffset days` for others**, `currentTouchPoint = 0`, `status 'new'`, `stopped false`, `removedFromQueue false`, `removedAt null`, `expiredAt null`, `discoveryReached false`, `lastActivityAt now`. History `taken_from_pool` with detail `"Taken from the pool by {name}"` or `"Taken again from the pool by {name} (round {n})"`. Add the key to `taken` (so two ids with the same code can't both be taken).

> Note the difference: at *take/transfer* time later steps get `due = now + dayOffset days`; only after an earlier step is *completed/skipped* does the next step get its due recalculated from the gap (see §5.5).

**Calls**
* `logCallAndCompleteTouchPoint({leadId, log})`: owned, workable; tp for `log.touchPointOrder` must exist, be of **type call** and open. Run `recordCallLogOnLead`; mark tp completed (`completedAt = now`); re-point; history `mark_complete` / `"Touch point {n} completed"`. (One atomic action so a log can never exist without its completed step.)
* `addCallLogWithoutCompletingTouchPoint({leadId, log})`: owned, workable → `recordCallLogOnLead` only. (Unused by UI.)
* `editCallLog({leadId, logId, callType, description})`: owned; sets type/description, `editedAt = now` (`timestamp` untouched), recomputes lead status, history `call_edited` / `"<OLD TYPE>: <old desc>  →  <NEW TYPE>: <new desc>"` (two spaces around the arrow) with meta `{callLogId}`. (Unused by UI.)

**Transfer** — `transferLeadToAgent({leadId, newAgentId})`: lead exists, **not removed**, new agent differs from current. Actor must exist; new user must have role `agent`. Allowed only if actor is **operation_manager** (any lead) or **team_leader whose team's `agentIds` includes the lead's current agent**. Archive current assignment (`endedAt = now`, `endedBy = actor`), new agent gets a fresh copy of the workflow (template from the campaign workflow, or the lead's own touch points if the workflow is missing; same due rule as take: order 0 due now, others `now + dayOffset`), `agentId = new`, `assignedAt = now`, `currentTouchPoint = 0`, `status 'new'`, `stopped false`, `removedFromQueue false`, `removedAt null`, `round + 1`, `expiredAt null`, `discoveryReached false`, `lastActivityAt now`, `previousAssignments` appended. History `transfer` / `"Transferred from {old} to {new} (round {r}: {done}/{total} touch points were completed)"` with meta `{fromAgentId,toAgentId,fromRound,toRound,completedTouchPoints,totalTouchPoints}`.

**Teams** — `moveAgentToTeam({agentId, toTeamId})`: actor must be `operation_manager`; agent must exist with role agent; target team must exist and be managed by the actor; current team (if any) must also be managed by the actor; same team → no-op. Remove agent id from every team's `agentIds`, push to the target, set `agent.teamId`. Create three `update`-type notifications (each `read:false`, `userId` set): to the agent **"You moved to a new team"** / `"You are now in {to}{ (was {from})}. Your leads and history stay with you."`; to the new leader **"New agent in your team"** / `"{agent} joined {to}{ from {from}}."`; to the old leader (if any) **"An agent left your team"** / `"{agent} moved from {from} to {to}."`. Leads, calls, meetings, emails, sales are **not touched**.

**Meetings**
* `createMeeting(meeting)`: push. If it has a lead: `lead.status = 'arranged_meeting'`, `discoveryReached = true`, history `meeting_arranged` / `"{date} at {time}"` meta `{meetingId}`.
* `updateMeeting({meetingId, updates})`: meeting must exist **and `createdBy === currentUserId`** (invited people can view only). If `updates.status === 'completed'` and the meeting has `leadId` and the resulting outcome (`updates.outcome ?? m.outcome ?? ''`) is blank → refuse. `Object.assign`. If the meeting has a lead and the status changed to anything except `arranged`: history `meeting_{status}` with detail `"{date} at {time}"` (for completed with an outcome: `"{date} at {time} - {outcome}"`), then `returnLeadToQueueWhenMeetingEnds(…, "Meeting " + status with '_' → ' ', byUser true)`.

**Team updates** — `postTeamUpdate(update)` unshift; `acknowledgeTeamUpdate({updateId,userId})` add once to `acknowledgedBy`.
**Tasks** — `createTask(task)` unshift; `toggleTaskCompletion({taskId,userId})` toggles membership in `completedBy`.
**Notifications** — `markNotificationRead(id)`, `markAllNotificationsRead()`, `addNotification(n)` (unshift).
**Sales** — `recordSale(sale)`: current user must be `quality`; the lead must exist; unshift `{...sale, leadName: lead.companyName}`. `deleteSale(id)`: quality only; filter out.

**Email**
* `sendEmailForLead({email, leadId, touchPointOrder})`: if `leadId` is given the lead must exist and be owned by me (else no-op). Unshift the log with `sentBy = currentUserId || email.sentBy`. If no lead → stop. If the touch point at `touchPointOrder` is an **open email** step and the lead is workable → complete it and re-point. Always push history `email_sent` / `"Email sent to {to}"` with meta `{emailLogId, subject}` (with the tp). A *free* email uses `touchPointOrder: -1` (workflow untouched).
* `sendBulkEmailForLeads({leadIds, subject, body, senderId, senderName})`: for each unique id: lead must exist, be owned by me, workable, and have a **valid email**; else skipped. Sender name = current user's name (fallback payload). Log: `templateType 'custom'`, `to = lead.email`, subject/body filled via `fillEmailTemplate`. Only if the lead's **current** touch point is an open email step it is completed + re-pointed. History `bulk_email_sent` / `"Email sent to {email}"`.
* `sendStandaloneEmail({to, subject, body, senderId, senderName})`: unshift log with `leadId ''`, `leadName ''`, `templateType 'custom'`.

### 6.4 Scheduler (`runScheduledJobs`, every 30 s while signed in)

Order inside the reducer: `runMeetingDayEndJob(state)`, `runLeadExpiryJob(state, now)`, `runMeetingReminderJob(state, now)`, then `runAutoEmailJob(state, now)` if `AUTO_EMAIL_ENABLED`.
`useSchedulerTick(isSignedIn)`: when signed in it dispatches once immediately and then `setInterval(30000)`; cleans up on sign-out/unmount.

1. **`meetingDayEndJob`**: for every lead with `status 'arranged_meeting'` call `returnLeadToQueueWhenMeetingEnds(state, lead, 'Meeting day ended with no result', false)`.
2. **`leadExpiryJob`**: for each lead: skip if already expired or removed; skip if `!stopped` and no open touch point (finished workflow); skip if it has an `arranged` meeting dated today or later (paused by a meeting); skip if `now − expiryReferenceMs(lead) < 15 days`. Else `expiredAt = now` and system history `expired_15_days` / `"No progress for 15 days - removed from {agent name or 'the agent'}'s queue, waiting for the Team Leader to reassign"`. (Stopped leads also expire.)
3. **`meetingReminderJob`**: for each meeting with status `arranged` and no `reminderSentAt`: `start = meetingStartMs`; skip if NaN or `now < start − 15 min`. **Mark `reminderSentAt = now` first** (never twice). If `now >= start + duration min` → no notification (already over). Else `mins = ceil((start − now)/60000)`; for each distinct user in `participantIds ∪ {createdBy}` unshift a `meeting` notification: title `Meeting in {mins} minute(s)` (`'minute'` singular when 1) or `Meeting starting now` when `mins ≤ 0`; message `"{title} at {time}"`; `leadId`, `meetingId`, `userId`.
4. **`autoEmailJob`**: for each lead that is not stopped / removed / expired and **has an email**: its current touch point must be an **open email** step with `dueDate <= now`. `idempotencyKey = "auto|{lead.id}|{round ?? 1}|{tp.order}"` — skip if any email log already has it. Template type = `discovery` if `effectiveCallType(lead) === 'discovery'` else `no_response`; template must exist. Agent name from `lead.agentId`. Unshift an `EmailLog` `{ …, templateType: type, sentAt: now, sentBy: lead.agentId, sentByName: agentName, auto: true, idempotencyKey }` with subject/body filled. Complete the touch point, re-point, system history `auto_email_sent` / `"{template name} sent to {email}"` with meta `{emailLogId, templateType}` and unshift a notification `{type:'email', title:'Email sent automatically', message:"{company}: {tp.label}", leadId, userId: lead.agentId, read:false}`. A call step never auto-skips; no email address → nothing sent and the step stays open.

### 6.5 Seed (demo) data

`createInitialState()` → `currentUserId ''`, users, teams, workflows, leads, `meetings/updates/tasks/emailLogs/notifications/sales = []`, templates.

**Users** (`id | username | name | email | role | team | initials | color | dailyCallTarget`):
| id | username | name | email | role | teamId | initials | color | target |
|---|---|---|---|---|---|---|---|---|
| u-admin | admin | System Admin | admin@company.com | admin | — | SA | #475569 | 0 |
| u-om | ahmed.om | Ahmed Hassan | om@company.com | operation_manager | — | AH | #1e40af | 0 |
| u-tl1 | sara.tl | Sara Mahmoud | sara@company.com | team_leader | t-1 | SM | #0d9488 | 0 |
| u-tl2 | omar.tl | Omar Khaled | omar@company.com | team_leader | t-2 | OK | #0891b2 | 0 |
| u-a1 | mona.agent | Mona Ali | mona@company.com | agent | t-1 | MA | #e11d48 | 90 |
| u-a2 | khaled.agent | Khaled Mostafa | khaled@company.com | agent | t-1 | KM | #ea580c | 90 |
| u-a3 | nour.agent | Nour Ibrahim | nour@company.com | agent | t-2 | NI | #0284c7 | 90 |
| u-a4 | yousef.agent | Yousef Adel | yousef@company.com | agent | t-2 | YA | #16a34a | 90 |
| u-q1 | hana.quality | Hana Samy | hana@company.com | quality | — | HS | #7c3aed | 0 |

**Teams:** `t-1 "Team Alpha"` leader `u-tl1` agents `[u-a1,u-a2]` manager `u-om`; `t-2 "Team Beta"` leader `u-tl2` agents `[u-a3,u-a4]` manager `u-om`.

**Workflows:**
* `w-1`, code `ACT-001`, name **"Activation Campaign"**: `0 call "Initial Call" +0`, `1 email "Follow-up Email" +1`, `2 call "Second Call" +2`, `3 email "Second Email" +4`, `4 call "Final Call" +5`, `5 email "Final Email" +7`.
* `w-2`, code `RET-002`, name **"Retention Campaign"**: `0 call "Outreach Call" +0`, `1 email "Welcome Email" +1`, `2 call "Check-in Call" +3`, `3 email "Offer Email" +5`.

**Email templates:**
* `et-1` "Discovery Follow-up", type `discovery`, subject `Following up on our conversation`, body `Dear [Name],\n\nThank you for your interest in our services. Following up on our recent conversation, I have attached additional details about our activation plan.\n\nBest regards,\n[Agent Name]`.
* `et-2` "No Response Follow-up", type `no_response`, subject `Reaching out - [Company Name]`, body `Dear [Name],\n\nI hope this email finds you well. I tried reaching you recently regarding our services. I would love to connect at your convenience.\n\nBest regards,\n[Agent Name]`.

**Leads (52 total).** Helper `day(offset)` = ISO of today ± offset days. Index `i` runs 0…51 through a counter `n`.
* `mkLead(i)`: `id l-{i+1}`; `leadCode LD` + zero-padded 3-digit `i+1` (LD001…); `campaignCode = i%2===0 ? 'ACT-001' : 'RET-002'`; `companyName = COMPANIES[i % 40]`; `contactName = CONTACTS[i % 10]`; `phone = "+20 1{i%3} {String(100+i).padStart(3,'0')} {String(1000+i*37).slice(-4)}"`; `email = "contact{i+1}@{company lowercased with non a-z removed}.com"`; `status 'new'`, `stopped false`, `removedFromQueue false`, `removedAt null`.
* **COMPANIES (40, in order):** Red Sea Shipping, Oasis Farms, Memphis Textiles, Nubian Dairy, Delta Steel Works, Cairo Print House, Pharaoh Foods, Aswan Ceramics, Sinai Mining, Giza Plastics, Nile Pharma, Alex Marine Services, Luxor Tours, Suez Logistics, Tanta Cotton Mills, Mansoura Electronics, Hurghada Diving Co, Fayoum Olive Oil, Siwa Dates, Port Said Trading, Ismailia Cement, Sharm Resorts Supply, Zamalek Design Studio, Maadi Software House, Heliopolis Dental Group, Nasr City Auto Parts, October Furniture, Obour Packaging, Shorouk Real Estate, Rehab Catering, Damietta Furniture, Minya Sugar, Assiut Cables, Sohag Textiles, Qena Pottery, Beni Suef Cement, Kafr El Sheikh Rice, Beheira Poultry, Sadat Industrial Group, Borg El Arab Steel.
* **CONTACTS (10):** Karim Nabil, Dina Fathy, Adel Samir, Salma Reda, Hossam Aly, Mariam Zaki, Tarek Fawzy, Heba Lotfy, Wael Saad, Nada Emad.
* **First 12 leads (3 per agent, agents in user order u-a1…u-a4)**, stages: `{done 0}`, `{done 1, lvm "Left a voicemail, asked for a call back."}`, `{done 2, discovery "Interested, asked for more details."}`. For stage index `k` (0..2): `assignedAt = day(-(k+2))`; touch points via `makeTouchPoints(workflow, done)`: orders `< done` are `completed` with `completedAt = dueDate = day(-5 + order)`; the others get `dueOffset = done===0 ? 0 : tp.dayOffset − workflow.touchPoints[done−1].dayOffset`, `dueDate = day(dueOffset)`, `status = overdue` if that date is before now else `pending`. `currentTouchPoint` = first pending/overdue order (or −1). If the stage has a call: one call log `{id 'cl-{n}' (n = the lead's 1-based number, i+1; history id is 'h-{n}'), type, description, timestamp day(-(k+1)), touchPointOrder 0, agentId, agentName, touchPointLabel: workflow.touchPoints[0].label, round 1}` and `status = call type`; `discoveryReached = (type === 'discovery')`; `lastActivityAt = assignedAt`; history = one entry `{id 'h-{n}', action 'taken_from_pool', timestamp assigned, userId agent.id, userName agent.name, detail "Taken from the pool by {name}", round 1, agentId}`.
* **Next 40 leads = the shared pool:** `agentId ''`, `assignedAt day(-1)`, empty touchPoints/callLogs, `currentTouchPoint -1`, history `{id 'h-pool-{k}', action 'created', timestamp day(-1), userId 'u-admin', userName 'System Admin', detail 'Lead created by the Admin (in the pool)'}`.
  (Result: lead codes LD001–LD012 held by agents, LD013–LD052 in the pool.)

---

## 7. Application shell, roles and navigation

### 7.1 `App.tsx`
* `const [page, setPage] = useState<PageId>('dashboard')`. `useSchedulerTick(!!state.currentUserId)`.
* No `currentUserId` → render `<LoginPage onLogin={() => {}} />` (the login page dispatches `setCurrentUser` itself).
* Otherwise `role = users.find(currentUserId).role`; `currentPage = role && !canOpenPage(page, role) ? homePageFor(role) : page` — so a page left open by the previous person is replaced by the new role's home page (e.g. admin never sees `dashboard`).
* Renders `<AppShell currentPage onNavigate={setPage} onLogout={() => dispatch(setCurrentUser(''))}>` and exactly one of: `adminleads→LeadPoolPage`, `dashboard→DashboardPage`, `workqueue→WorkQueuePage`, `calendar→CalendarPage`, `leads→MyLeadsPage`, `updates→TeamUpdatesPage`, `tasks→TasksPage`, `emails→EmailCenterPage`, `sales→SalesPage`, `analytics→AnalyticsPage`, `teams→TeamsPage`.
* Logging out does not clear data; the `page` state is kept (see above).

### 7.2 `navigation.ts`
`PageId = 'adminleads'|'dashboard'|'workqueue'|'calendar'|'leads'|'updates'|'tasks'|'emails'|'sales'|'analytics'|'teams'`. `ALL_ROLES = ['operation_manager','team_leader','agent']`.

`NAV_ITEMS` in this **display order**:
| id | label | icon | roles |
|---|---|---|---|
| adminleads | Lead Pool | Database | admin |
| dashboard | Dashboard | LayoutDashboard | OM, TL, agent |
| analytics | Analytics | BarChart3 | OM, TL, agent |
| teams | Teams | Network | admin, OM, TL, agent, quality |
| workqueue | Work Queue | Inbox | agent |
| calendar | Calendar | Calendar | OM, TL, agent |
| leads | Leads | Users | agent |
| sales | Sales | Trophy | OM, TL, agent, quality |
| updates | Team Updates | Bell | OM, TL, agent |
| tasks | Tasks | CheckCircle2 | OM, TL, agent |
| emails | Email Center | Mail | OM, TL, agent |

`homePageFor(role)`: quality → `sales`; admin → `adminleads`; everyone else → `dashboard`. `canOpenPage(page, role)` = the item exists and lists the role.

### 7.3 `AppShell`
Layout `div.flex.h-screen.bg-slate-50.text-slate-900` → `Sidebar` + `div.flex-1.min-w-0.flex.flex-col.overflow-hidden`. If the current user isn't found it renders `null`.
* `myNotifications = notifications.filter(n => !n.userId || n.userId === me.id)`; `unreadCount = myNotifications.filter(!read).length`.
* `navItems = NAV_ITEMS.filter(roles includes me.role)`.
* **Top bar** `header.h-16.bg-white.border-b.border-slate-200.flex.items-center.justify-between.px-6`: left `h1.text-lg.font-bold.tracking-tight` = label of current page; if the user is an **agent** and has a team, a pill `text-xs font-medium text-slate-600 bg-slate-100 px-2.5 py-1 rounded-full` with the team name. Right: `NotificationsMenu` and `UserMenu`.
* `main.flex-1.overflow-y-auto.scrollbar-thin` renders the page.

### 7.4 `Sidebar`
`aside` `w-[72px] lg:w-60 bg-white flex flex-col shrink-0 border-r border-slate-200` (icons only below `lg`).
* Brand row `h-16 px-4 lg:px-5 … border-b`: blue square `w-9 h-9 bg-blue-600 rounded-xl shadow-sm` with `TrendingUp` white icon; beside it (hidden below lg) **"SalesFlow"** (`font-bold text-[15px] tracking-tight text-slate-900`) over **"Unified Sales"** (`text-xs text-slate-500`).
* `nav` `aria-label="Main"`: one `button` per item, `title={label}`, `aria-current="page"` when active. Active: `bg-blue-50 text-blue-700`, a `w-1 rounded-r-full bg-blue-600` bar on the left edge, icon `text-blue-600` with `strokeWidth 2.25`. Inactive: `text-slate-600 hover:text-slate-900 hover:bg-slate-100`, icon `text-slate-400`. Label `hidden lg:inline`.
* **Badge quirk:** only the **`updates`** item shows a rose pill with `unreadCount` (the count of ALL unread notifications of the user, not just updates) when `> 0`.
* Footer: rounded `bg-slate-50` card with avatar (`style backgroundColor = user.color`, initials, `ring-2 ring-white`), name (truncate) + role label, and (lg only) a sign-out icon button (`LogOut`, `title/aria-label "Sign out"`, hover rose).

### 7.5 `NotificationsMenu`
Bell button (`w-9 h-9 rounded-lg hover:bg-slate-100`, `aria-label="Notifications"`, `aria-expanded`) with a small rose dot `animate-pulse-ring` when `unreadCount > 0`. Opening shows a fixed transparent overlay (click to close) and a `w-80` panel `absolute right-0 top-full mt-2 … animate-slide-up`: header "Notifications" + link-button "Mark all read" (`markAllNotificationsRead`, which marks **every** notification in the store, not only the user's); list `max-h-80 overflow-y-auto`; empty text "No notifications". Each item is a button: marks it read; if `n.meetingId` → navigate to `calendar`, else if `n.leadId` → `workqueue`; closes the menu. Unread items `bg-blue-50/40` plus a `w-2 h-2 bg-blue-500` dot. Icon tile `w-8 h-8 rounded-lg` — `overdue` rose, `meeting` violet, others slate. `notificationIcon(type)`: meeting→Calendar, email→Mail, overdue→AlertTriangle, update→Bell, task→CheckCircle2, default Bell.

### 7.6 `UserMenu`
Button with avatar (`w-7 h-7`), first name (hidden < sm), `ChevronDown`. Panel `w-56`: name, email, role pill `bg-blue-50 text-blue-700`, and a red "Sign out" row.

---

## 8. Shared components

* **`UserAvatar({user, size='w-9 h-9'})`** — circle with `backgroundColor: user.color`, white `text-xs font-semibold` initials.
* **`ConfirmDialog` / `useConfirm()`** — Used for *every* destructive/workflow-changing action. `const { ask, dialog } = useConfirm(); ask({title, message: ReactNode, confirmLabel='Confirm', tone: 'danger'|'warning'='warning'}, action)`; render `{dialog}` once. Modal: `fixed inset-0 z-[80]`, overlay `bg-slate-900/60 backdrop-blur-sm animate-fade-in` (click = cancel), card `max-w-sm rounded-2xl p-6 animate-slide-up`; circular icon (`AlertTriangle`) rose for danger / amber for warning; title `text-lg font-bold`; message `text-sm text-slate-600`; **Cancel** (autofocus, ghost) and a coloured confirm button (rose-600 / amber-600). `Escape` cancels. The action runs only after Confirm.
* **`ErrorBoundary`** (class) — on render error shows a centred card: rose circle with `AlertTriangle`, **"Something went wrong"**, "This screen hit an unexpected error. Your data is safe — nothing was deleted.", buttons **Try again** (resets error state) and **Reload** (`window.location.reload()`). Logs `'Screen crashed:'`.
* **`StorageBanner`** — listens to window events `crm:persist-failed` / `crm:persist-ok`; when failed shows a fixed rose banner (`bottom-4 left-1/2 -translate-x-1/2 z-[100] w-[min(92vw,34rem)] bg-rose-600 text-white rounded-xl shadow-2xl`) with the text "Your latest changes could not be saved (browser storage is full or blocked). Download a backup so nothing is lost." and a **Backup** button that downloads `crm-backup-YYYY-MM-DD.json` containing `JSON.stringify(store.getState().crm, null, 2)`.
* **`LeadPicker({leads, value, onChange, placeholder='Search by lead name, code or email...'})`** — searchable combobox. Filter (case-insensitive, `includes`) over company, contact, lead code, email, and phone (spaces removed on both sides). Shows at most **50** results with the footer `"Showing 50 of {total} — keep typing to narrow it down"`; empty → `No leads match “{query}”`. Keyboard: ↓ opens/moves, ↑ moves, **Enter** chooses the highlighted item, **Esc** closes; active index resets on query change and is scrolled into view; closes on outside `mousedown`. When a value is selected and the list is closed it renders a button row: mono lead-code chip + company + contact + an **X** (`aria-label="Clear linked lead"`) that calls `onChange('')`. Rows: lead-code chip (`font-mono text-xs bg-slate-100`), company (truncate), contact (right, `text-xs text-slate-500`).
* **`AgentPicker({agents, teams, value, onChange, placeholder='Search an agent or choose from the list...'})`** — same interaction, options = every agent that belongs to a team, **grouped by team** (a small `text-[11px] font-semibold` team header appears when the team changes). Filter on name, username, team name. Selected state shows avatar + name + clear X (`aria-label="Clear agent"`). Empty text `No agents match “{query}”`.

---

## 9. Pages (screens)

### 9.1 Login (`features/auth/LoginPage.tsx`)
* Layout `min-h-screen flex bg-slate-50`. **Left brand panel** (only ≥ lg, `lg:w-[46%] bg-slate-950`, two blurred glow circles blue/cyan): logo (`TrendingUp` in a blue-500 tile) + **SalesFlow**; headline **"Unified Sales / Management Platform"** (`text-4xl xl:text-[2.6rem] font-extrabold`, two lines); sub-text "Manage leads, workflows, touch points, meetings, and team communication — all in one place."; status pills New / Discovery / LVM / NVM / No Response / Meeting with coloured dots (slate-400, emerald-400, amber-400, amber-400, rose-400, violet-400); and three feature rows (Phone: "Structured call workflows with touch points", Mail: "Automated email templates and bulk sending", Calendar: "Meeting scheduling with calendar integration").
* **Right panel:** mobile logo, **"Welcome back"** / "Select your profile to sign in". A `role="radiogroup"` list of **all users** (avatar, name, `@username`, role pill, radio circle with a check when selected; selected row `border-blue-500 bg-blue-50 ring-1 ring-blue-500`). A **Password** input (`id login-password`, placeholder "Enter your password", **visual only**, not validated). A full-width blue button: `Sign in as {FirstName}` or `Sign In` when nobody is selected; disabled until a user is chosen. Footer: "This is a visual prototype — no real authentication". Clicking dispatches `setCurrentUser(user.id)`.

### 9.2 Dashboard (`DashboardPage`)
Chooses by role: **agent → `AgentDashboard`**, **team_leader → `TeamLeaderDashboard`**, everyone else (OM) → `OperationManagerDashboard`. Container `p-4 sm:p-6 max-w-6xl mx-auto`.

Helper `dashboardCallStats`: `isTodayDate(s)` compares **UTC** date strings (`s.split('T')[0] === new Date().toISOString().split('T')[0]`); `countCallsByType(logs, filter?)` → `{nvm,lvm,discovery,total}`; `countCallsMadeToday(logs)` = counts of logs made today (UTC day of `timestamp`).

**AgentDashboard** (props: currentUser, leads, meetings, emails, users, salesThisMonth where `salesThisMonth` = this agent's sales whose date starts with the current month key):
1. Title **"My Dashboard"** + today's date `weekday long, month long, day numeric` (en-US).
2. `TodayMeetingsCard` (violet) of the agent's meetings where `participantIds` includes the agent, status `arranged`, and date is today.
3. **Today's Call Progress** card: `Target` icon, `"{todayCalls.total} / {dailyCallTarget}"`, progress bar `h-3 bg-slate-100` fill `bg-blue-600` (emerald at ≥ 100%), `width: max(pct, 2)%`, caption `"{round(pct)}% of daily target"` (pct capped at 100, 0 when target is 0). Calls counted from the agent's leads that are **not removed and not expired**.
4. **"Today's Call Breakdown"** → `CallBreakdown` (4 cards: Total Calls (blue, Phone), Discovery (emerald, UserCheck), LVM (amber, Voicemail), NVM (amber, PhoneOutgoing)).
5. Three `StatCard`s: **Emails Sent Today** (emails with `sentBy === me` and sent today; violet Mail), **Meetings Today** (violet Calendar), **Sales This Month** (amber Trophy).

**TeamLeaderDashboard:** title `"{team name} Dashboard"` + date; `{confirmDialog}`; `TodayMeetingsCard` titled **"Team Meetings Today"** (arranged, today, and either a lead meeting whose `agentId` is in the team, or the TL participates/created it); if the team has **expired leads** (`expiredAt` set, not removed, held by a team agent) a rose-tinted card **"Needs reassignment (N)"** with the note "No progress for 15 days. The new agent starts from touch point 1; the old history is kept." and one `ReassignRow` per lead (lead code — company; "With {owner} • left the queue {date}"; a `<select>` of the *other* team agents defaulting to the first; **Reassign** button). Reassign asks for confirmation (*"Reassign this lead?"* — "<b>{company}</b> will move to <b>{agent}</b> and start again from touch point 1. The old history is kept." — confirm "Reassign") then dispatches `transferLeadToAgent`. Then **"Agent Performance — Today"**: one card per team agent: avatar, name, `@username`, a thin progress bar and `"{calls}/{target}"`, then a 6-cell grid: **Calls (blue), Disc. (emerald), LVM (amber), NVM (amber), Emails (violet), Meet. (violet)** (emails = that agent's emails today; meetings = `lead_meeting`, arranged, today, agent participates).

**OperationManagerDashboard:** title **"Operations Overview"** + date; `TodayMeetingsCard` **"Meetings Today"** (all arranged meetings dated today); **"Team Leader Performance — Today"**: for each team leader (team via `tl.teamId`): avatar, name, `"@username • {team} • {n} agents"`, progress bar `h-2.5` of today's calls vs the sum of the team agents' `dailyCallTarget` with label `"{calls}/{target} ({pct}%)"`, and the same 6-cell grid (team emails today by agent ids; team lead-meetings today by `m.agentId`).

`TodayMeetingsCard({meetings, users, title="Today's Meetings"})`: violet-50 panel; heading with Calendar icon `"{title} ({count})"`; empty → "No meetings today."; rows sorted by `time` showing time (bold violet) + `"{duration}min"`, the meeting title and a "who" line (lead meeting: `company • agent name`; internal: participant names).

### 9.3 Work Queue (`features/work-queue`, agent only) — the main working screen

**State in `WorkQueuePage`:** `selectedLeadId`, `callLeadId`, `emailLeadId`, `deleteLeadId`, `showTake`; collapsible-section state (`useCollapsibleSections`); `now` (a live clock refreshed every **30 s** so a lead moves from Next to Today by itself); `useConfirm`. **Only ids are stored** and the live lead is always re-read from `state.leads`, so modals/drawers never act on a stale copy.

**Data:** `myLeads = leads.filter(!removedFromQueue && !expiredAt && agentId === me.id)` (expired leads leave the queue; removed leads leave). `queue = buildWorkQueue(myLeads, workflows, now)`. `arrangedMeetingsToday` = meetings with `type 'lead_meeting'`, `date === new Date().toISOString().split('T')[0]` (UTC date string), `status 'arranged'`, and `participantIds` containing me. Totals: `todayTotal`, `nextTotal` (sum of campaign counts), `stoppedTotal`, `overdueCount` = leads in bucket `today` whose `describeDueDate(currentTP).tone === 'overdue'`.

**Page layout (top→bottom, container `p-4 sm:p-6 max-w-7xl mx-auto`):**
1. `WorkQueueStats` — 5 cards (`grid-cols-2 lg:grid-cols-5 gap-4 mb-6`): **Today** (blue-200 border, number `text-blue-600`), **Overdue** (`text-rose-600`), **Next** (`text-slate-700`), **Stopped** (`text-amber-600`), **Meetings Today** (`text-violet-600`, `col-span-2 lg:col-span-1`). Card: `bg-white rounded-xl border p-4`, label `text-sm text-slate-600`, value `text-2xl font-bold`.
2. `TodayMeetingsBanner` (only if ≥ 1): violet panel "Arranged Meetings — Today", two-column grid of buttons (violet square with Calendar icon, company name, `"{contact} — {time}"`); clicking opens the lead's detail drawer if the lead is still there.
3. Search row: a `LeadPicker` over `myLeads` (placeholder "Search a lead by name, code, email or phone, then select it...", selecting opens the drawer) and a blue **Take Leads** button (Download icon) that opens `TakeLeadsModal`.
4. The queue: if empty → centred Inbox icon + "No leads in your work queue" + "Use “Take Leads” to get leads from the pool."; else one `CampaignSection` per campaign.
5. Overlays: `LeadDetailDrawer`, `CallLogModal`, `TouchPointEmailModal`, confirm dialog, `DeleteLeadModal`, `TakeLeadsModal`.

**`buildWorkQueue(leads, workflows, now)`** → `CampaignQueue[]` sorted by campaign display name: group leads by `campaignCode`; per lead `queueBucket`: `stop` → `stopped[]`; `finished` → `finished[]`; else take the current touch point, create/get a `TouchPointStepGroup {order,type,label,byCategory,total}` inside the `today` or `next` map (key = tp.order) and push the lead into `byCategory[queueCategory(lead)]`. Steps are sorted by `order`; inside each category leads are sorted by **oldest due date first**. Result per campaign: `{code, name (campaignLabel), today[], next[], todayCount, nextCount, stopped[], finished[], total}`. Category display order: `new, discovery, lvm, nvm, meeting`.

**Hierarchy of collapsible blocks:** Campaign → (Today | Next | Stop | Workflow finished) → Step ("1: CALL") → Category (New / Discovery / LVM / NVM / Meeting) → lead rows. `useCollapsibleSections` stores only the keys the user **flipped** from their default (`isOpen(key, defaultOpen)`): defaults are **campaign open, Today open, Next closed, Stop closed, Workflow finished closed, step open, category open**. Keys: `{code}`, `{code}|today|next|stop`, `{code}|done`, `{code}|{bucket}|{order}`, `…|{category}`.

**`CampaignSection`:** white card; header button (chevron, campaign name `text-base font-bold`, right-side pills `Today N` (blue-100/blue-700), `Next N` (slate-100/slate-600), `Stop N` only when > 0 (amber-100/amber-700)). Body: three `QueueBucketSection`s + the **"Workflow finished"** emerald block (hidden when empty; count pill; closed by default; rows are `QueueLeadRow` with `bucket="finished"`).

**`QueueBucketSection`** styles (`QUEUE_BUCKET_STYLE`): *Today* — icon Sun, hint "due today or overdue", border `border-blue-200`, header `bg-blue-50 hover:bg-blue-100/70`, text `text-blue-800`, pill `bg-blue-600 text-white`; *Next* — Hourglass, "tomorrow or later", `border-slate-200`, `bg-slate-50 hover:bg-slate-100`, `text-slate-700`, pill `bg-slate-600 text-white`; *Stop* — PauseCircle, "workflows you stopped", `border-amber-200`, `bg-amber-50 hover:bg-amber-100/70`, `text-amber-800`, pill `bg-amber-500 text-white`. Empty messages: "Nothing due today in this campaign." / "Nothing coming up." / "No stopped workflows.". Stop rows are `StoppedLeadRow`.

**`TouchPointStepSection`:** header shows a round icon (cyan for call/Phone, violet for email/Mail), `stepLabel` (e.g. "1: CALL") bold, the step label (e.g. "Initial Call") muted, and a count pill. Inside, only non-empty categories, each with a coloured dot (`QUEUE_CATEGORY_STYLE`: new slate, discovery emerald, lvm amber labelled "LVM", nvm amber labelled "NVM", meeting violet "Meeting"), label and count pill.

**`QueueLeadRow`:** left: lead-code chip, Building2 icon, company; second line: contact (User icon); **"Leaves queue in Nd" / "Leaves queue today"** (amber, Hourglass) when `daysUntilExpiry(lead, now) <= 3` and the lead is not in a meeting; **"No email - can't auto-send"** (rose, AlertCircle) when the step is an email and the lead has no email; the due label from `describeDueDate` (Phone/Mail icon, tone colours `overdue: text-rose-600 font-medium`, `today: text-amber-600 font-medium`, `later/none: text-slate-500`). Right (md+): for `next` rows **"Today in {formatDuration(startOfDueDay − now)}"**; for `today` rows either `"Waiting {formatDuration(now − due)}"` (rose, when overdue) or **"Your turn now"** (blue); and always `"Last touch {…} ago"` or `"No touch yet"`. Actions: only in **Today** — a coloured button **"Mark Call"** (cyan-600) / **"Mark Email"** (violet-600), or rose-600 when overdue, plus a skip icon button (`SkipForward`, `title/aria-label "Skip this touch point"`); in all buckets a **Details** ghost button.

**`StoppedLeadRow`:** `"Stopped at {stepLabel} · {label}"` or "Stopped after finishing all touch points"; buttons **Resume** (emerald, Play), **Delete** (rose ghost, Trash2 → opens DeleteLeadModal), **Details**.

**Mark Call/Email handler:** `tp.type === 'call'` → `CallLogModal`, else `TouchPointEmailModal`. **Skip** → confirm *"Skip this touch point?"* — "Step <b>{stepLabel}</b> ({label}) for <b>{company}</b> will be skipped and the lead moves to the next step. You can restore it later." — confirm label "Skip" → `skipTouchPoint`.

**`CallLogModal`** (z-60, `max-w-md`): title **"Log Call"**, subtitle `"{company} — {contact}"`. **Call Type** – three big selectable cards (default **NVM**): `NVM` "No Voicemail" (amber), `LVM` "Left Voicemail" (amber), `Discovery` "Client Responded" (emerald); selected card shows its coloured border/background, unselected `border-slate-200`. **Call Description** textarea (rows 4, placeholder "What happened during the call?", hint "Required — this will be used for AI analysis"). Buttons: **Cancel**, **Save & Mark Complete** (disabled while the description is blank). On save the page dispatches **one** `logCallAndCompleteTouchPoint({ leadId, log: { id: randomUUID, type, description: trim, timestamp: now ISO, touchPointOrder: lead.currentTouchPoint } })` and closes.

**`TouchPointEmailModal`** (`max-w-lg`): title **"Send Email"**; "Start from:" pill toggle between **Blank** (`custom`, default) and the suggested template (**Discovery template** when the queue category is `discovery`, else **No Response template**); choosing a template copies its subject/body *unfilled* (placeholders are not substituted here); **To** (prefilled with `lead.email`), **Subject**, **Message** (monospace, rows 8). Button **"Send & Mark Complete"** (violet, Send icon) disabled unless `to` and `subject` are non-blank. On send the page dispatches `sendEmailForLead({ email: { id, leadId, leadName: company, to, subject, body, templateType, sentAt, sentBy, sentByName }, leadId, touchPointOrder: lead.currentTouchPoint })`.

**`LeadDetailDrawer`** (right-side drawer, `max-w-lg`, `animate-slide-in`, overlay `bg-black/30`): sticky header with lead code (`text-lg font-bold`), `"{company} • {contact}"`; badges **Stopped** (amber) and the status badge; a **⋮ menu** — if stopped: *Resume Workflow* (emerald), *Delete Permanently* (rose); else: *Schedule Meeting*, *Stop Workflow* (amber, Ban), *Remove from Queue* (rose, XCircle); then a close button. If stopped, an amber banner "This workflow is stopped. Resume it to bring the lead back to the queue, or delete it." with a **Resume** button. Sections: contact grid (Phone, Email, Agent name, Queue category); **Workflow Touch Points** timeline (each step: status circle — completed emerald check, skipped SkipForward, else Phone/Mail (rose when overdue); title `"{order+1}. {label}"` (line-through if skipped); subtitle `Completed {date}` / `Skipped {date}` / `Due {date}` + "• Overdue" / `Pending`; current step highlighted `border-blue-300 bg-blue-50/50` when not stopped; when not stopped: on the current open step a **"Log Call"/"Send Email"** button, on any open step a skip icon, on a skipped step a **Restore** button (Undo2)); **Call History (N)** (type badge + `toLocaleString()` time + description, or "No calls logged yet"); **Activity History** (dot, bold user name, `action` with `_`→space, ` • detail`, timestamp). Confirmations used by the page: *Stop this workflow?* ("<b>{company}</b> leaves Today / Next and moves to Stop. You can resume it later." → "Stop workflow"); *Remove from queue?* ("<b>{company}</b> leaves your work queue and your leads and will not continue its steps. Its history and activity are kept, and its lead ID becomes free for anyone to add again." → "Remove", danger, then closes the drawer). **Schedule Meeting** only closes the drawer (the agent continues in Calendar).

**`DeleteLeadModal`** (z-70, `max-w-sm`): trash icon; **"Delete this lead?"**; `"{code} — {company} will be deleted permanently with its call history and activity log. Its arranged meetings will be cancelled. This can’t be undone."`; if the lead has a sale an amber note: "This lead has a recorded sale, so it can’t be deleted. Use “Remove from queue” instead — the sale and its history stay intact." and the **Delete permanently** button is disabled. Confirm dispatches `deleteLeadPermanently`, closes the modal and the drawer.

### 9.4 Take Leads (`features/take-leads/TakeLeadsModal.tsx`)
Opened from Work Queue and from Leads. Props: `leads, users, workflows, me, onTake(ids), onClose`. `max-w-lg`, z-60. Title **"Take Leads"** / "Get leads from the shared pool into your work queue". Two tabs: **Search by exact ID** (default) and **Type / paste IDs**; switching tabs clears the result report.
* **Search tab:** input "Type the full lead ID, e.g. LD013" (autofocus). The pool is **never listed**. Normalized query must equal a pool lead's normalized code (`ld-013` finds `LD013`; `LD01` finds nothing). Hints: when empty "Leads are not listed. Write the exact ID of the lead you want and it will show up here."; found → a checkbox row (code chip, company, campaign label); held by someone → amber "`{CODE}` exists but is held by {you | name | another agent}."; typed but nothing → "No lead with this exact ID in the pool". Checked leads accumulate in a **Selected (N)** list with a per-row **Remove**. Button **"Take N lead(s)"** (disabled with none) calls `onTake(ids)` and then shows a **report** built with `planTakeFromPool`.
* **Paste tab:** explanatory text "Write or paste the lead IDs one under the other. All of them are added automatically - no need to pick each one."; monospace textarea (placeholder `LD012\nLD013\nLD014`). Live summary `"{n} ready"` (emerald) `· {m} with a problem` (rose) and a list of problem rows (max 50 + "…and N more"). Button **"Take N lead(s)"** takes all `ready` ones (`plan` ids) then shows the report and clears the text.
* **Report:** box with `"{n} added"` and `" · {m} not added"` plus rows (`ClaimResultRow`: green CheckCircle2 + code + "Added", or red AlertCircle + code + reason; `taken` shows `Held by {name}`).
* Footer: **Close** + the take button. The store re-checks everything on `takeLeadsFromPool`.

### 9.5 Leads (`features/my-leads/MyLeadsPage.tsx`, agent only)
Header: **"My Leads"** and `"{n} leads"` + a blue **Take Leads** button. Filters: `LeadPicker` over the agent's visible leads (selecting opens the drawer), a **Campaign** select ("All Campaigns" + each campaign code shown via `campaignLabel`) and a **Status** select ("All Statuses" + every key of `LEAD_STATUS_STYLE`). Visible leads = `agentId === me && !removedFromQueue` (expired and stopped leads **do** appear) filtered by campaign and status.
Table columns: **Lead Code** (mono chip), **Company** (Building2 + name), **Contact** (name + phone or "No phone"), **Campaign** (chip), **Status** (status badge + a rose **Expired** badge when `expiredAt`), **Progress** (`h-1.5` bar of completed / total touch points + "x/y"), **Actions** → **Details**. Empty: Users icon + "No leads found".
**Details drawer** (inline in this file, `max-w-lg`): header, grid (Phone, Email, Lead Code, Status badge), **Touch Points Progress** (each step with Phone/Mail icon, label and a status chip: completed emerald else slate), **Call Logs** (only when any), **Activity History**. Footer actions (only when not removed and not expired): **Resume Workflow** (emerald) if stopped, else **Stop Workflow** (amber, confirm *"Stop this workflow?"* — "<b>{company}</b> will stop moving through its touch points. You can resume it later." → "Stop workflow"); and **Remove Lead** (rose, confirm *"Remove this lead?"* — "<b>{company}</b> leaves your leads and will not continue its steps. Its history and activity are kept. It goes back to the shared pool and its lead ID becomes free for any agent to take again." → "Remove lead", danger). The drawer reads the live lead by id.

### 9.6 Lead Pool (`features/lead-pool/LeadPoolPage.tsx`, admin only)
Header **"Lead Pool"** with `"{total} leads · {poolCount} waiting in the pool for an agent"` (`poolCount = leads.filter(isInPool)`). Buttons (right): **Delete selected (N)** (rose, only when something is selected), **Add One Lead** (outlined, Plus), **Paste Leads** (blue, Upload).
Search box "Search by lead ID, company or contact..." (matches normalized code `includes`, or company/contact `includes` lower-case) and a select **All leads / In the pool / Held by an agent**.
Table (first **300** rows, footer "Showing 300 of N - search to narrow it down"): checkbox column (disabled with tooltip "Has a recorded sale - cannot be deleted" for sold leads; header checkbox selects/clears all *deletable shown* rows), **Lead ID, Company (Building2), Contact, Phone, Email, Campaign, Held by** (emerald chip "In pool" when never owned, "Back in pool" when removed by an agent, else the agent's name) and a trash icon button (disabled for sold leads). Empty → Database icon "No leads found". Selected rows tinted `bg-blue-50/40`.
Delete (single or bulk) uses the confirm dialog: title "Delete this lead?" or "Delete N leads?", message `"{code — company | These N leads} will be deleted permanently, with their call history and activity log. Their arranged meetings will be cancelled. This can’t be undone."`, confirm "Delete permanently" (danger) → `deleteLeadsAsAdmin(ids)` and the ids are removed from the selection.
**`LeadImportModalShell`**: z-60 `max-w-lg` modal with sticky header (title, subtitle, close X) and sticky footer.
**`AddSingleLeadModal`** ("Add One Lead" / "It goes to the shared pool"): fields **Lead ID \*** (autofocus), **Campaign \*** (select of workflows via `campaignLabel`, default the first), **Company \***, Contact person, Phone, Email (2-col grid). Live error (rose box) in this priority: code invalid → "Lead ID must contain letters and numbers only"; code exists → "This lead ID already exists"; email present but invalid → "Invalid email". **Add Lead** enabled only with a clean code, no error, a company and a campaign; builds `createPoolLead(adminId, adminName, {...})`, dispatches `addLeadsToPool([lead])`, closes.
**`PasteLeadsModal`** ("Paste Leads" / "They go to the shared pool - no agent yet"): **Default campaign** select (hint "Used for every row that has no campaign column."); a format box "Lead ID [Tab] Company [Tab] Contact [Tab] Phone [Tab] Email [Tab] Campaign (optional) / One lead per line. The ID must be letters and numbers only and must not exist yet."; monospace textarea (rows 8) with a two-line placeholder example (`LD101  TechCorp  John Smith  +20 100 111 2222  john@techcorp.com  ACT-001` and `LD102 DataSys Jane Doe …  RET-002`, tab-separated); live `"{n} ready · {m} with a problem"` and a list `Line {n} · {code} — {reason}` (max 50). Button **"Add N lead(s)"**: dispatches `addLeadsToPool` with `createPoolLead` for each accepted row; if there were rejected rows the text box is replaced by only the rejected raw lines and a green note "{added} lead(s) added to the pool. The rows below need fixing." appears; if nothing was rejected the modal closes.

### 9.7 Calendar (`features/calendar`, OM / TL / agent)

**Data:** `myMeetings = meetings.filter(participantIds includes me || createdBy === me)`. `meetingsByDate` keyed by `meeting.date`. `todayStr = new Date().toISOString().split('T')[0]` (UTC) and each grid cell's key is also `date.toISOString().split('T')[0]` (see quirks §13).

**Layout:** `p-4 sm:p-6 max-w-7xl mx-auto`.
1. If there are meetings today: violet gradient banner (`bg-gradient-to-r from-violet-600 to-violet-700 text-white rounded-xl`) "Today's Meetings (N)" with translucent buttons (Clock + time, `({duration}min)`, title, company for lead meetings else participants); click opens the detail modal.
2. Two columns: **month grid** (flex-1) and a **right panel** `w-80` (sticky).
   * Grid card header: month name (`toLocaleDateString('en-US',{month:'long',year:'numeric'})`), prev chevron, **Today**, next chevron, and a blue **New Meeting** button (Plus).
   * Weekday header row **Sun Mon Tue Wed Thu Fri Sat** (week starts on **Sunday** here). Cells are `min-h-[100px] border-r border-b`; empty leading/trailing cells `bg-slate-50/30`; each day is a button: the day number (today = `text-violet-700 font-bold` and `ring-2 ring-violet-300 ring-inset`), selected `bg-violet-50`; up to **3** chips `"{time} {company | title}"` coloured by `MEETING_STATUS_STYLE[status].bg/color`; `+N more` text beyond 3.
   * Right panel: title = selected date (`weekday long, month long, day numeric`) or "Select a date"; empty → Calendar icon "No meetings on this day"; else cards (time, status pill, title, `"{company • }{participants} • {duration}min"`).
3. `MEETING_STATUS_STYLE`: arranged "Arranged" violet-700 on violet-100; completed "Completed" emerald; no_show "No Show" rose; cancelled "Cancelled" slate-600 on slate-100; rescheduled "Rescheduled" amber.

`getDisplayParticipants(m)`: for a lead meeting with a company → participant names; otherwise if the viewer is the creator → participant names, else `['Manager', ...names]` (so an invited agent sees "Manager, …").

**`CreateMeetingModal`** (z-60, `max-w-md`; title **"Schedule Meeting"**, **"Reschedule Meeting"** when `prefill.purpose==='reschedule'`, **"Schedule Another Meeting"** for a follow-up prefill). `MeetingPrefill = { source: Meeting; purpose: 'reschedule' | 'follow_up' }` copies leadId, participantIds (non-agents), title, duration (default 30) and notes (agenda) from the source; **date defaults to today and time to `10:00`** (not copied).
* **Agent:** a required **Lead** `LeadPicker` over own leads that are not removed / stopped / expired. Creates `{type:'lead_meeting', leadId, leadName: contactName, companyName, agentId: me, participantIds:[me], participantNames:[me.name], title: "Meeting with {company}", date, time, duration, notes, status:'arranged', priority:'high', createdBy: me}`.
* **Team Leader:** optional **Title**, optional **Link to Lead** (leads of own team agents, same filters) shown only if there are leads, and **Select Agents** (checkbox list of team agents with "(n/m)" and a *Select all agents / Clear all* toggle). Needs ≥ 1 participant. With a lead → `lead_meeting` (leadId/leadName/companyName set, **no `agentId`**), without → `internal_meeting`. Title fallback `"Meeting with {company}"` or `"Meeting with {names joined}"`.
* **Operation Manager:** Title + **Select Team Leaders** (leaders of teams the OM manages, same toggle labelled "Select all team leaders"), no lead link; always an `internal_meeting`.
* Common: **Date** (date input), **Time** (time input), **Duration** quick buttons `15min 30min 45min 60min` (selected blue), **Notes** textarea (placeholder "Meeting agenda or notes...", rows 3). Buttons Cancel / **Schedule Meeting** (disabled until valid: agent needs a lead; TL/OM need participants).
* The page on create dispatches `createMeeting(meeting)`; **if rescheduling**, it then dispatches `updateMeeting({meetingId: source.id, updates:{status:'rescheduled'}})` — the old meeting is closed only after the new one is saved so the lead stays in the Meeting section; then `addNotification({type:'meeting', title:'Meeting scheduled', message:"{title} on {date} at {time}", read:false})` (no `userId`, so visible to everyone); closes the modal and clears the prefill.

**`MeetingDetailModal`** (`max-w-md`): header title + `"{company • }{participants}"`; grid Date (`weekday short, month short, day numeric`) and Time (`"{time} ({duration}min)"`); **Notes** (grey box), **Meeting outcome** (green box, `whitespace-pre-wrap`) when present, **Participants**, **Status** pill. `canUpdate = meeting.createdBy === me.id`; otherwise the note "Only the person who created this meeting can update its status." is shown and no actions.
* Actions grid (2×2): **Completed** (emerald, CheckCircle2), **No Show** (rose, XCircle), **Cancel** (slate, Ban), **Reschedule** (amber, RefreshCw). A lead meeting (`type lead_meeting && leadId`) pressing *Completed* opens the **outcome form**: label "What happened in the meeting?", textarea rows 4 (placeholder "Describe the meeting: what was discussed, what the lead decided, next steps..."), hint "Required — it is saved on the meeting and in the lead's history."; buttons **Back**, **Save & schedule next meeting** (updates to completed then opens the schedule form prefilled as follow-up), **Save outcome** (emerald); both need a non-blank outcome. *Reschedule* does **not** change the status immediately; it opens the schedule form prefilled (`reschedule`). *Cancel* asks to confirm (*"Cancel this meeting?"* — "<b>{title}</b> will be marked as cancelled." — "Cancel meeting", danger). Lead meetings also get a blue **"Schedule another meeting with this lead"** button (CalendarPlus) which opens the form prefilled as `follow_up`. Internal meetings set Completed/No show directly.

### 9.8 Sales (`features/sales`, OM / TL / agent / quality)

All numbers refer to the **selected month** (`YYYY-MM`, default current; chevron buttons ‹ › shift it; label min-width 130px). Container `p-4 sm:p-6 max-w-6xl mx-auto space-y-6`.
* **Header:** title — agent "My Sales", TL `"{team name} Sales"`, OM "Team Sales", quality "Sales". Subtitle: quality "Record every sale and follow each agent’s progress"; others "Sales recorded by Quality · everyone can see everyone’s sales". Month switcher and, **for quality only**, a blue **Record Sale** button.
* **Scope** (`scopeGroups`): agent → only own row of their team; TL → own team; OM → teams they manage; quality → all teams. `monthSales` = this month's sales whose agent is in scope. `totalTarget = Σ teamSalesTarget(of scope groups)` (agent count × 28; for an agent scope = 28).
* **Summary card:** Target icon + label (**My monthly target / Team monthly target / All teams monthly target / Company monthly target**), `"{count} / {target}"`, `TargetProgressBar`, `SaleTypeChips`, and for non-agents the caption "Each agent: 28 sales a month. A team's target is its number of agents × 28."
* **`TargetProgressBar({count,target})`:** `pct = target>0 ? min(count/target*100,100) : 0`; bar `h-1.5 bg-slate-200`, fill blue-500 (emerald at 100%), width `max(pct, count>0 ? 2 : 0)%`; right label `"{count}/{target} ({round(pct)}%)"` (`w-24 text-right`).
* **`SaleTypeChips`:** seven chips `"{TYPE} {count}"`, coloured with the type's chip classes when count > 0, else `bg-slate-50 text-slate-500`.
* **Top 5 agents (`TopAgentsCard`):** company-wide ranking (§5.12). Header Trophy icon "Top 5 agents · {Month Year}". Empty → "No sales yet this month". Row: rank circle (1st/3rd amber, 2nd slate, rest `bg-slate-50`), avatar, name (+ blue **You** pill), team name, and `"{n} sale(s)"` (only the count, never the type).
* **All teams:** header "All teams" + `SortDirectionButton` (label `Sales: Descending/Ascending`, icons ArrowDownWideNarrow / ArrowUpNarrowWide). Every team for every role. Teams sorted by their month sales count (`dirMul`), agents inside sorted by their sales then name. Each team card: **violet header** (`bg-violet-50 border-l-4 border-l-violet-500`) with the leader's avatar in a violet ring, name, a **"Team Leader"** pill with a Crown icon, `"{team} • {n} agents"`, Trophy + team count, a target bar and type chips. Below, agent rows (`p-4`; own row `bg-blue-50/40`): avatar, name + grey **Agent** pill (+ **You**), `@username`, a **More details** button (chevron rotates when open, `aria-expanded`) **shown only if `canSeeDetails(agentId)`** (agent: self; TL: agents of own team; OM & quality: everyone), the agent's target bar (target 28) and chips. Expanded → `AgentSalesDetails`: sales grouped by lead (newest first) with company, `code · campaign`, a blue **"N sales"** badge when a lead has several, and per-sale `type chip + date` (`month short, day numeric`). Empty → "No sales this month.". Team without agents → "No agents in this team.".
* **Sales list** (card): title by role (`My sales / Team sales / My teams’ sales / Sales`) + count + `SortDirectionButton` (label "Date"; sort by date then `createdAt`). Row: date (`month short, day numeric`), company (`leadName`), sub-line `"{agent name · }{leadCode} · {campaignCode}"` (agent name hidden for agents), blue badge **"{N} sales on this lead"** when the same lead has > 1 sale in the scoped month, the type chip, and — **quality only** — a trash button (confirm *"Delete this sale?"* — "The {type} sale for <b>{company}</b> will be deleted. This can’t be undone." — "Delete", danger → `deleteSale`). Empty → Trophy icon "No sales in {Month Year}".

**`RecordSaleModal`** (quality only; `max-w-md`): **Agent** (`AgentPicker`; changing agent clears the lead), **Lead** (`LeadPicker` over *that agent's* leads — `leads.filter(agentId === chosen)`; before choosing an agent a dashed "Choose an agent first" box; under the picker `"{leadCode} · {campaignCode}"`; if the lead was never reached (`!hasReachedPerson`) an amber warning "Nobody has spoken to this lead yet (no Discovery call or meeting). Check that this is the right lead before saving."), **Sale type** (select "Select sale type..." + 7 types), **Sale date** (date input, default today, `max` = today). **Save Sale** needs agent + lead + type + date. It dispatches `recordSale({id, agentId, leadId, leadName, saleType, date, createdBy: me.id, createdAt})` and the page jumps to the sale's month.

### 9.9 Analytics (`features/analytics`, OM / TL / agent)
Container `p-4 sm:p-6 max-w-6xl mx-auto space-y-6`.
* **Header:** `h1` "My Analytics" (agent) or "Analytics"; subtitle `"Your own numbers"` for agents, else `"Your team"` (TL) / `"All your teams"` (OM) + ` · {n} agents`, then ` · {leads.length} leads · {range}` (`from → to`, or a single date). `PeriodPicker` (segmented **Today / This week / This month / Custom**, default **This month**; Custom reveals two date inputs "to"). A campaign select: "All campaigns" + `"{code} · {label}"` for every workflow.
* **Scope:** agent → themself; TL → agents of teams they lead; OM → agents of teams they manage. `baseLeads` = leads held by scope agents and matching the campaign filter; `sales` = sales on those leads inside the range; `meetings` = all meetings inside the range; `leads` = `leadsForPeriod(baseLeads, range, soldLeadIds)`.
* **KPI cards (4):** **Answer rate** (`"{calls.answerRate}%"`, hint `"{lvm+discovery} of {calls} calls got a reply"`), **Reach rate** (hint "Right person on the line (Discovery)"), **Lead conversion** (`pct(sold, leads)`, hint `"{sold} of {leads} leads sold"`), and **Sales this month** `"{sales} / {target}"` (target = scope agents × 28, hint `"{pct}% of target"`) when the preset is *month*, else **"Sales {today|this week|the selected period}"** with hint "Monthly target is shown in 'This month'".
* **Lead funnel** card: five bars — Leads, "Contacted (at least one call)", "Reached the right person", "Meeting arranged", "Sold"; each shows the count and `"· {pct}% of previous step"` (when the previous count > 0); bars are `HorizontalBar` (max = total leads, last bar emerald else blue).
* **Best time to call** card: sentence `"Highest reach rate: around {hour}:00 ({rate}% of {calls} calls)."` (best hour = hours with ≥ 2 calls sorted by reach rate then calls) or "Needs at least 2 calls in the same hour."; per hour row `HH:00`, cyan bar of reach rate (max 100) and `"{rate}% of {calls} calls"`; empty → "No calls in this period.".
* **Campaigns** table and (non-agents) **Agents** table (`GroupPerformanceTable`; columns **{Campaign|Agent}, Leads, Calls, Answer rate, Reach rate, Reached leads, Sold leads, Conversion, Reached → sale**; empty row "No data for this selection.").
* **"What agents report on calls"** card (cyan bars, `"{count} · {share}%"`, text "Taken from the call reason, or read from the comment when no reason was chosen."; empty "No calls in this period.") and, for non-agents, a **Data quality** card (warn = amber with AlertTriangle, info = slate with Info; empty "No problems found in the data."). Issues are computed on the scope's leads/sales regardless of the period.
* `HorizontalBar({value,max,color='bg-blue-500'})`: `h-1.5 bg-slate-200` track, fill width `max>0 ? max(2, value/max*100) : 0`%. `KpiCard`: card with `text-2xl font-bold` value, label, optional hint. Shared `CARD_CLASS = 'bg-white rounded-xl border border-slate-200 shadow-sm p-5'`.

### 9.10 Email Center (`features/email-center`, OM / TL / agent)
Header "Email Center" with subtitle — managers: "Send custom emails and track history"; agents: "Write your own emails (templates are optional) and track history". Buttons: **agents only** a white/violet **"Email step leads (N)"** (Users icon; N = `emailStepLeads.length`); and a blue button **"Compose Email"** (managers) / **"Write Email"** (agent) (PenSquare).
* **Visible lead sets:** agent → own, not removed; TL → leads of team agents; OM → leads that have an agent.
* **Template cards (agents only):** two cards for the templates showing name, `Subject: …` and `"{n} sent"` (count of all logs whose `templateType` equals the template's type).
* **Email History** card with a search box (filters subject or recipient) and the list sorted by `sentAt` desc: Mail icon tile, subject, `→ {to}`, a violet **"Auto · Discovery|No Response"** pill for auto-sent mail, a violet **"Custom"** pill when `templateType === 'custom'`, body preview (truncated), then `date • {leadName} • by {sentByName}`. Visibility: agent → logs they sent (`sentBy === me`); TL → logs whose lead belongs to a team agent (standalone emails with no lead are *not* shown to TLs); OM → all. Empty: Mail icon "No emails sent yet".
* **`emailStepLeads`** (agent): own leads not removed/stopped whose current touch point is an open **email** step and whose bucket is `today`.
* **Compose (manager)** → `CustomEmailModal` (title "Compose Email", subtitle "Custom email — write from scratch"; To (text), Subject, Message; **Send Email** disabled unless To and Subject) → `sendStandaloneEmail`.
* **Write Email (agent)** → `TemplatedEmailModal` (title "Send Email"): **Template** select ("Select template..."; choosing copies subject/body), **To** (email input), **Link to Lead (optional — auto-fills email)** (`LeadPicker` over own leads; picking a lead with an email fills *To*), Subject, Message. **Send Email** → `sendEmailForLead({ email:{… templateType:'custom' …}, leadId: leadId || '', touchPointOrder: -1 })` (does not advance the workflow). The modal clears its fields after sending.
* **Email step leads (agent)** → `BulkEmailModal` (title "Email step leads", subtitle "Leads whose current step is an email due today"): checkbox list (`"({selected}/{total})"`, *Select all / Clear all*; each row shows code chip, company, `stepLabel`, and a rose "no email" tag when missing), optional **Template** select ("Write it myself..."), Subject, Message with hint "[Name], [Company Name] and [Agent Name] are filled in for each lead."; an amber note when selected leads lack an email ("{n} selected lead(s) has/have no email address saved."); empty state "No leads are waiting on an email step right now."; button **"Send & Mark Complete (N)"** (violet) → `sendBulkEmailForLeads`.

### 9.11 Tasks (`features/tasks`, OM / TL / agent)
Header "Tasks" with subtitle: agent "Your assigned tasks", OM "Assign tasks to team leaders", TL "Assign tasks to your team agents"; a **New Task** button for TL/OM. Visible tasks: OM → authored by me or assigned to me; TL → assigned to me or authored by me; agent → assigned to me. Assignable people: OM → all team leaders; TL → agents of their team. Empty: "No tasks yet".
Task card: checkbox circle (assignees get a clickable `Circle/CheckCircle2` that dispatches `toggleTaskCompletion`; non-assignees see a read-only circle that is green when everyone finished), title (`line-through` when I completed it), a rose **Overdue** pill (`deadline < now` and not completed by me), description, and a meta row **Due: {date}**, author name, `"{done}/{total} completed"` (done counts only `completedBy ∩ assignedTo`). For non-agents a divider and per-assignee chips (green check when done, grey circle otherwise).
**`CreateTaskModal`** ("New Task"): Title, Description (rows 3), Deadline (date; empty → now + 7 days), **Assign To**: toggle **All {Team Leaders|Agents}** (default) / **Select Specific** with a checkbox list. **Create Task** disabled when the title is blank or "specific" with nobody ticked. Creates `{id, authorId, authorName, title, description, createdAt, deadline, assignedTo, completedBy: []}` (all = every assignable user id).

### 9.12 Team Updates (`features/team-updates`, OM / TL / agent)
Header "Team Updates" with subtitle: agent "Updates from your team leader and management", OM "Send updates to team leaders or everyone", TL "Send updates to your team agents"; **New Update** (Send icon) for TL/OM. Visible: agent → `all` or `specific_team` of their team; TL → `all`, `team_leaders`, or `specific_team` of their team; OM → all.
Recipients of an update: `all` → everyone except OM and admin; `team_leaders` → all team leaders; `specific_team` → that team's agents. Card: author avatar, author name, date (`month short, day numeric, 2-digit hour:minute`), title, a grey **"To: {Everyone | All Team Leaders | team name}"** pill, an unread rose pulsing dot when the viewer is a recipient who has not acknowledged, content, and — for non-agents — an **Acknowledgments `x/y`** list (green chips for acknowledged, grey with a Clock for pending). Recipients see an **Acknowledge** button (dark → green "Acknowledged" and disabled once done) → `acknowledgeTeamUpdate`. Empty: "No updates yet".
**`CreateUpdateModal`** ("New Update"): **Audience** radio-cards — OM sees *Everyone (all TLs + all agents)*, *All Team Leaders only*, *Specific Team*; TL only sees *My Team Agents* (default `specific_team`; OM default `all`). A **Team** select appears for `specific_team` when more than one team is available (OM: all teams; TL: own). Title, Content (rows 5), a helper line (`All team leaders and agents will see this` / `Only team leaders will see this` / `Agents in the selected team will see this`). **Send Update** → the page dispatches `postTeamUpdate(update)` and `addNotification({type:'update', title:'New update', message:"{author} posted: {title}"})` (visible to everyone).

### 9.13 Teams (`features/teams`, all five roles)
Header "Teams" with `"{n} teams · {m} agents"` (+ " · use Move to put an agent in another team" for OM). For each operation manager: a centred card (blue-200 border, avatar, name, `@username`, **Manager** pill with Crown) with a connector line and a responsive grid (`sm:grid-cols-2 lg:grid-cols-3`) of team cards: header (name + `"{n} agent(s)"`), the leader row with a violet **Team Leader** pill (Shield), then agent rows; an empty team shows "No agents in this team". Below: a dashed card **"Agents without a team"** when any exist. `(you)` is appended to the current user's name. **Move** (blue, ArrowRightLeft) appears on an agent row only for an **OM** and only if the agent is unassigned or in a team that OM manages.
**`MoveAgentModal`** ("Move agent to another team"): agent card with `"{team} · {leader}"` or "No team yet"; **New team** select of the OM's *other* teams (`"{name} · Team Leader: {leader}"`); explanation "Only the team changes. {First} keeps all their leads, calls, meetings and sales exactly as they are, and continues under {leader}."; **Move agent** → `moveAgentToTeam`.

---

## 10. Design system

Tailwind only; system font stack; icons from `lucide-react`. Mobile-first with breakpoints `sm 640`, `md 768`, `lg 1024` (the sidebar collapses to icons below `lg`).

### 10.1 Colour roles (do not introduce indigo / purple / teal / orange / red in new code)
| Use | Colour |
|---|---|
| Primary (buttons, active nav, focus) | **blue** (`bg-blue-600 hover:bg-blue-700`; nav active `bg-blue-50 text-blue-700`) |
| Success (Discovery, completed step, target reached) | **emerald** |
| Warning (LVM / NVM, due today, stopped) | **amber** |
| Error / delete / No Response / overdue | **rose** |
| Accent (Meetings, Emails, Team Leader) | **violet** |
| Call touch points, Activation | **cyan** |
| Neutral | **slate** (page `bg-slate-50`, cards white, borders `slate-200`, dividers `slate-100`) |

(The seed *user avatar colours* are arbitrary hex values, listed in §6.5.)

### 10.2 Component recipes
* **Card:** `rounded-xl border border-slate-200 bg-white shadow-sm` (padding `p-4`/`p-5`).
* **Buttons:** `rounded-lg`; primary `bg-blue-600 text-white hover:bg-blue-700`; danger `bg-rose-600 hover:bg-rose-700`; ghost `text-slate-600 hover:bg-slate-100`; disabled `disabled:opacity-40` (and the global rule gives `cursor-not-allowed`).
* **Badge/pill:** `rounded-full px-2.5 py-0.5 text-xs font-medium` (smaller `text-[11px]`/`text-[10px]` variants exist).
* **Modal:** overlay `bg-slate-900/60 backdrop-blur-sm animate-fade-in` (click closes); panel `bg-white rounded-2xl shadow-2xl w-full max-w-{sm|md|lg} mx-4 animate-slide-up`; header `px-6 py-4 border-b border-slate-200` with a close X (`w-8 h-8 rounded-lg hover:bg-slate-100`); body `px-6 py-5 space-y-4`; footer `px-6 py-4 border-t border-slate-100 flex justify-end gap-2` (sticky in long forms; `max-h-[90vh] overflow-y-auto scrollbar-thin`). z-index: modals `z-[60]`, delete lead `z-[70]`, confirm dialog `z-[80]`, storage banner `z-[100]`, drawer `z-50`, notification menu `z-30/40`.
* **Drawer:** `fixed inset-0 z-50 flex justify-end`, overlay `bg-black/30`, panel `max-w-lg bg-white h-full overflow-y-auto animate-slide-in shadow-2xl`, sticky header.
* **Inputs:** `rounded-lg border border-slate-300 text-sm px-4 py-2.5 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500`.
* **Progress bar:** `h-1.5 rounded-full bg-slate-200`, fill `bg-blue-500` (emerald at 100%); dashboard bars use `h-3`/`h-2.5`.
* **Tables:** header row `bg-slate-50/50 border-b border-slate-100`, header cells `px-4 py-3 text-left text-xs font-semibold text-slate-600`, body `divide-y divide-slate-100`, row hover `hover:bg-slate-50/30`.
* **Lead-code chip:** `font-mono text-xs bg-slate-100 text-slate-600/700 px-1.5–2 py-0.5 rounded`.
* **Empty states:** large lucide icon with `opacity-30`, then a `text-sm text-slate-500` sentence.

### 10.3 `index.css` (the complete stylesheet)
```css
@tailwind base;
@tailwind components;
@tailwind utilities;

/* SalesFlow design tokens … (comment) */
@layer base {
  :root { --color-primary-50:#eff6ff; --color-primary-100:#dbeafe; --color-primary-200:#bfdbfe; --color-primary-300:#93c5fd;
          --color-primary-400:#60a5fa; --color-primary-500:#3b82f6; --color-primary-600:#2563eb; --color-primary-700:#1d4ed8;
          --color-primary-800:#1e40af; --color-primary-900:#1e3a8a; }
  html { -webkit-text-size-adjust: 100%; }
  body { font-family: ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
         -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; color:#0f172a; background-color:#f8fafc;
         font-feature-settings:'tnum' 1; }
  ::selection { background:#bfdbfe; color:#1e3a8a; }
  button:focus-visible, a:focus-visible, summary:focus-visible, [role='button']:focus-visible, [tabindex]:focus-visible
    { outline:2px solid #3b82f6; outline-offset:2px; }
  button:disabled, input:disabled, select:disabled, textarea:disabled { cursor:not-allowed; }
  input:disabled, select:disabled, textarea:disabled { background-color:#f1f5f9; color:#64748b; }
  select { background-color:#fff; }
}
@layer utilities {
  .scrollbar-thin { scrollbar-width:thin; scrollbar-color:#cbd5e1 transparent; }
  .scrollbar-thin::-webkit-scrollbar { width:8px; height:8px; }
  .scrollbar-thin::-webkit-scrollbar-thumb { background:#cbd5e1; border-radius:9999px; border:2px solid transparent; background-clip:content-box; }
  .scrollbar-thin::-webkit-scrollbar-thumb:hover { background:#94a3b8; background-clip:content-box; }
  .scrollbar-thin::-webkit-scrollbar-track { background:transparent; }
  .animate-fade-in  { animation: fadeIn 0.18s ease-out; }
  .animate-slide-in { animation: slideIn 0.24s cubic-bezier(0.22,1,0.36,1); }
  .animate-slide-up { animation: slideUp 0.22s cubic-bezier(0.22,1,0.36,1); }
  .animate-pulse-ring { animation: pulse-ring 2s infinite; }
  @keyframes fadeIn  { from{opacity:0} to{opacity:1} }
  @keyframes slideIn { from{transform:translateX(100%);opacity:0} to{transform:translateX(0);opacity:1} }
  @keyframes slideUp { from{transform:translateY(12px);opacity:0} to{transform:translateY(0);opacity:1} }
  @keyframes pulse-ring { 0%{box-shadow:0 0 0 0 rgba(244,63,94,.4)} 70%{box-shadow:0 0 0 8px rgba(244,63,94,0)} 100%{box-shadow:0 0 0 0 rgba(244,63,94,0)} }
}
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation-duration:0.01ms !important; animation-iteration-count:1 !important; transition-duration:0.01ms !important; }
}
```

---

## 11. Permission matrix (what the **store** enforces — not only the UI)

| Operation | Allowed actor | Store check |
|---|---|---|
| Add leads to pool / delete leads from pool | `admin` | role check; leads with a sale are never deleted |
| Take leads from the pool | `agent` | role check + still in pool + code not held + workflow exists |
| Call / email / skip / restore / stop / resume / remove / delete a lead | the **agent who owns it** | `lead.agentId === currentUserId` (+ workable for complete/log/email) |
| Transfer a lead | OM, or TL of the agent currently holding it | target must be an `agent`; removed leads can't be transferred |
| Move agent between teams | OM, only teams he manages | role + manager checks, creates 3 notifications |
| Record / delete a sale | `quality` | role check (+ lead must exist) |
| Update a meeting | the meeting's **creator** | `createdBy === currentUserId` (+ outcome required for completed lead meetings) |
| Create Team Update / Task | TL, OM (UI-level only; the reducers don't check the role) | — |
| Acknowledge update / toggle task | any user (UI limits to recipients/assignees) | — |
| Notifications | any | — |

---

## 12. Lifecycle walk-throughs (use as end-to-end tests)

### 12.1 A lead from birth to sale
1. **Admin** pastes `LD101 TechCorp …` → lead lands in the pool (`agentId ''`, history `created`).
2. **Agent** opens *Take Leads*, types `ld-101` → takes it. Now `round 1`, touch points = workflow copy (step 1 due *now*), history `taken_from_pool`; it appears in **Work Queue → Activation → Today → 1: CALL → New**.
3. Agent presses **Mark Call**, picks *Discovery*, writes a description → call log + step completed in one action; lead moves to **Next → 2: EMAIL** (due tomorrow), category **Discovery**; `status 'discovery'`. Step 2 is due `now + (1 − 0) days`.
4. The next day, `autoEmailJob` sends the *Discovery Follow-up* template automatically (if the lead has an email), completes step 2, writes an `EmailLog` flagged `auto`, a system history row and a notification to the agent. Step 3 (call) is due `now + (2 − 1) days`.
5. Agent schedules a **Meeting** (Calendar → New Meeting → pick lead). Lead status → `arranged_meeting`, `discoveryReached true`; it shows in category **Meeting** and is **exempt from the 15-day rule** while the meeting is today or later. 15 minutes before it, participants get a notification.
6. After the meeting the creator marks it **Completed** and must write the outcome (stored on the meeting and as history `meeting_completed`). Lead returns to the Discovery queue (`meeting_ended`, `lastActivityAt = now`). If nobody updates it, the day-end job returns the lead automatically ("Meeting day ended with no result").
7. **Quality** opens Sales → Record Sale → picks agent, that agent's lead, type (e.g. Activation) and date. Sale counts toward targets, Top 5 and analytics.

### 12.2 Expiry and reassignment
No completed step / stop / resume / assignment for 15 days → the lead gets `expiredAt`, disappears from the agent's queue and dashboard stats, shows as **Expired** in Leads, and appears in the TL's **"Needs reassignment"** card. TL chooses another agent and confirms → `transferLeadToAgent`: old touch points frozen in `previousAssignments`, `round + 1`, fresh workflow, history `transfer … (round 1: 3/6 touch points were completed)`. An expired lead cannot be resumed by the agent.

### 12.3 Remove vs delete
*Remove* (agent): `removedFromQueue`, stopped, back in the pool, id free, history preserved; another agent who takes it starts **round + 1** with the old steps archived. *Delete permanently* (agent, only from a stopped workflow / drawer): the lead and all of its data disappear and its arranged meetings are cancelled; blocked when a sale exists.

### 12.4 Team move
OM → Teams → **Move** on an agent → modal → confirm. Only `teams[].agentIds` and `agent.teamId` change; three notifications are created (agent, new TL, old TL). Leads, sales and history stay with the agent.

### 12.5 Multi-tab behaviour
Two tabs share the same `localStorage`; a change in one is picked up by the other via the `storage` event, each tab keeping its own signed-in user. When storage fails the red banner offers a JSON backup.

---

## 13. Behaviours and quirks that must be preserved

1. **Two different "today" definitions.** Dashboards, Work Queue "Meetings today", and Calendar use the **UTC** date (`toISOString().split('T')[0]`), while the scheduler, meeting-end logic, analytics, sales and queue buckets use the **local** date (`localDay` / `localDateStr` / `endOfDay`). Reproduce both as written.
2. Calendar cells are keyed with `date.toISOString().split('T')[0]` (UTC) — in time zones ahead of UTC this can shift a day. Preserve.
3. The sidebar's red badge shows the **unread notification count on the "Team Updates" item** only.
4. `markAllNotificationsRead` marks every notification in the store as read (not only the viewer's).
5. A new meeting's notification (`Meeting scheduled`) and a new team update notification have **no `userId`**, so everyone sees them; reminder, auto-email and team-move notifications are user-specific.
6. `Lead.status` value `no_response` and notification types `task` / `overdue` exist in types/styles but nothing creates them. `CallLog.reason` exists, nothing sets it (analytics falls back to the comment classifier).
7. `completeTouchPoint`, `addCallLogWithoutCompletingTouchPoint`, `editCallLog`, `resetToSeedData`, `parseLeadRows` are implemented but unreachable from the UI — keep them.
8. The login password field is cosmetic; any text (or none) works.
9. The email "send" is simulated — only an `EmailLog` is created. The Touch-point email modal does **not** substitute `[Name]`-style placeholders when you load a template; the **bulk** send and the **auto** email **do**.
10. Auto-email only fires for the lead's **current** step if it is an email, has an email address and is due; a call step blocks the queue (never skipped). Idempotency key guarantees one auto email per (lead, round, step).
11. `skipTouchPoint` / `restoreSkippedTouchPoint` ignore the "stopped" state in the reducer (the UI hides them when stopped).
12. Lead Pool *Held by* shows **"Back in pool"** for removed leads that still keep an old `agentId`, **"In pool"** for never-assigned leads.
13. The work-queue campaign section hides "Stop N" pill when 0, but Today/Next pills always show.
14. Dashboards count calls only from leads that are **not removed and not expired**; the Work Queue excludes the same set; *Leads* page excludes only removed.
15. Sales list for a TL = sales of agents currently in their team; sales stay credited to the agent when an agent moves teams (history of old team sales moves with the agent).
16. The analytics "Data quality" issues use *all* time data for the scope; everything else follows the selected period.
17. Seed contact in `Meeting.leadName` is the **contact person's** name, while `companyName` is the company.
18. `Sidebar` code comment says "dark menu" but the sidebar is **white**.

---

## 14. Build order and acceptance checklist

### 14.1 Suggested build order
1. Scaffold Vite + React + TS + Tailwind 3 + path alias; add `index.css` (§10.3).
2. `domain/types/*`, then `shared/lib/dates.ts`, `shared/ui/leadStatusStyles.ts`.
3. Pure domain modules (workflow, lead, sales, analytics, email, meeting, user) exactly per §5.
4. Seed data (§6.5), `AppState`, persistence (§6.1), helpers (§6.2), reducers (§6.3), scheduler (§6.4), slice, `store/index.ts`, hooks.
5. Shared components (§8), `App`, `navigation`, layout (§7).
6. Pages in this order: Login → Lead Pool → Take Leads → Work Queue (+modals/drawer) → Leads → Dashboard (3 variants) → Calendar → Sales → Analytics → Email Center → Tasks → Team Updates → Teams.

### 14.2 Acceptance checklist (should all pass)
- [ ] Fresh browser shows the login list of 9 users; signing in as `admin` lands on **Lead Pool** with 52 leads (40 "In pool"); quality lands on **Sales**; others on **Dashboard**.
- [ ] Sidebar items per role exactly as §7.2; opening a disallowed page falls back to the role's home page.
- [ ] Admin: paste 3 rows (one duplicate id, one bad email) → 1–2 accepted, rejected rows listed with the exact reasons; add one lead; bulk delete (leads with sales cannot be selected).
- [ ] Agent (e.g. Mona): Work Queue shows her 3 seeded leads; stats cards correct; Take Leads by exact ID `ld-013` works, `LD01` finds nothing, ids held by others report "Held by {name}", duplicates "Repeated in this list".
- [ ] Mark Call needs a description; saves as one atomic action; step advances; categories re-bucket (New → Discovery/LVM/NVM).
- [ ] Skip asks for confirmation, can be restored from the drawer; Stop moves the lead into **Stop**, Resume brings it back; Remove returns it to the pool; Delete is blocked by a sale.
- [ ] Setting a lead's `assignedAt` 15+ days back (or advancing time) expires it; TL sees it under "Needs reassignment" and can reassign.
- [ ] Meeting: agent creates a lead meeting → lead in **Meeting** category; reminder 15 min before; completing requires an outcome; reschedule creates the new meeting first and then marks the old one `rescheduled`; only the creator can update.
- [ ] Quality records a sale; agents cannot; Sales page shows Top 5 (tie-break discovery → lvm → name), target bars (28/agent), violet team-leader headers, More-details visibility rules per role.
- [ ] Analytics: period presets (week starts Saturday), campaign filter, funnel, best hour, tables, reasons, data-quality warnings.
- [ ] Email Center: agent write/bulk/history; manager compose; auto emails labelled "Auto · …".
- [ ] Tasks and Team Updates: audience and visibility rules, acknowledgement counts.
- [ ] Teams: OM can Move an agent; three notifications are created.
- [ ] Reload keeps all data; two tabs stay in sync; filling storage shows the red backup banner.
- [ ] Every delete / skip / stop / remove / cancel / reassign action asks for confirmation first.

---

## 15. Glossary
**Lead** – a prospect company/contact with a unique lead code. **Pool** – shared set of unowned leads. **Campaign / Workflow** – a named template (`ACT-001` Activation, `RET-002` Retention) of ordered touch points. **Touch point** – one step (call or email) with a day offset. **Round** – how many agents have owned the lead (starts 1). **NVM / LVM / Discovery** – No Voicemail / Left Voicemail / Client Responded. **Reached** – a Discovery call or an arranged meeting. **OM / TL** – Operation Manager / Team Leader. **Expired** – removed from the agent's queue by the 15-day rule, waiting for TL reassignment.
