# SalesFlow — Verbatim Source Appendix

Ground-truth source of every file in `src/` (153 files), exactly as in the uploaded project. Use it together with `SalesFlow_Full_Spec.md`: the spec explains, this file is the exact code. Create each file at the path shown in its heading.

Not included (not in the upload, see spec §2.2): package.json, vite.config.ts, tsconfig.json, tailwind.config.js, postcss.config.js, index.html.

---

## `src/app/App.tsx`

```tsx
import { useState } from 'react';
import { useStore, setCurrentUser } from '@/store';
import { AppShell } from '@/app/layout/AppShell';
import { canOpenPage, homePageFor, type PageId } from '@/app/navigation';
import { useSchedulerTick } from '@/app/useSchedulerTick';
import { LoginPage } from '@/features/auth/LoginPage';
import { DashboardPage } from '@/features/dashboard/DashboardPage';
import { WorkQueuePage } from '@/features/work-queue/WorkQueuePage';
import { CalendarPage } from '@/features/calendar/CalendarPage';
import { MyLeadsPage } from '@/features/my-leads/MyLeadsPage';
import { TeamUpdatesPage } from '@/features/team-updates/TeamUpdatesPage';
import { TasksPage } from '@/features/tasks/TasksPage';
import { EmailCenterPage } from '@/features/email-center/EmailCenterPage';
import { SalesPage } from '@/features/sales/SalesPage';
import { AnalyticsPage } from '@/features/analytics/AnalyticsPage';
import { TeamsPage } from '@/features/teams/TeamsPage';
import { LeadPoolPage } from '@/features/lead-pool/LeadPoolPage';

export function App() {
  const { state, dispatch } = useStore();
  const [page, setPage] = useState<PageId>('dashboard');

  useSchedulerTick(!!state.currentUserId);

  if (!state.currentUserId) {
    return <LoginPage onLogin={() => {}} />;
  }

  // If the page left open from the previous person is not allowed for this role, go to their home page
  const role = state.users.find(u => u.id === state.currentUserId)?.role;
  const currentPage: PageId = role && !canOpenPage(page, role) ? homePageFor(role) : page;

  return (
    <AppShell
      currentPage={currentPage}
      onNavigate={setPage}
      onLogout={() => dispatch(setCurrentUser(''))}
    >
      {currentPage === 'adminleads' && <LeadPoolPage />}
      {currentPage === 'dashboard' && <DashboardPage />}
      {currentPage === 'workqueue' && <WorkQueuePage />}
      {currentPage === 'calendar' && <CalendarPage />}
      {currentPage === 'leads' && <MyLeadsPage />}
      {currentPage === 'updates' && <TeamUpdatesPage />}
      {currentPage === 'tasks' && <TasksPage />}
      {currentPage === 'emails' && <EmailCenterPage />}
      {currentPage === 'sales' && <SalesPage />}
      {currentPage === 'analytics' && <AnalyticsPage />}
      {currentPage === 'teams' && <TeamsPage />}
    </AppShell>
  );
}

```

---

## `src/app/layout/AppShell.tsx`

```tsx
import { Sidebar } from '@/app/layout/Sidebar';
import { NotificationsMenu } from '@/app/layout/NotificationsMenu';
import { UserMenu } from '@/app/layout/UserMenu';
import { NAV_ITEMS } from '@/app/navigation';
import type { PageId } from '@/app/navigation';
import { useStore } from '@/store';

export function AppShell({
  children,
  currentPage,
  onNavigate,
  onLogout,
}: {
  children: React.ReactNode;
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  onLogout: () => void;
}) {
  const { state } = useStore();

  const currentUser = state.users.find(u => u.id === state.currentUserId);
  if (!currentUser) return null;

  // a notification with a userId belongs to that person only
  const myNotifications = state.notifications.filter(n => !n.userId || n.userId === currentUser.id);
  const unreadCount = myNotifications.filter(n => !n.read).length;

  const navItems = NAV_ITEMS.filter(item => item.roles.includes(currentUser.role));

  const team = state.teams.find(t => t.id === currentUser.teamId);

  return (
    <div className="flex h-screen bg-slate-50 text-slate-900">
      <Sidebar
        navItems={navItems} currentPage={currentPage} onNavigate={onNavigate}
        unreadCount={unreadCount} currentUser={currentUser} onLogout={onLogout}
      />

      {/* Main content */}
      <div className="flex-1 min-w-0 flex flex-col overflow-hidden">
        {/* Top bar */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 shrink-0">
          <div className="flex items-center gap-3">
            <h1 className="text-lg font-bold tracking-tight text-slate-900">
              {navItems.find(n => n.id === currentPage)?.label}
            </h1>
            {team && currentUser.role === 'agent' && (
              <span className="text-xs font-medium text-slate-600 bg-slate-100 px-2.5 py-1 rounded-full">{team.name}</span>
            )}
          </div>

          <div className="flex items-center gap-3">
            <NotificationsMenu notifications={myNotifications} unreadCount={unreadCount} onNavigate={onNavigate} />

            <UserMenu currentUser={currentUser} onLogout={onLogout} />
          </div>
        </header>

        {/* PageId content */}
        <main className="flex-1 overflow-y-auto scrollbar-thin">
          {children}
        </main>
      </div>
    </div>
  );
}

```

---

## `src/app/layout/NotificationsMenu.tsx`

```tsx
import { useState } from 'react';
import { Bell } from 'lucide-react';
import type { Notification } from '@/domain/types';
import { markAllNotificationsRead, markNotificationRead, useAppDispatch } from '@/store';
import { notificationIcon } from '@/app/layout/notificationIcon';
import type { PageId } from '@/app/navigation';

interface NotificationsMenuProps {
  notifications: Notification[];
  unreadCount: number;
  onNavigate: (page: PageId) => void;
}

/** The bell in the top bar and the list of notifications that opens under it. */
export function NotificationsMenu({ notifications, unreadCount, onNavigate }: NotificationsMenuProps) {
  const dispatch = useAppDispatch();
  const [notifOpen, setNotifOpen] = useState(false);
  return (
    <div className="relative">
      <button
        onClick={() => setNotifOpen(!notifOpen)}
        aria-label="Notifications"
        aria-expanded={notifOpen}
        className="relative w-9 h-9 rounded-lg hover:bg-slate-100 flex items-center justify-center transition-colors"
      >
        <Bell className="w-[18px] h-[18px] text-slate-600" />
        {unreadCount > 0 && (
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full animate-pulse-ring" />
        )}
      </button>

      {notifOpen && (
        <>
          <div className="fixed inset-0 z-30" onClick={() => setNotifOpen(false)} />
          <div className="absolute right-0 top-full mt-2 w-80 bg-white rounded-xl shadow-lg border border-slate-200 z-40 animate-slide-up">
            <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
              <span className="font-semibold text-sm text-slate-900">Notifications</span>
              <button
                onClick={() => dispatch(markAllNotificationsRead())}
                className="text-xs text-blue-600 hover:underline"
              >
                Mark all read
              </button>
            </div>
            <div className="max-h-80 overflow-y-auto scrollbar-thin">
              {notifications.length === 0 && (
                <div className="px-4 py-8 text-center text-sm text-slate-500">No notifications</div>
              )}
              {notifications.map(n => {
                const Icon = notificationIcon(n.type);
                return (
                  <button
                    key={n.id}
                    onClick={() => {
                      dispatch(markNotificationRead(n.id));
                      if (n.meetingId) onNavigate('calendar');
                      else if (n.leadId) onNavigate('workqueue');
                      setNotifOpen(false);
                    }}
                    className={`w-full flex items-start gap-3 px-4 py-3 hover:bg-slate-50 transition-colors text-left border-b border-slate-100 ${
                      !n.read ? 'bg-blue-50/40' : ''
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                      n.type === 'overdue' ? 'bg-rose-100' : n.type === 'meeting' ? 'bg-violet-100' : 'bg-slate-100'
                    }`}>
                      <Icon className={`w-4 h-4 ${
                        n.type === 'overdue' ? 'text-rose-600' : n.type === 'meeting' ? 'text-violet-600' : 'text-slate-600'
                      }`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-slate-900">{n.title}</div>
                      <div className="text-xs text-slate-600 mt-0.5">{n.message}</div>
                    </div>
                    {!n.read && <div className="w-2 h-2 bg-blue-500 rounded-full shrink-0 mt-1.5" />}
                  </button>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

```

---

## `src/app/layout/Sidebar.tsx`

```tsx
import { TrendingUp, LogOut } from 'lucide-react';
import type { User } from '@/domain/types';
import { roleLabel } from '@/domain/user/roleLabel';
import type { NavItem, PageId } from '@/app/navigation';

interface SidebarProps {
  navItems: NavItem[];
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  unreadCount: number;
  currentUser: User;
  onLogout: () => void;
}

/** The dark menu on the left: the pages this role may open, and who is signed in. Shrinks to icons on small screens. */
export function Sidebar({ navItems, currentPage, onNavigate, unreadCount, currentUser, onLogout }: SidebarProps) {
  return (
    <aside className="w-[72px] lg:w-60 bg-white flex flex-col shrink-0 border-r border-slate-200">
      <div className="h-16 px-4 lg:px-5 flex items-center justify-center lg:justify-start gap-3 border-b border-slate-200">
        <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center shadow-sm shrink-0">
          <TrendingUp className="w-5 h-5 text-white" />
        </div>
        <div className="hidden lg:block leading-tight">
          <div className="text-slate-900 font-bold text-[15px] tracking-tight">SalesFlow</div>
          <div className="text-slate-500 text-xs">Unified Sales</div>
        </div>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto scrollbar-thin" aria-label="Main">
        {navItems.map(item => {
          const active = currentPage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              title={item.label}
              aria-current={active ? 'page' : undefined}
              className={`group relative w-full flex items-center justify-center lg:justify-start gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                active
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {active && <span className="absolute left-0 top-2 bottom-2 w-1 rounded-r-full bg-blue-600" />}
              <item.icon
                className={`w-[18px] h-[18px] shrink-0 transition-colors ${active ? 'text-blue-600' : 'text-slate-400 group-hover:text-slate-600'}`}
                strokeWidth={active ? 2.25 : 2}
              />
              <span className="hidden lg:inline">{item.label}</span>
              {item.id === 'updates' && unreadCount > 0 && (
                <span className="absolute top-1 right-1.5 lg:static lg:ml-auto bg-rose-500 text-white text-[11px] font-semibold leading-none px-1.5 py-1 rounded-full min-w-[20px] text-center">
                  {unreadCount}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      <div className="px-3 py-3 border-t border-slate-200">
        <div className="flex items-center justify-center lg:justify-start gap-3 px-2 lg:px-3 py-2 rounded-xl bg-slate-50">
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-semibold shrink-0 ring-2 ring-white"
            style={{ backgroundColor: currentUser.color }}
            title={currentUser.name}
          >
            {currentUser.initials}
          </div>
          <div className="hidden lg:block flex-1 min-w-0">
            <div className="text-slate-900 text-sm font-medium truncate">{currentUser.name}</div>
            <div className="text-slate-500 text-xs truncate">{roleLabel(currentUser.role)}</div>
          </div>
          <button
            onClick={onLogout}
            className="hidden lg:flex w-8 h-8 items-center justify-center rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors"
            title="Sign out"
            aria-label="Sign out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  );
}

```

---

## `src/app/layout/UserMenu.tsx`

```tsx
import { useState } from 'react';
import { ChevronDown, LogOut } from 'lucide-react';
import type { User } from '@/domain/types';
import { roleLabel } from '@/domain/user/roleLabel';

interface UserMenuProps {
  currentUser: User;
  onLogout: () => void;
}

/** The name + avatar in the top bar and the small menu (profile + sign out) that opens under it. */
export function UserMenu({ currentUser, onLogout }: UserMenuProps) {
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  return (
    <div className="relative">
      <button
        onClick={() => setUserMenuOpen(!userMenuOpen)}
        aria-expanded={userMenuOpen}
        aria-label="Account menu"
        className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-slate-100 transition-colors"
      >
        <div
          className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-semibold"
          style={{ backgroundColor: currentUser.color }}
        >
          {currentUser.initials}
        </div>
        <span className="text-sm text-slate-700 font-medium hidden sm:block">{currentUser.name.split(' ')[0]}</span>
        <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
      </button>

      {userMenuOpen && (
        <>
          <div className="fixed inset-0 z-30" onClick={() => setUserMenuOpen(false)} />
          <div className="absolute right-0 top-full mt-2 w-56 bg-white rounded-xl shadow-lg border border-slate-200 z-40 animate-slide-up">
            <div className="px-4 py-3 border-b border-slate-100">
              <div className="font-medium text-sm text-slate-900">{currentUser.name}</div>
              <div className="text-xs text-slate-600">{currentUser.email}</div>
              <div className="mt-1.5">
                <span className="inline-block text-xs px-2 py-0.5 bg-blue-50 text-blue-700 rounded-full font-medium">
                  {roleLabel(currentUser.role)}
                </span>
              </div>
            </div>
            <button
              onClick={onLogout}
              className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-rose-600 hover:bg-rose-50 transition-colors rounded-b-xl"
            >
              <LogOut className="w-4 h-4" />
              Sign out
            </button>
          </div>
        </>
      )}
    </div>
  );
}

```

---

## `src/app/layout/notificationIcon.ts`

```ts
import { AlertTriangle, Bell, Calendar, CheckCircle2, Mail } from 'lucide-react';

/** The icon shown next to a notification of each type. */
export function notificationIcon(type: string) {
  switch (type) {
    case 'meeting': return Calendar;
    case 'email': return Mail;
    case 'overdue': return AlertTriangle;
    case 'update': return Bell;
    case 'task': return CheckCircle2;
    default: return Bell;
  }
}

```

---

## `src/app/navigation.ts`

```ts
/** Which pages exist, who may open them, and where each role lands after signing in. */
import { BarChart3, Bell, Calendar, CheckCircle2, Database, Inbox, LayoutDashboard, Mail, Network, Trophy, Users } from 'lucide-react';
import type { User } from '@/domain/types';

export type PageId = 'adminleads' | 'dashboard' | 'workqueue' | 'calendar' | 'leads' | 'updates' | 'tasks' | 'emails' | 'sales' | 'analytics' | 'teams';

export interface NavItem {
  id: PageId;
  label: string;
  icon: typeof LayoutDashboard;
  roles: User['role'][];
  badge?: number;
}

const ALL_ROLES: User['role'][] = ['operation_manager', 'team_leader', 'agent'];

export const NAV_ITEMS: NavItem[] = [
  { id: 'adminleads', label: 'Lead Pool', icon: Database, roles: ['admin'] },
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ALL_ROLES },
  { id: 'analytics', label: 'Analytics', icon: BarChart3, roles: ['operation_manager', 'team_leader', 'agent'] },
  { id: 'teams', label: 'Teams', icon: Network, roles: ['admin', ...ALL_ROLES, 'quality'] },
  { id: 'workqueue', label: 'Work Queue', icon: Inbox, roles: ['agent'] },
  { id: 'calendar', label: 'Calendar', icon: Calendar, roles: ALL_ROLES },
  { id: 'leads', label: 'Leads', icon: Users, roles: ['agent'] },
  { id: 'sales', label: 'Sales', icon: Trophy, roles: [...ALL_ROLES, 'quality'] },
  { id: 'updates', label: 'Team Updates', icon: Bell, roles: ALL_ROLES },
  { id: 'tasks', label: 'Tasks', icon: CheckCircle2, roles: ALL_ROLES },
  { id: 'emails', label: 'Email Center', icon: Mail, roles: ALL_ROLES },
];

/** The page a person lands on, and the fallback when the current page is not allowed for their role. */
export const homePageFor = (role: User['role']): PageId => (role === 'quality' ? 'sales' : role === 'admin' ? 'adminleads' : 'dashboard');

export const canOpenPage = (page: PageId, role: User['role']) =>
  NAV_ITEMS.some(i => i.id === page && i.roles.includes(role));

```

---

## `src/app/useSchedulerTick.ts`

```ts
import { useEffect } from 'react';
import { useAppDispatch } from '@/store/hooks';
import { runScheduledJobs } from '@/store';

const SCHEDULER_INTERVAL_MS = 30000;

/**
 * Runs the timed rules (meeting reminders, meeting-day end, 15-day rule, automatic emails) while somebody is signed in.
 * A real backend would run these as background jobs instead.
 */
export function useSchedulerTick(isSignedIn: boolean) {
  const dispatch = useAppDispatch();
  useEffect(() => {
    if (!isSignedIn) return;
    dispatch(runScheduledJobs());
    const t = setInterval(() => dispatch(runScheduledJobs()), SCHEDULER_INTERVAL_MS);
    return () => clearInterval(t);
  }, [isSignedIn, dispatch]);
}

```

---

## `src/domain/analytics/commentClassifier.ts`

```ts
/** Classifies an agent's comment into a call reason (structured reason always wins). */
import { pct } from '@/domain/analytics/performanceMetrics';
import type { CallReason, Lead } from '@/domain/types';

// ---------------------------------------------------------------------------
// Comment intelligence (light): classify the agent's comment into a reason.
// A structured `reason` on the call always wins; keywords are only the fallback for free text.
// ---------------------------------------------------------------------------
export const REASON_LABEL: Record<CallReason, string> = {
  interested: 'Interested', callback: 'Call back later', price: 'Price', timing: 'Timing',
  not_interested: 'Not interested', wrong_contact: 'Wrong contact', no_answer: 'No answer', voicemail: 'Voicemail / third person', other: 'Other',
};

const REASON_KEYWORD_RULES: [CallReason, RegExp][] = [
  ['wrong_contact', /wrong (number|contact|person)|left the company|رقم غلط|مش هو|ساب الشركة/i],
  ['not_interested', /not interested|no interest|refus|declin|مش مهتم|مش عايز|رفض/i],
  ['price', /pric|cost|expensive|discount|budget|سعر|غالي|تكلف|خصم/i],
  ['callback', /call ?back|later|ring back|كلمني|بعدين|اتصل تاني/i],
  ['timing', /next (week|month|quarter)|not now|busy|الشهر الجاي|مشغول|مش دلوقتي/i],
  ['interested', /interest|agree|wants|requested|confirm|great|مهتم|موافق|عايز/i],
  ['no_answer', /no answer|nobody|didn.t answer|مفيش رد|محدش رد/i],
  ['voicemail', /voicemail|assistant|secretary|message|سكرتير/i],
];

export function classifyComment(text: string, type: 'nvm' | 'lvm' | 'discovery'): CallReason {
  for (const [reason, re] of REASON_KEYWORD_RULES) if (re.test(text)) return reason;
  return type === 'nvm' ? 'no_answer' : type === 'lvm' ? 'voicemail' : 'other';
}

export function reasonCounts(leads: Lead[]): { reason: CallReason; count: number; share: number }[] {
  const counts = new Map<CallReason, number>();
  let total = 0;
  for (const l of leads) for (const c of l.callLogs) {
    const r = c.reason ?? classifyComment(c.description, c.type);
    counts.set(r, (counts.get(r) ?? 0) + 1); total++;
  }
  return [...counts.entries()].map(([reason, count]) => ({ reason, count, share: pct(count, total) })).sort((a, b) => b.count - a.count);
}

```

---

## `src/domain/analytics/dataQuality.ts`

```ts
/** Warnings about data that makes the numbers unreliable. */
import { hasReachedPerson } from '@/domain/analytics/performanceMetrics';
import type { Lead, Sale } from '@/domain/types';

// ---------------------------------------------------------------------------
// Data quality: things that make the numbers unreliable
// ---------------------------------------------------------------------------
export interface QualityIssue { id: string; level: 'warn' | 'info'; text: string }

export function findDataQualityIssues(leads: Lead[], sales: Sale[]): QualityIssue[] {
  const byId = new Map(leads.map(l => [l.id, l]));
  const out: QualityIssue[] = [];
  const noLead = sales.filter(s => !s.leadId || !byId.has(s.leadId));
  if (noLead.length) out.push({ id: 'sale-no-lead', level: 'warn', text: `${noLead.length} sale(s) are not linked to a lead, so they are missing from campaign and agent analysis.` });
  const unreached = sales.filter(s => { const l = byId.get(s.leadId); return l && !hasReachedPerson(l); });
  if (unreached.length) out.push({ id: 'sale-unreached', level: 'warn', text: `${unreached.length} sale(s) belong to leads nobody has reached yet (${unreached.map(s => s.leadName).join(', ')}).` });
  const mismatch = sales.filter(s => { const l = byId.get(s.leadId); return l && l.agentId !== s.agentId; });
  if (mismatch.length) out.push({ id: 'sale-agent', level: 'info', text: `${mismatch.length} sale(s) are credited to a different agent than the lead's current owner (usually after a transfer).` });
  const noReason = leads.reduce((n, l) => n + l.callLogs.filter(c => !c.reason).length, 0);
  const all = leads.reduce((n, l) => n + l.callLogs.length, 0);
  if (noReason) out.push({ id: 'no-reason', level: 'info', text: `${noReason} of ${all} calls have no structured reason; they are classified from the comment text.` });
  const dup = new Set<string>(); const seen = new Set<string>();
  for (const s of sales) { const k = `${s.leadId}|${s.saleType}|${s.date}`; if (seen.has(k)) dup.add(k); seen.add(k); }
  if (dup.size) out.push({ id: 'dup-sale', level: 'warn', text: `${dup.size} possible duplicate sale(s): same lead, type and date.` });
  return out;
}

```

---

## `src/domain/analytics/dateRange.ts`

```ts
/** The period an Analytics screen looks at: today, this week, this month or any custom from-to. */
import type { Lead } from '@/domain/types';
import { localDateStr } from '@/shared/lib/dates';

export type PeriodPreset = 'today' | 'week' | 'month' | 'custom';

/** Both ends are local days (YYYY-MM-DD) and both are included. */
export interface DateRange { from: string; to: string }

/** The week starts on Saturday (Egypt). Change this to 1 for a Monday week. */
const WEEK_STARTS_ON = 6;

const addDays = (d: Date, n: number) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };

export function resolveRange(preset: PeriodPreset, custom: DateRange, now = new Date()): DateRange {
  if (preset === 'today') { const t = localDateStr(now); return { from: t, to: t }; }
  if (preset === 'week') {
    const back = (now.getDay() - WEEK_STARTS_ON + 7) % 7;
    const start = addDays(now, -back);
    return { from: localDateStr(start), to: localDateStr(addDays(start, 6)) };
  }
  if (preset === 'month') {
    const y = now.getFullYear(), m = now.getMonth();
    return { from: localDateStr(new Date(y, m, 1)), to: localDateStr(new Date(y, m + 1, 0)) };
  }
  // custom: an empty or reversed range is fixed instead of showing nothing
  const from = custom.from || custom.to || localDateStr(now);
  const to = custom.to || from;
  return from <= to ? { from, to } : { from: to, to: from };
}

export const dayOf = (iso: string) => localDateStr(new Date(iso));
export const isInRange = (day: string, r: DateRange) => day >= r.from && day <= r.to;

/**
 * The leads as they looked during the period: only the calls made in the period are kept, and "reached" means a
 * Discovery call in the period. A lead is included when it had a call in the period, was given to the agent in the
 * period, or is in `keepIds` (leads sold in the period).
 */
export function leadsForPeriod(leads: Lead[], r: DateRange, keepIds: Set<string>): Lead[] {
  const out: Lead[] = [];
  for (const l of leads) {
    const callLogs = l.callLogs.filter(c => isInRange(dayOf(c.timestamp), r));
    const assignedNow = !!l.assignedAt && isInRange(dayOf(l.assignedAt), r);
    if (!callLogs.length && !assignedNow && !keepIds.has(l.id)) continue;
    out.push({ ...l, callLogs, status: 'new', discoveryReached: callLogs.some(c => c.type === 'discovery') });
  }
  return out;
}

```

---

## `src/domain/analytics/performanceMetrics.ts`

```ts
/** Call, funnel and group metrics (pure functions of the store data). */
import type { Lead, Meeting, Sale, User } from '@/domain/types';

export const pct = (n: number, d: number) => (d > 0 ? Math.round((n / d) * 1000) / 10 : 0);

/** The right person was reached at least once (a discovery call, or a meeting was arranged). */
export const hasReachedPerson = (l: Lead) =>
  !!l.discoveryReached || l.status === 'discovery' || l.status === 'arranged_meeting' ||
  l.callLogs.some(c => c.type === 'discovery');

export interface CallStats { calls: number; nvm: number; lvm: number; discovery: number; answerRate: number; reachRate: number }

export function callStats(leads: Lead[]): CallStats {
  let nvm = 0, lvm = 0, discovery = 0;
  for (const l of leads) for (const c of l.callLogs) {
    if (c.type === 'nvm') nvm++; else if (c.type === 'lvm') lvm++; else discovery++;
  }
  const calls = nvm + lvm + discovery;
  return { calls, nvm, lvm, discovery, answerRate: pct(lvm + discovery, calls), reachRate: pct(discovery, calls) };
}

export interface Funnel { leads: number; contacted: number; reached: number; meetings: number; sold: number }

export function funnel(leads: Lead[], meetings: Meeting[], sales: Sale[]): Funnel {
  const ids = new Set(leads.map(l => l.id));
  const meetingLeads = new Set(meetings.filter(m => m.type === 'lead_meeting' && m.leadId && ids.has(m.leadId)).map(m => m.leadId));
  const soldLeads = new Set(sales.filter(s => ids.has(s.leadId)).map(s => s.leadId));
  return {
    leads: leads.length,
    contacted: leads.filter(l => l.callLogs.length > 0).length,
    reached: leads.filter(hasReachedPerson).length,
    meetings: meetingLeads.size,
    sold: soldLeads.size,
  };
}

export interface GroupRow extends CallStats {
  key: string; label: string; leads: number; reached: number; sold: number; sales: number;
  conversion: number;       // sold leads / leads
  reachToSale: number;      // sold leads / reached leads
  callsPerLead: number;
}

function buildGroupRow(key: string, label: string, leads: Lead[], sales: Sale[]): GroupRow {
  const ids = new Set(leads.map(l => l.id));
  const mine = sales.filter(s => ids.has(s.leadId));
  const sold = new Set(mine.map(s => s.leadId)).size;
  const reached = leads.filter(hasReachedPerson).length;
  const cs = callStats(leads);
  return {
    key, label, ...cs, leads: leads.length, reached, sold, sales: mine.length,
    conversion: pct(sold, leads.length), reachToSale: pct(sold, reached),
    callsPerLead: leads.length ? Math.round((cs.calls / leads.length) * 10) / 10 : 0,
  };
}

export const byCampaign = (leads: Lead[], sales: Sale[], label: (code: string) => string) =>
  [...new Set(leads.map(l => l.campaignCode))].sort()
    .map(code => buildGroupRow(code, label(code), leads.filter(l => l.campaignCode === code), sales));

export const byAgent = (leads: Lead[], sales: Sale[], agents: User[]) =>
  agents.map(a => buildGroupRow(a.id, a.name, leads.filter(l => l.agentId === a.id), sales));

/** Best time to call: answer / reach rate per hour of the day. */
export interface HourBucket { hour: number; calls: number; answered: number; reached: number; reachRate: number }

export function byHour(leads: Lead[]): HourBucket[] {
  const map = new Map<number, HourBucket>();
  for (const l of leads) for (const c of l.callLogs) {
    const h = new Date(c.timestamp).getHours();
    const b = map.get(h) ?? { hour: h, calls: 0, answered: 0, reached: 0, reachRate: 0 };
    b.calls++;
    if (c.type !== 'nvm') b.answered++;
    if (c.type === 'discovery') b.reached++;
    map.set(h, b);
  }
  return [...map.values()].map(b => ({ ...b, reachRate: pct(b.reached, b.calls) })).sort((a, b) => a.hour - b.hour);
}

```

---

## `src/domain/email/fillEmailTemplate.ts`

```ts
/** Fills [Name], [Company Name] and [Agent Name] in an email template. */
import type { Lead } from '@/domain/types';

/** Fills [Name], [Company Name] and [Agent Name] in an email template. */
export const fillEmailTemplate = (text: string, lead: Lead, agentName: string) => text
  .replace(/\[Name\]/g, lead.contactName || 'there')
  .replace(/\[Company Name\]/g, lead.companyName)
  .replace(/\[Agent Name\]/g, agentName);

```

---

## `src/domain/lead/createPoolLead.ts`

```ts
/** A brand new lead in the pool: no agent, no workflow yet. */
import type { Lead } from '@/domain/types';

/** A brand new lead in the pool: no agent, no workflow yet (it starts when an agent takes it). */
export function createPoolLead(
  adminId: string, adminName: string,
  f: { leadCode: string; campaignCode: string; companyName: string; contactName: string; phone: string; email: string },
): Lead {
  const now = new Date().toISOString();
  return {
    id: crypto.randomUUID(), ...f,
    status: 'new', agentId: '', assignedAt: now, touchPoints: [], currentTouchPoint: -1, callLogs: [],
    history: [{ id: crypto.randomUUID(), action: 'created', timestamp: now, userId: adminId, userName: adminName, detail: 'Lead created by the Admin (in the pool)' }],
    stopped: false, removedFromQueue: false, removedAt: null,
  };
}

```

---

## `src/domain/lead/leadCode.ts`

```ts
/** Lead code rules: how a lead code is cleaned, compared and validated. */
export const MAX_ROWS_PER_IMPORT = 1000;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const INVISIBLE = /[\u200B-\u200F\u202A-\u202E\u2060\uFEFF\u00AD]/g;

/** Trim, drop invisible characters / surrounding quotes (Excel and web pages add them) and collapse spaces. This is what gets stored. */
export const cleanLeadCode = (code: string) =>
  code.replace(INVISIBLE, '').normalize('NFKC').trim().replace(/^["'“”‘’]+|["'“”‘’]+$/g, '').trim().replace(/\s+/g, ' ');

/**
 * The identity of a lead = its letters and digits, in the same order. Upper / lower case does not matter.
 *   "acd123" = "AcD123" = "ACD-123" = "acd 123"      (same letters and digits, same order)
 *   "LD-001" is NOT "LD-1"  and  "ABC12" is NOT "ABC21"  (different digits / different order)
 * The campaign, company name, phone and email are NOT part of the identity.
 */
export const normalizeLeadCode = (code: string) => cleanLeadCode(code).toUpperCase().replace(/[^\p{L}\p{N}]/gu, '');

/** A lead id is accepted only when it is made of letters and digits and nothing else (no spaces, dashes or symbols). */
export const isValidLeadCode = (code: string) => /^[\p{L}\p{N}]+$/u.test(cleanLeadCode(code));

export const isValidEmail = (email: string) => EMAIL_RE.test(email);

```

---

## `src/domain/lead/leadImport.ts`

```ts
/** Pasting leads in bulk: turns spreadsheet text into accepted rows + rejected rows with a reason. */
import { MAX_ROWS_PER_IMPORT, cleanLeadCode, isValidEmail, isValidLeadCode, normalizeLeadCode } from '@/domain/lead/leadCode';

export interface ExistingLead { leadCode: string; agentId: string }

export interface ParsedLeadRow {
  line: number;          // 1-based line number in what the user pasted
  raw: string;
  leadCode: string;
  companyName: string;
  contactName: string;
  phone: string;
  email: string;
}

export interface RejectedRow {
  line: number;
  raw: string;
  leadCode: string;
  reason: string;
}

export interface ParseResult { accepted: ParsedLeadRow[]; rejected: RejectedRow[] }

/**
 * A pasted spreadsheet row is tab separated. But in a plain text box people type, and there the Tab key moves the
 * focus instead of typing a tab - so a line WITHOUT a tab is also understood:
 *   "AB12 Nile Trading"    -> id "AB12", company "Nile Trading"   (the id is the first word)
 *   "AB12, Nile, Ali, ..." -> comma / semicolon separated columns
 */
function splitPastedRow(line: string): string[] {
  if (line.includes('\t')) return line.split('\t').map(p => p.trim());
  if (/[,;]/.test(line)) return line.split(/[,;]/).map(p => p.trim());
  const m = line.trim().match(/^(\S+)\s+(.*)$/);
  return m ? [m[1], m[2].trim()] : [line.trim()];
}

/**
 * Turns pasted spreadsheet text (tab separated) into valid rows + rejected rows WITH a reason.
 * Columns: Lead Code | Company | Contact | Phone | Email
 *  - a header line ("Lead Code ...") is ignored
 *  - the code must be new for the whole system (every agent), not only inside the paste
 *  - an email, when given, must look like an email
 */
export function parseLeadRows(
  text: string,
  existing: ExistingLead[],
  currentAgentId: string,
  agentNameOf: (agentId: string) => string,
): ParseResult {
  const owner = new Map<string, string>();                       // normalized code -> agentId
  for (const l of existing) owner.set(normalizeLeadCode(l.leadCode), l.agentId);

  const seenInPaste = new Set<string>();
  const accepted: ParsedLeadRow[] = [];
  const rejected: RejectedRow[] = [];

  const lines = text.split(/\r?\n/);
  let dataRows = 0;
  lines.forEach((rawLine, i) => {
    if (!rawLine.trim()) return;
    const line = i + 1;
    const parts = splitPastedRow(rawLine);
    const code = cleanLeadCode(parts[0] ?? '');

    // header row copied together with the data
    if (dataRows === 0 && accepted.length === 0 && rejected.length === 0 && /^(lead\s*)?(code|id)$/i.test(code)) return;

    const reject = (reason: string) => rejected.push({ line, raw: rawLine, leadCode: code, reason });

    dataRows++;
    if (dataRows > MAX_ROWS_PER_IMPORT) return reject(`Over the limit of ${MAX_ROWS_PER_IMPORT} leads per import`);
    if (!code) return reject('Lead code is missing');

    if (!isValidLeadCode(code)) return reject('Lead ID must contain letters and numbers only');

    const key = normalizeLeadCode(code);
    if (seenInPaste.has(key)) return reject('Repeated in this paste');
    const ownerId = owner.get(key);
    if (ownerId !== undefined) {
      return reject(ownerId === currentAgentId
        ? 'Already in your leads'
        : `Already assigned to ${agentNameOf(ownerId) || 'another agent'}`);
    }

    const email = parts[4] ?? '';
    if (email && !isValidEmail(email)) return reject(`Invalid email "${email}"`);

    seenInPaste.add(key);
    accepted.push({
      line, raw: rawLine, leadCode: code,
      companyName: parts[1] || code,
      contactName: parts[2] || '',
      phone: parts[3] || '',
      email,
    });
  });

  return { accepted, rejected };
}

/** Keeps only leads whose code is not taken yet (reducer-level safety net, same rule as above). */
export function dropTakenLeadCodes<T extends { leadCode: string }>(incoming: T[], existing: { leadCode: string }[]): T[] {
  const taken = new Set(existing.map(l => normalizeLeadCode(l.leadCode)));
  const out: T[] = [];
  for (const l of incoming) {
    const k = normalizeLeadCode(l.leadCode);
    if (!isValidLeadCode(l.leadCode) || taken.has(k)) continue;
    taken.add(k);
    out.push(l);
  }
  return out;
}

// ---------------------------------------------------------------------------
// Shared lead pool
//  - only the Admin creates leads; they go to the pool (agentId = '')
//  - an agent TAKES leads from the pool by lead id; from then on the lead is theirs
//  - a lead the agent removes keeps its history and goes back to the pool (its id is free again)
// ---------------------------------------------------------------------------

export interface ParsedAdminRow extends ParsedLeadRow { campaignCode: string }

export interface ParseAdminResult { accepted: ParsedAdminRow[]; rejected: RejectedRow[] }

/**
 * Admin paste: Lead ID | Company | Contact | Phone | Email | Campaign (code or name; optional, falls back to the default).
 * Every id is checked against ALL leads of the system (an agent's, a pool lead, or a removed lead that is back in the pool).
 */
export function parseAdminRows(
  text: string,
  existingCodes: { leadCode: string }[],
  workflows: { campaignCode: string; name: string }[],
  defaultCampaign: string,
): ParseAdminResult {
  const taken = new Set(existingCodes.map(l => normalizeLeadCode(l.leadCode)));
  const seen = new Set<string>();
  const accepted: ParsedAdminRow[] = [];
  const rejected: RejectedRow[] = [];
  const campaignOf = (v: string) => {
    const q = v.trim().toLowerCase();
    return workflows.find(w => w.campaignCode.toLowerCase() === q || w.name.toLowerCase() === q)?.campaignCode;
  };

  let dataRows = 0;
  text.split(/\r?\n/).forEach((rawLine, i) => {
    if (!rawLine.trim()) return;
    const line = i + 1;
    const parts = splitPastedRow(rawLine);
    const code = cleanLeadCode(parts[0] ?? '');
    if (dataRows === 0 && /^(lead\s*)?(code|id)$/i.test(code)) return;
    const reject = (reason: string) => rejected.push({ line, raw: rawLine, leadCode: code, reason });

    dataRows++;
    if (dataRows > MAX_ROWS_PER_IMPORT) return reject(`Over the limit of ${MAX_ROWS_PER_IMPORT} leads per import`);
    if (!code) return reject('Lead code is missing');
    if (!isValidLeadCode(code)) return reject('Lead ID must contain letters and numbers only');
    const key = normalizeLeadCode(code);
    if (seen.has(key)) return reject('Repeated in this paste');
    if (taken.has(key)) return reject('This lead ID already exists');
    const email = parts[4] ?? '';
    if (email && !isValidEmail(email)) return reject(`Invalid email "${email}"`);
    const campaignCell = (parts[5] ?? '').trim();
    const campaignCode = campaignCell ? campaignOf(campaignCell) : defaultCampaign;
    if (!campaignCode) return reject(`Unknown campaign "${campaignCell}"`);

    seen.add(key);
    accepted.push({
      line, raw: rawLine, leadCode: code, campaignCode,
      companyName: parts[1] || code, contactName: parts[2] || '', phone: parts[3] || '', email,
    });
  });
  return { accepted, rejected };
}

```

---

## `src/domain/lead/leadPool.ts`

```ts
/** The shared lead pool: who can take which lead, and what would happen to each id typed by an agent. */
import { MAX_ROWS_PER_IMPORT, cleanLeadCode, normalizeLeadCode } from '@/domain/lead/leadCode';

interface PoolLeadLike { id: string; leadCode: string; agentId: string; removedFromQueue: boolean }

/** Nobody owns it: it was created by the Admin, or the agent removed it. Any agent can take it. */
export const isInPool = (l: Pick<PoolLeadLike, 'agentId' | 'removedFromQueue'>) => !l.agentId || l.removedFromQueue;

/** Lead ids typed / pasted one under the other. A spreadsheet row (tab separated) counts as its first cell; commas / semicolons also separate ids. */
export function splitLeadIds(text: string): { line: number; code: string }[] {
  const out: { line: number; code: string }[] = [];
  text.split(/\r?\n/).forEach((rawLine, i) => {
    if (!rawLine.trim()) return;
    const cells = rawLine.includes('\t') ? [rawLine.split('\t')[0]] : rawLine.split(/[,;]/);
    for (const c of cells) {
      const code = cleanLeadCode(c);
      if (!code) continue;
      if (out.length === 0 && /^(lead\s*)?(code|id)$/i.test(code)) continue;   // copied header
      out.push({ line: i + 1, code });
    }
  });
  return out;
}

export type ClaimStatus = 'ready' | 'mine' | 'taken' | 'not_found' | 'invalid' | 'duplicate' | 'over_limit';

export interface ClaimResult {
  line: number;
  code: string;
  status: ClaimStatus;
  leadId?: string;       // the lead to take (status 'ready') or the lead that was found
  holderName?: string;   // when status is 'taken'
}

/** Looks one id up. The holder (active lead) always wins over an older removed copy with the same id. */
function findLeadHolderByCode<T extends PoolLeadLike>(leads: T[], key: string) {
  let pool: T | undefined;
  for (const l of leads) {
    if (normalizeLeadCode(l.leadCode) !== key) continue;
    if (!isInPool(l)) return { holder: l, pool: undefined };
    pool = l;
  }
  return { holder: undefined, pool };
}

/** What would happen to each id if this agent took it. Pure: the UI shows it live, the reducer re-checks it. */
export function planTakeFromPool<T extends PoolLeadLike>(
  ids: { line: number; code: string }[], leads: T[], agentId: string, agentNameOf: (id: string) => string,
): ClaimResult[] {
  const seen = new Set<string>();
  let ready = 0;
  return ids.map(({ line, code }): ClaimResult => {
    const key = normalizeLeadCode(code);
    if (!key) return { line, code, status: 'invalid' };   // lookup is lenient: "LD-013", "ld013" and "LD 013" all find the same lead
    if (seen.has(key)) return { line, code, status: 'duplicate' };
    seen.add(key);
    const { holder, pool } = findLeadHolderByCode(leads, key);
    if (holder) {
      return holder.agentId === agentId
        ? { line, code, status: 'mine', leadId: holder.id }
        : { line, code, status: 'taken', leadId: holder.id, holderName: agentNameOf(holder.agentId) || 'another agent' };
    }
    if (!pool) return { line, code, status: 'not_found' };
    if (ready >= MAX_ROWS_PER_IMPORT) return { line, code, status: 'over_limit', leadId: pool.id };
    ready++;
    return { line, code, status: 'ready', leadId: pool.id };
  });
}

export const CLAIM_STATUS_TEXT: Record<ClaimStatus, string> = {
  ready: 'Ready to add',
  mine: 'Already in your leads',
  taken: 'Held by another agent',
  not_found: 'Not found in the pool',
  invalid: 'Not a valid lead ID',
  duplicate: 'Repeated in this list',
  over_limit: `Over the limit of ${MAX_ROWS_PER_IMPORT} leads at once`,
};

```

---

## `src/domain/meeting/meetingTime.ts`

```ts
/** Meeting time helpers. */
import type { Meeting } from '@/domain/types';

export const meetingStartMs = (m: Pick<Meeting, 'date' | 'time'>) => new Date(`${m.date}T${m.time}:00`).getTime();

```

---

## `src/domain/sales/saleMigration.ts`

```ts
/** Upgrades sales saved by older versions of the app. */
import { SALE_TYPES } from '@/domain/sales/saleTypes';
import type { Sale, SaleType } from '@/domain/types';

/** Old saved sales used 'new' / 'upsell' / 'renewal' and had a "product" text: convert them to the current shape. */
export function migrateSale(x: Sale & { product?: string }): Sale {
  const legacy: Record<string, SaleType> = { new: 'Activation', upsell: 'Activation', renewal: 'Retention' };
  const valid = SALE_TYPES.some(t => t.value === x.saleType);
  const { product: _product, ...rest } = x;
  return { ...rest, saleType: valid ? x.saleType : (legacy[x.saleType as string] ?? 'Activation') };
}

```

---

## `src/domain/sales/saleTypes.ts`

```ts
/** The list of sale types and how to count them. */
import type { Sale, SaleType } from '@/domain/types';

export const SALE_TYPES: { value: SaleType; label: string; chip: string }[] = [
  { value: 'BP', label: 'BP', chip: 'bg-emerald-100 text-emerald-700' },
  { value: 'PPI', label: 'PPI', chip: 'bg-violet-100 text-violet-700' },
  { value: 'MUA', label: 'MUA', chip: 'bg-blue-100 text-blue-700' },
  { value: 'ATEP', label: 'ATEP', chip: 'bg-amber-100 text-amber-700' },
  { value: 'Activation', label: 'Activation', chip: 'bg-cyan-100 text-cyan-700' },
  { value: 'Retention', label: 'Retention', chip: 'bg-rose-100 text-rose-700' },
  { value: 'Transition', label: 'Transition', chip: 'bg-slate-100 text-slate-700' },
];

export const saleTypeConfig = (t: SaleType) => SALE_TYPES.find(x => x.value === t) ?? SALE_TYPES[0];

export function countByType(sales: Sale[]): Record<SaleType, number> {
  const out = Object.fromEntries(SALE_TYPES.map(t => [t.value, 0])) as Record<SaleType, number>;
  for (const s of sales) if (s.saleType in out) out[s.saleType]++;
  return out;
}

```

---

## `src/domain/sales/salesLeaderboard.ts`

```ts
/** Monthly ranking of agents by sales (ties: more Discovery calls, then more LVM calls). */
import type { Lead, Sale, User } from '@/domain/types';
import { localDateStr } from '@/shared/lib/dates';

export interface AgentRank {
  agent: User;
  sales: number;
  discovery: number;   // used only to break ties
  lvm: number;         // used only to break ties
}

/** Discovery / LVM calls an agent logged during the month (local calendar month, YYYY-MM). */
export function monthlyCallCounts(leads: Lead[], agentId: string, month: string) {
  let discovery = 0;
  let lvm = 0;
  for (const lead of leads) {
    for (const cl of lead.callLogs) {
      if ((cl.agentId ?? lead.agentId) !== agentId) continue;
      if (localDateStr(new Date(cl.timestamp)).slice(0, 7) !== month) continue;
      if (cl.type === 'discovery') discovery++;
      else if (cl.type === 'lvm') lvm++;
    }
  }
  return { discovery, lvm };
}

/** Top agents of the month. Agents with no sales are left out. */
export function topAgentsOfMonth(agents: User[], sales: Sale[], leads: Lead[], month: string, limit = 5): AgentRank[] {
  const monthSales = sales.filter(s => s.date.startsWith(month));
  return agents
    .map(agent => ({
      agent,
      sales: monthSales.filter(s => s.agentId === agent.id).length,
      ...monthlyCallCounts(leads, agent.id, month),
    }))
    .filter(r => r.sales > 0)
    .sort((a, b) =>
      b.sales - a.sales
      || b.discovery - a.discovery
      || b.lvm - a.lvm
      || a.agent.name.localeCompare(b.agent.name))
    .slice(0, limit);
}

```

---

## `src/domain/sales/salesTargets.ts`

```ts
/** Monthly sales targets. */
import type { Team } from '@/domain/types';

/** Monthly sales target for ONE agent. Team Leader = agents x this. Operation Manager = sum of their teams. */
export const AGENT_SALES_TARGET = 28;

export const teamSalesTarget = (team: Pick<Team, 'agentIds'>) => team.agentIds.length * AGENT_SALES_TARGET;

```

---

## `src/domain/types/callLog.ts`

```ts
/** What happened on a phone call. */
export type CallType = 'nvm' | 'lvm' | 'discovery';

// Structured outcome reason for a call. Optional: when it is empty the analytics fall back to reading the comment text.
export type CallReason =
  | 'interested' | 'callback' | 'price' | 'timing' | 'not_interested' | 'wrong_contact' | 'no_answer' | 'voicemail' | 'other';

export interface CallLog {
  id: string;
  type: CallType;
  reason?: CallReason;
  description: string;
  timestamp: string;
  editedAt?: string;   // set when the agent edits the log; `timestamp` stays the real time of the call
  touchPointOrder: number;
  // Filled automatically by the store so a log always says who/which step/which round
  agentId?: string;
  agentName?: string;
  touchPointLabel?: string;
  round?: number;
}

```

---

## `src/domain/types/email.ts`

```ts
/** Email templates and the log of every email sent. */
export interface EmailTemplate {
  id: string;
  name: string;
  type: 'discovery' | 'no_response';
  subject: string;
  body: string;
}

export interface EmailLog {
  id: string;
  leadId: string;
  leadName: string;
  to: string;
  subject: string;
  body: string;
  templateType: 'discovery' | 'no_response' | 'custom';
  sentAt: string;
  sentBy: string;
  sentByName: string;
  auto?: boolean;            // sent by the system when the email touch point came due
  idempotencyKey?: string;   // the same touch point can never produce two automatic emails
}

```

---

## `src/domain/types/index.ts`

```ts
/** One import path for every business type: `import type { Lead } from '@/domain/types'`. */
export * from './user';
export * from './team';
export * from './workflow';
export * from './callLog';
export * from './lead';
export * from './meeting';
export * from './teamUpdate';
export * from './task';
export * from './email';
export * from './notification';
export * from './sale';

```

---

## `src/domain/types/lead.ts`

```ts
/** The lead: the central record of the whole system. */
import type { CallLog } from '@/domain/types/callLog';
import type { TouchPoint, TouchPointType } from '@/domain/types/workflow';

export type LeadStatus = 'new' | 'discovery' | 'lvm' | 'nvm' | 'no_response' | 'arranged_meeting';

export interface LeadHistoryEntry {
  id: string;
  action: string;
  timestamp: string;
  userId: string;
  userName: string;
  detail?: string;
  // Extra context so the history can be filtered/reported on later
  round?: number;                 // which assignment round (1 = first agent, 2 = after 1st transfer ...)
  agentId?: string;               // the agent who owned the lead when this happened
  touchPointOrder?: number;
  touchPointLabel?: string;
  touchPointType?: TouchPointType;
  meta?: Record<string, unknown>; // free-form data for future features
}

// A closed assignment: everything the previous agent had on this lead
export interface LeadAssignment {
  round: number;
  agentId: string;
  agentName: string;
  assignedAt: string;
  endedAt: string;
  endedBy: string;
  endedByName: string;
  touchPoints: TouchPoint[];      // frozen snapshot of that agent's touch points
}

export interface Lead {
  id: string;
  leadCode: string;
  campaignCode: string;
  companyName: string;
  contactName: string;
  phone: string;
  email: string;
  status: LeadStatus;
  agentId: string;                         // '' while the lead sits in the shared pool (created by the Admin, nobody owns it yet)
  assignedAt: string;
  touchPoints: TouchPoint[];
  currentTouchPoint: number;
  callLogs: CallLog[];
  history: LeadHistoryEntry[];
  stopped: boolean;
  removedFromQueue: boolean;
  removedAt: string | null;
  round?: number;                          // current round, defaults to 1
  previousAssignments?: LeadAssignment[];  // archived rounds (old agents' touch points)
  expiredAt?: string | null;               // set by the 15-day rule: out of the agent's queue, waiting for the TL to reassign
  lastActivityAt?: string;                 // last time the lead was assigned / stopped / resumed / came back from a meeting
  discoveryReached?: boolean;              // a meeting was arranged, so the person was reached (counts as Discovery)
}

```

---

## `src/domain/types/meeting.ts`

```ts
/** Meetings (with a lead, or internal). */
export type MeetingStatus = 'arranged' | 'completed' | 'no_show' | 'cancelled' | 'rescheduled';

export type MeetingType = 'lead_meeting' | 'internal_meeting';

export interface Meeting {
  id: string;
  type: MeetingType;
  leadId?: string;
  leadName?: string;
  companyName?: string;
  agentId?: string;
  participantIds: string[];
  participantNames: string[];
  title: string;
  date: string;
  time: string;
  duration: number;
  notes: string;                  // the agenda written when the meeting was scheduled
  outcome?: string;               // what happened: REQUIRED when a meeting with a lead is marked Completed
  status: MeetingStatus;
  priority: 'high' | 'normal';
  createdBy: string;
  reminderSentAt?: string | null;  // the 15-minute reminder was already sent (prevents duplicates)
}

```

---

## `src/domain/types/notification.ts`

```ts
/** In-app notifications. */
export interface Notification {
  id: string;
  type: 'meeting' | 'update' | 'task' | 'overdue' | 'email';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  leadId?: string;
  meetingId?: string;
  userId?: string;   // when set, only this user sees the notification
}

```

---

## `src/domain/types/sale.ts`

```ts
/** Sales recorded by the Quality role. */
// ---------------------------------------------------------------------------
// Sales (recorded by the Quality role)
// ---------------------------------------------------------------------------
export type SaleType = 'BP' | 'PPI' | 'MUA' | 'ATEP' | 'Activation' | 'Retention' | 'Transition';

export interface Sale {
  id: string;
  agentId: string;
  leadId: string;         // REQUIRED: the lead is the identity of a sale (company names can repeat). Campaign is derived from it.
  leadName: string;       // snapshot of the company name at the time of the sale (display only)
  saleType: SaleType;
  date: string;           // YYYY-MM-DD, the day the sale happened
  createdBy: string;      // the quality user who recorded it
  createdAt: string;
}

```

---

## `src/domain/types/task.ts`

```ts
/** Tasks assigned by managers. */
export interface Task {
  id: string;
  authorId: string;
  authorName: string;
  title: string;
  description: string;
  createdAt: string;
  deadline: string;
  assignedTo: string[];
  completedBy: string[];
}

```

---

## `src/domain/types/team.ts`

```ts
/** A team: one leader, several agents, one operation manager. */
export interface Team {
  id: string;
  name: string;
  leaderId: string;
  agentIds: string[];
  managerId: string;
}

```

---

## `src/domain/types/teamUpdate.ts`

```ts
/** Announcements from managers to teams. */
export type UpdateAudience = 'all' | 'team_leaders' | 'specific_team';

export interface TeamUpdate {
  id: string;
  audience: UpdateAudience;
  teamId: string | null;
  authorId: string;
  authorName: string;
  title: string;
  content: string;
  createdAt: string;
  acknowledgedBy: string[];
}

```

---

## `src/domain/types/user.ts`

```ts
/** Who can sign in and what role they have. */
export type UserRole = 'admin' | 'operation_manager' | 'team_leader' | 'agent' | 'quality';

export interface User {
  id: string;
  username: string;
  name: string;
  email: string;
  role: UserRole;
  teamId?: string;
  initials: string;
  color: string;
  dailyCallTarget: number;
}

```

---

## `src/domain/types/workflow.ts`

```ts
/** A campaign workflow (the template) and the touch points a lead gets from it (the copy). */
export type TouchPointType = 'call' | 'email';

export interface TouchPointTemplate {
  order: number;
  type: TouchPointType;
  label: string;
  dayOffset: number;
}

export interface Workflow {
  id: string;
  campaignCode: string;
  name: string;
  touchPoints: TouchPointTemplate[];
}

export type TouchPointStatus = 'pending' | 'overdue' | 'completed' | 'skipped';

export interface TouchPoint {
  order: number;
  type: TouchPointType;
  label: string;
  dayOffset: number;
  status: TouchPointStatus;
  completedAt: string | null;
  dueDate: string | null;
  skippedAt?: string | null;
}

```

---

## `src/domain/user/roleLabel.ts`

```ts
import type { UserRole } from '@/domain/types';

/** The name of a role as the person sees it on screen. */
export function roleLabel(role: UserRole | string): string {
  switch (role) {
    case 'admin': return 'Admin';
    case 'operation_manager': return 'Operation Manager';
    case 'team_leader': return 'Team Leader';
    case 'agent': return 'Agent';
    case 'quality': return 'Quality';
    default: return role;
  }
}

```

---

## `src/domain/workflow/callClassification.ts`

```ts
/** Turns the calls an agent logged into a lead status / queue category (discovery > lvm > nvm). */
import type { CallType, Lead } from '@/domain/types';

/** Call logs that belong to the lead's CURRENT round (a transfer starts a new round). */
export function currentRoundCalls(lead: Lead) {
  const round = lead.round ?? 1;
  return lead.callLogs.filter(cl => (cl.round ?? 1) === round);
}

const CALL_RANK: Record<CallType, number> = { discovery: 3, lvm: 2, nvm: 1 };

/** Best call result so far: discovery > lvm > nvm. null when no call was logged yet. */
export function highestCallType(lead: Lead): CallType | null {
  let best: CallType | null = null;
  for (const cl of currentRoundCalls(lead)) {
    if (!best || CALL_RANK[cl.type] > CALL_RANK[best]) best = cl.type;
  }
  return best;
}

/** Best result so far. A lead that got a meeting arranged was reached, so it counts as Discovery. */
export function effectiveCallType(lead: Lead): CallType | null {
  return lead.discoveryReached ? 'discovery' : highestCallType(lead);
}

/**
 * Category used by the work queue (each one is its own section).
 *   no calls yet                -> new
 *   best result = discovery     -> discovery   (even if there is also an LVM)
 *   best result = lvm           -> lvm
 *   only NVM calls              -> nvm
 *   meeting arranged            -> meeting     (until the meeting day ends)
 */
export type QueueCategory = 'new' | 'discovery' | 'lvm' | 'nvm' | 'meeting';

export function queueCategory(lead: Lead): QueueCategory {
  if (lead.status === 'arranged_meeting') return 'meeting';
  return effectiveCallType(lead) ?? 'new';
}

/** The status stored on the lead after a call (never overrides an arranged meeting). */
export function statusFromCalls(lead: Lead): Lead['status'] {
  if (lead.status === 'arranged_meeting') return lead.status;
  return effectiveCallType(lead) ?? 'new';
}

```

---

## `src/domain/workflow/campaignLabel.ts`

```ts
/** Display name of a campaign. */
import type { Workflow } from '@/domain/types';

// ---------------------------------------------------------------------------
// Display names  ("Activation" instead of ACT-001, "1: CALL" instead of 1-call-ACT-001)
// ---------------------------------------------------------------------------
/** "Activation Campaign" -> "Activation". Falls back to the code when there is no workflow. */
export function campaignLabel(workflows: Workflow[], code: string): string {
  const wf = workflows.find(w => w.campaignCode === code);
  return (wf?.name ?? code).replace(/\s+campaign$/i, '').trim();
}

```

---

## `src/domain/workflow/leadExpiry.ts`

```ts
/** The 15-day rule: when does a lead without progress leave the agent's queue. */
import type { Lead } from '@/domain/types';
import { LEAD_EXPIRY_DAYS } from '@/domain/workflow/workflowRules';

// ---------------------------------------------------------------------------
// 15-day rule
// ---------------------------------------------------------------------------
/** The moment the 15 days are counted from: the latest of assignment, last completed touch point, stop/resume. */
export function expiryReferenceMs(lead: Lead): number {
  const stamps = [lead.assignedAt, lead.lastActivityAt]
    .filter((x): x is string => !!x).map(x => new Date(x).getTime());
  for (const tp of lead.touchPoints) if (tp.status === 'completed' && tp.completedAt) stamps.push(new Date(tp.completedAt).getTime());
  return Math.max(...stamps.filter(n => !isNaN(n)));
}

/** Whole days left before the lead leaves the queue (0 = today). */
export const daysUntilExpiry = (lead: Lead, now: number = Date.now()) =>
  Math.max(0, Math.ceil((expiryReferenceMs(lead) + LEAD_EXPIRY_DAYS * 86400000 - now) / 86400000));

```

---

## `src/domain/workflow/leadQueue.ts`

```ts
/** Which work-queue bucket a lead belongs to: today / next / stop / finished. */
import type { Lead, TouchPoint } from '@/domain/types';
import { findCurrentTouchPoint, isOpenTouchPoint } from '@/domain/workflow/touchPoints';
import { endOfDay, startOfDay } from '@/shared/lib/dates';

// ---------------------------------------------------------------------------
// Work queue buckets:  today  /  next  /  stop
// ---------------------------------------------------------------------------
export type QueueBucket = 'today' | 'next' | 'stop' | 'finished';

/**
 *   stopped lead                                -> stop
 *   no open touch point left                    -> finished
 *   due today (or already overdue)              -> today
 *   due tomorrow or later                       -> next
 */
export function queueBucket(lead: Lead, now: number = Date.now()): QueueBucket {
  if (lead.stopped) return 'stop';
  const tp = findCurrentTouchPoint(lead);
  if (!tp || !isOpenTouchPoint(tp)) return 'finished';
  if (!tp.dueDate) return 'today';
  return new Date(tp.dueDate).getTime() <= endOfDay(now).getTime() ? 'today' : 'next';
}

/** The moment a "next" lead moves into Today = the start of the day its touch point is due. */
export function becomesTodayAt(tp: TouchPoint | undefined): number | null {
  if (!tp?.dueDate) return null;
  return startOfDay(new Date(tp.dueDate)).getTime();
}

```

---

## `src/domain/workflow/touchPoints.ts`

```ts
/** Rules about touch points: which one is open, which one is current, when the next one is due. */
import type { Lead, TouchPoint } from '@/domain/types';

/** A touch point still waiting for the agent (not done, not skipped). */
export const isOpenTouchPoint = (tp: TouchPoint) => tp.status === 'pending' || tp.status === 'overdue';

/** The open touch point the lead is currently waiting on (undefined when the workflow is finished). */
export const findCurrentTouchPoint = (lead: Lead) => lead.touchPoints.find(t => t.order === lead.currentTouchPoint);

/**
 * Finds the first open touch point and gives it a fresh due date.
 * Workflow day offsets are cumulative (0, 1, 2, 4 ...), so the wait for a step is the GAP
 * from the previous step, counted forward from the moment the last touch point was done.
 */
export function scheduleNextTouchPoint(touchPoints: TouchPoint[]): { touchPoints: TouchPoint[]; next: TouchPoint | undefined } {
  const idx = touchPoints.findIndex(isOpenTouchPoint);
  if (idx === -1) return { touchPoints, next: undefined };
  const tp = touchPoints[idx];
  const prev = [...touchPoints].filter(t => t.order < tp.order).sort((a, b) => b.order - a.order)[0];
  const gapDays = Math.max(0, tp.dayOffset - (prev?.dayOffset ?? 0));
  const next = { ...tp, dueDate: new Date(Date.now() + gapDays * 86400000).toISOString() };
  return { touchPoints: touchPoints.map((x, i) => (i === idx ? next : x)), next };
}

export function describeDueDate(tp: TouchPoint | undefined): { label: string; tone: 'overdue' | 'today' | 'later' | 'none' } {
  if (!tp || !tp.dueDate) return { label: '', tone: 'none' };
  const due = new Date(tp.dueDate);
  const endOfToday = new Date(); endOfToday.setHours(23, 59, 59, 999);
  const startOfToday = new Date(); startOfToday.setHours(0, 0, 0, 0);
  if (due < startOfToday) {
    const d = Math.max(1, Math.round((startOfToday.getTime() - due.getTime()) / 86400000));
    return { label: `Overdue ${d}d`, tone: 'overdue' };
  }
  if (due <= endOfToday) return { label: 'Due today', tone: 'today' };
  const d = Math.ceil((due.getTime() - endOfToday.getTime()) / 86400000);
  return { label: `Due in ${d}d`, tone: 'later' };
}

/** When the agent last touched this lead (latest completed touch point of the current round). */
export function lastTouchTimestamp(lead: Lead): number | null {
  let best: number | null = null;
  for (const tp of lead.touchPoints) {
    if (tp.status !== 'completed' || !tp.completedAt) continue;
    const t = new Date(tp.completedAt).getTime();
    if (best === null || t > best) best = t;
  }
  return best;
}

/** "1: CALL" / "2: EMAIL" */
export const stepLabel = (order: number, type: string) => `${order + 1}: ${type.toUpperCase()}`;

```

---

## `src/domain/workflow/workflowRules.ts`

```ts
/** The business numbers agreed with the project owner (15-day rule, reminder time, auto-email switch). */
// ---------------------------------------------------------------------------
// Rules agreed with the project owner
// ---------------------------------------------------------------------------
/** A lead that makes no progress (same touch point, or stopped) for this many CALENDAR days leaves the agent's queue. */
export const LEAD_EXPIRY_DAYS = 15;

/** Reminder before an arranged meeting. */
export const MEETING_REMINDER_MINUTES = 15;

/** When an EMAIL touch point comes due the system sends it by itself (Discovery or No Response template). Set false to turn it off. */
export const AUTO_EMAIL_ENABLED = true;

```

---

## `src/features/analytics/AnalyticsPage.tsx`

```tsx
import { AlertTriangle, Info } from 'lucide-react';
import { useMemo, useState } from 'react';
import { REASON_LABEL, reasonCounts } from '@/domain/analytics/commentClassifier';
import { findDataQualityIssues } from '@/domain/analytics/dataQuality';
import { isInRange, leadsForPeriod, resolveRange } from '@/domain/analytics/dateRange';
import type { DateRange, PeriodPreset } from '@/domain/analytics/dateRange';
import { byAgent, byCampaign, byHour, callStats, funnel, pct } from '@/domain/analytics/performanceMetrics';
import { AGENT_SALES_TARGET } from '@/domain/sales/salesTargets';
import { campaignLabel } from '@/domain/workflow/campaignLabel';
import { CARD_CLASS } from '@/features/analytics/analyticsStyles';
import { GroupPerformanceTable } from '@/features/analytics/components/GroupPerformanceTable';
import { HorizontalBar } from '@/features/analytics/components/HorizontalBar';
import { KpiCard } from '@/features/analytics/components/KpiCard';
import { PeriodPicker } from '@/features/analytics/components/PeriodPicker';
import { localDateStr } from '@/shared/lib/dates';
import { useStore } from '@/store';

export function AnalyticsPage() {
  const { state } = useStore();
  const me = state.users.find(u => u.id === state.currentUserId);
  const [campaign, setCampaign] = useState('all');
  const [preset, setPreset] = useState<PeriodPreset>('month');
  const [custom, setCustom] = useState<DateRange>({ from: localDateStr(), to: localDateStr() });
  const range = useMemo(() => resolveRange(preset, custom), [preset, custom]);
  const isAgent = me?.role === 'agent';

  // Scope: a Team Leader sees their team, the Operation Manager sees every team they manage
  const scope = useMemo(() => {
    if (!me) return { agents: [], teamIds: [] as string[] };
    if (me.role === 'agent') return { agents: [me], teamIds: [] as string[] };   // an agent sees only their own numbers
    const teams = me.role === 'team_leader'
      ? state.teams.filter(t => t.leaderId === me.id)
      : state.teams.filter(t => t.managerId === me.id);
    const ids = new Set(teams.flatMap(t => t.agentIds));
    return { agents: state.users.filter(u => ids.has(u.id)), teamIds: teams.map(t => t.id) };
  }, [me, state.teams, state.users]);

  const agentIds = useMemo(() => new Set(scope.agents.map(a => a.id)), [scope.agents]);
  const campaigns = useMemo(() => state.workflows.map(w => w.campaignCode), [state.workflows]);

  // the agent's leads (and campaign), over all time; the period is applied on top of them
  const baseLeads = useMemo(
    () => state.leads.filter(l => agentIds.has(l.agentId) && (campaign === 'all' || l.campaignCode === campaign)),
    [state.leads, agentIds, campaign],
  );
  const baseIds = useMemo(() => new Set(baseLeads.map(l => l.id)), [baseLeads]);
  const sales = useMemo(
    () => state.sales.filter(s => baseIds.has(s.leadId) && isInRange(s.date, range)),
    [state.sales, baseIds, range],
  );
  const meetings = useMemo(() => state.meetings.filter(m => isInRange(m.date, range)), [state.meetings, range]);
  const leads = useMemo(
    () => leadsForPeriod(baseLeads, range, new Set(sales.map(s => s.leadId))),
    [baseLeads, range, sales],
  );

  const calls = callStats(leads);
  const f = funnel(leads, meetings, sales);
  const label = (c: string) => campaignLabel(state.workflows, c);
  const campaignRows = byCampaign(leads, sales, label);
  const agentRows = byAgent(leads, sales, scope.agents);
  const hours = byHour(leads);
  const reasons = reasonCounts(leads);
  const issues = findDataQualityIssues(state.leads.filter(l => agentIds.has(l.agentId)), state.sales.filter(s => agentIds.has(s.agentId)));

  const target = scope.agents.length * AGENT_SALES_TARGET;   // the sales target is monthly
  const periodName = { today: 'today', week: 'this week', month: 'this month', custom: 'the selected period' }[preset];
  const rangeText = range.from === range.to ? range.from : `${range.from} → ${range.to}`;
  const bestHour = [...hours].filter(h => h.calls >= 2).sort((a, b) => b.reachRate - a.reachRate || b.calls - a.calls)[0];

  const funnelSteps: [string, number][] = [
    ['Leads', f.leads], ['Contacted (at least one call)', f.contacted], ['Reached the right person', f.reached],
    ['Meeting arranged', f.meetings], ['Sold', f.sold],
  ];

  if (!me) return null;

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900">{isAgent ? 'My Analytics' : 'Analytics'}</h1>
          <p className="text-sm text-slate-600">
            {isAgent ? 'Your own numbers' : `${me.role === 'team_leader' ? 'Your team' : 'All your teams'} · ${scope.agents.length} agents`} · {leads.length} leads · {rangeText}
          </p>
        </div>
        <PeriodPicker preset={preset} custom={custom} onPreset={setPreset} onCustom={setCustom} />
        <select
          value={campaign} onChange={e => setCampaign(e.target.value)}
          className="px-3 py-2 rounded-lg border border-slate-200 text-sm bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="all">All campaigns</option>
          {campaigns.map(c => <option key={c} value={c}>{c} · {label(c)}</option>)}
        </select>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard label="Answer rate" value={`${calls.answerRate}%`} hint={`${calls.lvm + calls.discovery} of ${calls.calls} calls got a reply`} />
        <KpiCard label="Reach rate" value={`${calls.reachRate}%`} hint="Right person on the line (Discovery)" />
        <KpiCard label="Lead conversion" value={`${pct(f.sold, f.leads)}%`} hint={`${f.sold} of ${f.leads} leads sold`} />
        {preset === 'month'
          ? <KpiCard label="Sales this month" value={`${sales.length} / ${target}`} hint={`${pct(sales.length, target)}% of target`} />
          : <KpiCard label={`Sales ${periodName}`} value={String(sales.length)} hint="Monthly target is shown in 'This month'" />}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className={CARD_CLASS}>
          <h2 className="text-sm font-semibold text-slate-900 mb-4">Lead funnel</h2>
          <div className="space-y-3">
            {funnelSteps.map(([name, n], i) => (
              <div key={name}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-700">{name}</span>
                  <span className="text-slate-600">
                    {n}{i > 0 && funnelSteps[i - 1][1] > 0 && <span className="text-slate-500"> · {pct(n, funnelSteps[i - 1][1])}% of previous step</span>}
                  </span>
                </div>
                <HorizontalBar value={n} max={f.leads} color={i === funnelSteps.length - 1 ? 'bg-emerald-500' : 'bg-blue-500'} />
              </div>
            ))}
          </div>
        </div>

        <div className={CARD_CLASS}>
          <h2 className="text-sm font-semibold text-slate-900 mb-1">Best time to call</h2>
          <p className="text-xs text-slate-600 mb-4">
            {bestHour ? `Highest reach rate: around ${bestHour.hour}:00 (${bestHour.reachRate}% of ${bestHour.calls} calls).` : 'Needs at least 2 calls in the same hour.'}
          </p>
          <div className="space-y-2.5">
            {hours.map(h => (
              <div key={h.hour} className="flex items-center gap-3">
                <div className="w-12 text-xs text-slate-600">{String(h.hour).padStart(2, '0')}:00</div>
                <div className="flex-1"><HorizontalBar value={h.reachRate} max={100} color="bg-cyan-500" /></div>
                <div className="w-28 text-xs text-slate-600 text-right">{h.reachRate}% of {h.calls} calls</div>
              </div>
            ))}
            {hours.length === 0 && <div className="text-sm text-slate-500">No calls in this period.</div>}
          </div>
        </div>
      </div>

      <div className={CARD_CLASS}>
        <h2 className="text-sm font-semibold text-slate-900 mb-2">Campaigns</h2>
        <GroupPerformanceTable rows={campaignRows} first="Campaign" />
      </div>

      {!isAgent && (
        <div className={CARD_CLASS}>
          <h2 className="text-sm font-semibold text-slate-900 mb-2">Agents</h2>
          <GroupPerformanceTable rows={agentRows} first="Agent" />
        </div>
      )}

      <div className="grid lg:grid-cols-2 gap-6">
        <div className={CARD_CLASS}>
          <h2 className="text-sm font-semibold text-slate-900 mb-1">What agents report on calls</h2>
          <p className="text-xs text-slate-600 mb-4">Taken from the call reason, or read from the comment when no reason was chosen.</p>
          <div className="space-y-3">
            {reasons.map(r => (
              <div key={r.reason}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-700">{REASON_LABEL[r.reason]}</span>
                  <span className="text-slate-600">{r.count} · {r.share}%</span>
                </div>
                <HorizontalBar value={r.count} max={reasons[0]?.count ?? 1} color="bg-cyan-500" />
              </div>
            ))}
            {reasons.length === 0 && <div className="text-sm text-slate-500">No calls in this period.</div>}
          </div>
        </div>

        {!isAgent && (
          <div className={CARD_CLASS}>
            <h2 className="text-sm font-semibold text-slate-900 mb-4">Data quality</h2>
            <div className="space-y-2.5">
              {issues.map(i => (
                <div key={i.id} className={`flex gap-2.5 text-sm rounded-lg px-3 py-2.5 ${i.level === 'warn' ? 'bg-amber-50 text-amber-900' : 'bg-slate-50 text-slate-700'}`}>
                  {i.level === 'warn' ? <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" /> : <Info className="w-4 h-4 mt-0.5 shrink-0" />}
                  <span>{i.text}</span>
                </div>
              ))}
              {issues.length === 0 && <div className="text-sm text-slate-600">No problems found in the data.</div>}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

```

---

## `src/features/analytics/analyticsStyles.ts`

```ts
/** Shared card style of the Analytics screen. */
export const CARD_CLASS = 'bg-white rounded-xl border border-slate-200 shadow-sm p-5';

```

---

## `src/features/analytics/components/GroupPerformanceTable.tsx`

```tsx
import type { GroupRow } from '@/domain/analytics/performanceMetrics';

export function GroupPerformanceTable({ rows, first }: { rows: GroupRow[]; first: string }) {
  const th = 'px-3 py-2.5 text-left text-xs font-semibold text-slate-600 whitespace-nowrap';
  const td = 'px-3 py-2.5 text-sm text-slate-700 whitespace-nowrap';
  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead className="border-b border-slate-100">
          <tr>
            <th className={th}>{first}</th><th className={th}>Leads</th><th className={th}>Calls</th>
            <th className={th}>Answer rate</th><th className={th}>Reach rate</th><th className={th}>Reached leads</th>
            <th className={th}>Sold leads</th><th className={th}>Conversion</th><th className={th}>Reached → sale</th>
          </tr>
        </thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.key} className="border-b border-slate-100 last:border-0">
              <td className={`${td} font-medium text-slate-900`}>{r.label}</td>
              <td className={td}>{r.leads}</td><td className={td}>{r.calls}</td>
              <td className={td}>{r.answerRate}%</td><td className={td}>{r.reachRate}%</td><td className={td}>{r.reached}</td>
              <td className={td}>{r.sold}</td><td className={td}>{r.conversion}%</td><td className={td}>{r.reachToSale}%</td>
            </tr>
          ))}
          {rows.length === 0 && <tr><td className={td} colSpan={9}>No data for this selection.</td></tr>}
        </tbody>
      </table>
    </div>
  );
}

```

---

## `src/features/analytics/components/HorizontalBar.tsx`

```tsx
export function HorizontalBar({ value, max, color = 'bg-blue-500' }: { value: number; max: number; color?: string }) {
  return (
    <div className="h-1.5 rounded-full bg-slate-200 overflow-hidden">
      <div className={`h-full rounded-full ${color}`} style={{ width: `${max > 0 ? Math.max(2, (value / max) * 100) : 0}%` }} />
    </div>
  );
}

```

---

## `src/features/analytics/components/KpiCard.tsx`

```tsx
import { CARD_CLASS } from '@/features/analytics/analyticsStyles';

export function KpiCard({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className={CARD_CLASS}>
      <div className="text-2xl font-bold text-slate-900">{value}</div>
      <div className="text-sm text-slate-600 mt-0.5">{label}</div>
      {hint && <div className="text-xs text-slate-500 mt-1">{hint}</div>}
    </div>
  );
}

```

---

## `src/features/analytics/components/PeriodPicker.tsx`

```tsx
import type { DateRange, PeriodPreset } from '@/domain/analytics/dateRange';

const PRESETS: [PeriodPreset, string][] = [['today', 'Today'], ['week', 'This week'], ['month', 'This month'], ['custom', 'Custom']];

/** Today / This week / This month / Custom from-to. */
export function PeriodPicker({ preset, custom, onPreset, onCustom }: {
  preset: PeriodPreset; custom: DateRange; onPreset: (p: PeriodPreset) => void; onCustom: (r: DateRange) => void;
}) {
  const dateInput = 'px-3 py-2 rounded-lg border border-slate-200 text-sm bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500';
  return (
    <div className="flex flex-wrap items-center gap-2">
      <div className="inline-flex rounded-lg border border-slate-200 bg-white p-0.5" role="group" aria-label="Period">
        {PRESETS.map(([id, label]) => (
          <button
            key={id} onClick={() => onPreset(id)} aria-pressed={preset === id}
            className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${preset === id ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'}`}
          >
            {label}
          </button>
        ))}
      </div>
      {preset === 'custom' && (
        <div className="flex items-center gap-2 text-sm text-slate-600">
          <input type="date" value={custom.from} max={custom.to || undefined} onChange={e => onCustom({ ...custom, from: e.target.value })} className={dateInput} aria-label="From" />
          <span>to</span>
          <input type="date" value={custom.to} min={custom.from || undefined} onChange={e => onCustom({ ...custom, to: e.target.value })} className={dateInput} aria-label="To" />
        </div>
      )}
    </div>
  );
}

```

---

## `src/features/auth/LoginPage.tsx`

```tsx
import { roleLabel } from '@/domain/user/roleLabel';
import { Calendar, Check, Mail, Phone, TrendingUp } from 'lucide-react';
import { useState } from 'react';
import type { User } from '@/domain/types';
import { setCurrentUser, useStore } from '@/store';

export function LoginPage({ onLogin }: { onLogin: () => void }) {
  const { state, dispatch } = useStore();
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    if (selectedUser) {
      dispatch(setCurrentUser(selectedUser.id));
      onLogin();
    }
  };

  return (
    <div className="min-h-screen flex bg-slate-50">
      {/* Left brand panel */}
      <div className="hidden lg:flex lg:w-[46%] bg-slate-950 relative overflow-hidden">
        <div className="absolute -top-32 -left-24 w-[26rem] h-[26rem] bg-blue-600/30 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -right-20 w-[28rem] h-[28rem] bg-cyan-500/15 rounded-full blur-3xl" />
        <div className="relative z-10 flex flex-col justify-between p-12 xl:p-14 text-white w-full">
          <div>
            <div className="flex items-center gap-3 mb-14">
              <div className="w-11 h-11 bg-blue-500 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/30">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold tracking-tight">SalesFlow</span>
            </div>
            <h1 className="text-4xl xl:text-[2.6rem] font-extrabold leading-[1.15] tracking-tight mb-4">
              Unified Sales<br />Management Platform
            </h1>
            <p className="text-slate-300 text-base leading-relaxed max-w-md">
              Manage leads, workflows, touch points, meetings, and team communication — all in one place.
            </p>

            {/* The lead statuses people will see all day, shown in the same colours the app uses */}
            <div className="mt-10 flex flex-wrap gap-2 max-w-md">
              {[
                { label: 'New', dot: 'bg-slate-400' },
                { label: 'Discovery', dot: 'bg-emerald-400' },
                { label: 'LVM', dot: 'bg-amber-400' },
                { label: 'NVM', dot: 'bg-amber-400' },
                { label: 'No Response', dot: 'bg-rose-400' },
                { label: 'Meeting', dot: 'bg-violet-400' },
              ].map(s => (
                <span key={s.label} className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-sm text-slate-200">
                  <span className={`w-2 h-2 rounded-full ${s.dot}`} />
                  {s.label}
                </span>
              ))}
            </div>
          </div>
          <div className="space-y-3">
            {[
              { icon: Phone, text: 'Structured call workflows with touch points' },
              { icon: Mail, text: 'Automated email templates and bulk sending' },
              { icon: Calendar, text: 'Meeting scheduling with calendar integration' },
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3 text-slate-300">
                <div className="w-9 h-9 bg-white/5 rounded-lg flex items-center justify-center border border-white/10">
                  <item.icon className="w-4 h-4 text-blue-300" />
                </div>
                <span className="text-sm">{item.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right login panel */}
      <div className="flex-1 flex items-center justify-center px-6 py-10">
        <div className="w-full max-w-md">
          <div className="lg:hidden flex items-center gap-3 mb-8">
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <span className="text-lg font-bold tracking-tight text-slate-900">SalesFlow</span>
          </div>

          <h2 className="text-2xl font-bold tracking-tight text-slate-900 mb-1">Welcome back</h2>
          <p className="text-slate-600 text-sm mb-6">Select your profile to sign in</p>

          {/* User selection grid */}
          <div className="space-y-1.5 mb-5" role="radiogroup" aria-label="Profile">
            {state.users.map(user => {
              const selected = selectedUser?.id === user.id;
              return (
                <button
                  key={user.id}
                  onClick={() => setSelectedUser(user)}
                  role="radio"
                  aria-checked={selected}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl border transition-all text-left ${
                    selected
                      ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-500'
                      : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-sm'
                  }`}
                >
                  <div
                    className="w-9 h-9 rounded-full flex items-center justify-center text-white text-sm font-semibold shrink-0"
                    style={{ backgroundColor: user.color }}
                  >
                    {user.initials}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-slate-900 text-sm truncate">{user.name}</div>
                    <div className="text-xs text-slate-600 truncate">@{user.username}</div>
                  </div>
                  <span className={`text-xs font-medium px-2 py-0.5 rounded-full shrink-0 ${selected ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-600'}`}>
                    {roleLabel(user.role)}
                  </span>
                  <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${selected ? 'bg-blue-600' : 'border border-slate-300'}`}>
                    {selected && <Check className="w-3 h-3 text-white" strokeWidth={3} />}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Password field (visual only) */}
          <div className="mb-5">
            <label htmlFor="login-password" className="block text-sm font-medium text-slate-700 mb-1.5">Password</label>
            <input
              id="login-password"
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="Enter your password"
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-shadow"
            />
          </div>

          <button
            onClick={handleLogin}
            disabled={!selectedUser}
            className="w-full py-3 bg-blue-600 text-white text-sm font-semibold rounded-lg shadow-sm hover:bg-blue-700 disabled:bg-slate-300 disabled:text-slate-500 disabled:cursor-not-allowed transition-colors active:scale-[0.99]"
          >
            {selectedUser ? `Sign in as ${selectedUser.name.split(' ')[0]}` : 'Sign In'}
          </button>

          <p className="text-center text-xs text-slate-500 mt-6">
            This is a visual prototype — no real authentication
          </p>
        </div>
      </div>
    </div>
  );
}

```

---

## `src/features/calendar/CalendarPage.tsx`

```tsx
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Clock, Plus } from 'lucide-react';
import { useMemo, useState } from 'react';
import type { Meeting } from '@/domain/types';
import { CreateMeetingModal, type MeetingPrefill } from '@/features/calendar/components/CreateMeetingModal';
import { MeetingDetailModal } from '@/features/calendar/components/MeetingDetailModal';
import { MEETING_STATUS_STYLE } from '@/features/calendar/meetingStatusStyles';
import { useConfirm } from '@/shared/components/ConfirmDialog';
import { addNotification, createMeeting, updateMeeting, useStore } from '@/store';

export function CalendarPage() {
  const { state, dispatch } = useStore();
  const { ask, dialog: confirmDialog } = useConfirm();
  const currentUser = state.users.find(u => u.id === state.currentUserId)!;
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedMeeting, setSelectedMeeting] = useState<Meeting | null>(null);
  // set when the schedule form was opened FROM a meeting (reschedule / one more meeting with the same lead)
  const [prefill, setPrefill] = useState<MeetingPrefill | null>(null);

  const myMeetings = useMemo(() => {
    return state.meetings.filter(m => m.participantIds.includes(currentUser.id) || m.createdBy === currentUser.id);
  }, [state.meetings, currentUser]);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const daysInMonth = lastDay.getDate();
  const startWeekday = firstDay.getDay();
  const todayStr = new Date().toISOString().split('T')[0];

  const weeks: (Date | null)[][] = [];
  let week: (Date | null)[] = [];
  for (let i = 0; i < startWeekday; i++) week.push(null);
  for (let d = 1; d <= daysInMonth; d++) {
    week.push(new Date(year, month, d));
    if (week.length === 7) { weeks.push(week); week = []; }
  }
  if (week.length > 0) {
    while (week.length < 7) week.push(null);
    weeks.push(week);
  }

  const meetingsByDate = useMemo(() => {
    const map: Record<string, Meeting[]> = {};
    for (const m of myMeetings) {
      if (!map[m.date]) map[m.date] = [];
      map[m.date].push(m);
    }
    return map;
  }, [myMeetings]);

  const dayMeetings = selectedDate ? meetingsByDate[selectedDate] || [] : [];
  const todayMeetings = meetingsByDate[todayStr] || [];

  const monthName = currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  const weekdayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const formatDate = (d: Date) => d.toISOString().split('T')[0];
  const isToday = (d: Date) => formatDate(d) === todayStr;

  const getDisplayParticipants = (m: Meeting): string => {
    if (m.type === 'lead_meeting' && m.companyName) return m.participantNames.join(', ');
    const isCreator = currentUser.id === m.createdBy;
    if (isCreator) return m.participantNames.join(', ');
    return ['Manager', ...m.participantNames].join(', ');
  };

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto">
      {todayMeetings.length > 0 && (
        <div className="bg-gradient-to-r from-violet-600 to-violet-700 rounded-xl p-4 mb-6 text-white">
          <div className="flex items-center gap-2 mb-3">
            <CalendarIcon className="w-4 h-4" />
            <span className="font-semibold text-sm">Today's Meetings ({todayMeetings.length})</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {todayMeetings.map(m => (
              <button
                key={m.id}
                onClick={() => setSelectedMeeting(m)}
                className="bg-white/10 backdrop-blur rounded-lg p-3 text-left hover:bg-white/20 transition-all border border-white/10"
              >
                <div className="flex items-center gap-2 mb-1">
                  <Clock className="w-3.5 h-3.5 text-violet-200" />
                  <span className="text-sm font-medium">{m.time}</span>
                  <span className="text-xs text-violet-200">({m.duration}min)</span>
                </div>
                <div className="text-sm font-semibold truncate">{m.title}</div>
                <div className="text-xs text-violet-200 truncate">
                  {m.type === 'lead_meeting' && m.companyName ? m.companyName : getDisplayParticipants(m)}
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="flex gap-6">
        <div className="flex-1">
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
              <h2 className="text-lg font-bold text-slate-900">{monthName}</h2>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setCurrentDate(new Date(year, month - 1, 1))}
                  className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center transition-colors"
                >
                  <ChevronLeft className="w-4 h-4 text-slate-600" />
                </button>
                <button
                  onClick={() => setCurrentDate(new Date())}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-600 hover:bg-slate-100 transition-colors"
                >
                  Today
                </button>
                <button
                  onClick={() => setCurrentDate(new Date(year, month + 1, 1))}
                  className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center transition-colors"
                >
                  <ChevronRight className="w-4 h-4 text-slate-600" />
                </button>
                <button
                  onClick={() => setShowCreateModal(true)}
                  className="ml-2 px-3 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-medium hover:bg-blue-700 transition-all flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  New Meeting
                </button>
              </div>
            </div>

            <div className="grid grid-cols-7 border-b border-slate-100">
              {weekdayNames.map(d => (
                <div key={d} className="px-2 py-2.5 text-center text-xs font-semibold text-slate-600">
                  {d}
                </div>
              ))}
            </div>

            <div className="grid grid-cols-7">
              {weeks.flat().map((date, i) => {
                if (!date) return <div key={i} className="min-h-[100px] border-r border-b border-slate-100 bg-slate-50/30" />;
                const dateStr = formatDate(date);
                const meetings = meetingsByDate[dateStr] || [];
                const selected = selectedDate === dateStr;
                return (
                  <button
                    key={i}
                    onClick={() => setSelectedDate(dateStr)}
                    className={`min-h-[100px] border-r border-b border-slate-100 p-1.5 text-left align-top transition-colors ${
                      selected ? 'bg-violet-50' : 'hover:bg-slate-50'
                    } ${isToday(date) ? 'ring-2 ring-violet-300 ring-inset' : ''}`}
                  >
                    <div className={`text-xs font-medium mb-1 ${
                      isToday(date) ? 'text-violet-700 font-bold' : 'text-slate-700'
                    }`}>
                      {date.getDate()}
                    </div>
                    <div className="space-y-0.5">
                      {meetings.slice(0, 3).map(m => (
                        <div
                          key={m.id}
                          className={`text-xs px-1.5 py-0.5 rounded truncate ${MEETING_STATUS_STYLE[m.status].bg} ${MEETING_STATUS_STYLE[m.status].color}`}
                        >
                          {m.time} {m.type === 'lead_meeting' ? m.companyName : m.title}
                        </div>
                      ))}
                      {meetings.length > 3 && (
                        <div className="text-xs text-slate-500 px-1.5">+{meetings.length - 3} more</div>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="w-80 shrink-0">
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 sticky top-0">
            <h3 className="font-semibold text-sm text-slate-900 mb-3">
              {selectedDate
                ? new Date(selectedDate).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })
                : 'Select a date'}
            </h3>
            {dayMeetings.length === 0 ? (
              <div className="text-center py-8 text-slate-500">
                <CalendarIcon className="w-8 h-8 mx-auto mb-2 opacity-30" />
                <p className="text-xs">No meetings on this day</p>
              </div>
            ) : (
              <div className="space-y-2">
                {dayMeetings.map(m => (
                  <button
                    key={m.id}
                    onClick={() => setSelectedMeeting(m)}
                    className="w-full text-left p-3 rounded-lg border border-slate-100 hover:border-slate-300 transition-all"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-slate-900">{m.time}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${MEETING_STATUS_STYLE[m.status].bg} ${MEETING_STATUS_STYLE[m.status].color}`}>
                        {MEETING_STATUS_STYLE[m.status].label}
                      </span>
                    </div>
                    <div className="text-sm text-slate-700">{m.title}</div>
                    <div className="text-xs text-slate-600">
                      {m.type === 'lead_meeting' && m.companyName ? `${m.companyName} • ` : ''}
                      {getDisplayParticipants(m)} • {m.duration}min
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {showCreateModal && (
        <CreateMeetingModal
          state={state}
          currentUser={currentUser}
          prefill={prefill ?? undefined}
          onClose={() => { setShowCreateModal(false); setPrefill(null); }}
          onCreate={(meeting) => {
            dispatch(createMeeting(meeting));
            // rescheduling: the old meeting is closed only now, once the new time is really saved (the lead stays in Meeting)
            if (prefill?.purpose === 'reschedule') dispatch(updateMeeting({ meetingId: prefill.source.id, updates: { status: 'rescheduled' } }));
            dispatch(addNotification({
              id: crypto.randomUUID(),
              type: 'meeting',
              title: 'Meeting scheduled',
              message: `${meeting.title} on ${meeting.date} at ${meeting.time}`,
              timestamp: new Date().toISOString(),
              read: false,
            }));
            setShowCreateModal(false);
            setPrefill(null);
          }}
        />
      )}

      {confirmDialog}

      {selectedMeeting && (
        <MeetingDetailModal
          meeting={selectedMeeting}
          currentUser={currentUser}
          onClose={() => setSelectedMeeting(null)}
          onReschedule={() => { setPrefill({ source: selectedMeeting, purpose: 'reschedule' }); setSelectedMeeting(null); setShowCreateModal(true); }}
          onScheduleAnother={() => { setPrefill({ source: selectedMeeting, purpose: 'follow_up' }); setSelectedMeeting(null); setShowCreateModal(true); }}
          onUpdate={(updates) => {
            const apply = () => { dispatch(updateMeeting({ meetingId: selectedMeeting.id, updates })); setSelectedMeeting(null); };
            if (updates.status === 'cancelled') {
              ask({ title: 'Cancel this meeting?', message: <><b>{selectedMeeting.title}</b> will be marked as cancelled.</>, confirmLabel: 'Cancel meeting', tone: 'danger' }, apply);
            } else apply();
          }}
        />
      )}
    </div>
  );
}

```

---

## `src/features/calendar/components/CreateMeetingModal.tsx`

```tsx
import { Users as UsersIcon, X } from 'lucide-react';
import { useMemo, useState } from 'react';
import type { Meeting, User } from '@/domain/types';
import { LeadPicker } from '@/shared/components/LeadPicker';
import type { AppState } from '@/store/state/AppState';

/** Starting point of the form: copy the lead / people / title / length / agenda of an existing meeting. */
export interface MeetingPrefill {
  source: Meeting;
  purpose: 'reschedule' | 'follow_up';
}

export function CreateMeetingModal({
  state, currentUser, onClose, onCreate, prefill,
}: {
  state: AppState;
  currentUser: User;
  onClose: () => void;
  onCreate: (meeting: Meeting) => void;
  prefill?: MeetingPrefill;
}) {
  const isAgent = currentUser.role === 'agent';
  const isTL = currentUser.role === 'team_leader';
  const isOM = currentUser.role === 'operation_manager';

  const from = prefill?.source;
  const [leadId, setLeadId] = useState(from?.leadId ?? '');
  const [participantIds, setParticipantIds] = useState<string[]>(isAgent ? [] : from?.participantIds ?? []);
  const [title, setTitle] = useState(from?.title ?? '');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [time, setTime] = useState('10:00');
  const [duration, setDuration] = useState(from?.duration ?? 30);
  const [notes, setNotes] = useState(from?.notes ?? '');

  const myTeam = state.teams.find(t => t.id === currentUser.teamId);

  const availableLeads = useMemo(() => {
    if (isAgent) return state.leads.filter(l => l.agentId === currentUser.id && !l.removedFromQueue && !l.stopped && !l.expiredAt);
    if (isTL) return state.leads.filter(l => myTeam?.agentIds.includes(l.agentId) && !l.removedFromQueue && !l.stopped && !l.expiredAt);
    return [];
  }, [state.leads, currentUser, isAgent, isTL, myTeam]);

  const availableParticipants = useMemo(() => {
    if (isAgent) return [];
    if (isTL) return state.users.filter(u => myTeam?.agentIds.includes(u.id));
    if (isOM) {
      const myLeaderIds = state.teams.filter(t => t.managerId === currentUser.id).map(t => t.leaderId);
      return state.users.filter(u => u.role === 'team_leader' && myLeaderIds.includes(u.id));
    }
    return [];
  }, [state.users, currentUser, isTL, isOM, myTeam]);

  const selectedLead = state.leads.find(l => l.id === leadId);

  const handleCreate = () => {
    if (isAgent && selectedLead) {
      onCreate({
        id: crypto.randomUUID(),
        type: 'lead_meeting',
        leadId: selectedLead.id,
        leadName: selectedLead.contactName,
        companyName: selectedLead.companyName,
        agentId: currentUser.id,
        participantIds: [currentUser.id],
        participantNames: [currentUser.name],
        title: `Meeting with ${selectedLead.companyName}`,
        date, time, duration, notes,
        status: 'arranged',
        priority: 'high',
        createdBy: currentUser.id,
      });
    } else if ((isTL || isOM) && participantIds.length > 0) {
      const participants = state.users.filter(u => participantIds.includes(u.id));
      const firstLead = selectedLead;
      onCreate({
        id: crypto.randomUUID(),
        type: firstLead ? 'lead_meeting' : 'internal_meeting',
        ...(firstLead ? {
          leadId: firstLead.id,
          leadName: firstLead.contactName,
          companyName: firstLead.companyName,
        } : {}),
        participantIds,
        participantNames: participants.map(p => p.name),
        title: title || (firstLead ? `Meeting with ${firstLead.companyName}` : `Meeting with ${participants.map(p => p.name).join(', ')}`),
        date, time, duration, notes,
        status: 'arranged',
        priority: 'high',
        createdBy: currentUser.id,
      });
    }
  };

  const allSelected = availableParticipants.length > 0 && availableParticipants.every(p => participantIds.includes(p.id));
  const toggleAll = () => setParticipantIds(allSelected ? [] : availableParticipants.map(p => p.id));

  const canCreate = isAgent ? !!leadId : participantIds.length > 0;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 animate-slide-up max-h-[90vh] overflow-y-auto scrollbar-thin">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between sticky top-0 bg-white z-10">
          <h2 className="text-lg font-bold text-slate-900">{prefill?.purpose === 'reschedule' ? 'Reschedule Meeting' : prefill ? 'Schedule Another Meeting' : 'Schedule Meeting'}</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center">
            <X className="w-4 h-4 text-slate-600" />
          </button>
        </div>

        <div className="px-6 py-5 space-y-4">
          {isAgent && (
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Lead</label>
              <LeadPicker leads={availableLeads} value={leadId} onChange={setLeadId} placeholder="Search a lead, then select it..." />
            </div>
          )}

          {(isTL || isOM) && (
            <>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Title (optional)</label>
                <input
                  type="text"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="Meeting title..."
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              {isTL && availableLeads.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Link to Lead (optional)</label>
                  <LeadPicker leads={availableLeads} value={leadId} onChange={setLeadId} placeholder="Search a lead, then select it..." />
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-medium text-slate-700">
                    <UsersIcon className="w-3.5 h-3.5 inline mr-1" />
                    {isOM ? 'Select Team Leaders' : 'Select Agents'}
                    <span className="text-xs text-slate-500 font-normal ml-1">({participantIds.length}/{availableParticipants.length})</span>
                  </label>
                  {availableParticipants.length > 0 && (
                    <button
                      type="button"
                      onClick={toggleAll}
                      className="text-xs font-medium text-blue-600 hover:text-blue-700"
                    >
                      {allSelected ? 'Clear all' : isOM ? 'Select all team leaders' : 'Select all agents'}
                    </button>
                  )}
                </div>
                <div className="space-y-1.5 max-h-40 overflow-y-auto scrollbar-thin border border-slate-200 rounded-xl p-2">
                  {availableParticipants.map(p => (
                    <label key={p.id} className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-slate-50 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={participantIds.includes(p.id)}
                        onChange={e => {
                          if (e.target.checked) setParticipantIds([...participantIds, p.id]);
                          else setParticipantIds(participantIds.filter(id => id !== p.id));
                        }}
                        className="rounded"
                      />
                      <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-semibold shrink-0" style={{ backgroundColor: p.color }}>
                        {p.initials}
                      </div>
                      <span className="text-sm text-slate-700">{p.name}</span>
                    </label>
                  ))}
                </div>
              </div>
            </>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Date</label>
              <input
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Time</label>
              <input
                type="time"
                value={time}
                onChange={e => setTime(e.target.value)}
                className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Duration (minutes)</label>
            <div className="flex gap-2">
              {[15, 30, 45, 60].map(d => (
                <button
                  key={d}
                  onClick={() => setDuration(d)}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                    duration === d ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {d}min
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Notes</label>
            <textarea
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="Meeting agenda or notes..."
              rows={3}
              className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 resize-none"
            />
          </div>
        </div>

        <div className="px-6 py-4 border-t border-slate-100 flex justify-end gap-2 sticky bottom-0 bg-white">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100">Cancel</button>
          <button
            onClick={handleCreate}
            disabled={!canCreate}
            className="px-4 py-2 rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-40 transition-all"
          >
            Schedule Meeting
          </button>
        </div>
      </div>
    </div>
  );
}

```

---

## `src/features/calendar/components/MeetingDetailModal.tsx`

```tsx
import { useState } from 'react';
import { Ban, CalendarPlus, CheckCircle2, RefreshCw, X, XCircle } from 'lucide-react';
import type { Meeting, MeetingStatus, User } from '@/domain/types';
import { MEETING_STATUS_STYLE } from '@/features/calendar/meetingStatusStyles';

export function MeetingDetailModal({
  meeting, currentUser, onClose, onUpdate, onReschedule, onScheduleAnother,
}: {
  meeting: Meeting;
  currentUser: User;
  onClose: () => void;
  onUpdate: (updates: Partial<Meeting>) => void;
  onReschedule: () => void;          // opens the schedule form with this meeting's data, to pick another time
  onScheduleAnother: () => void;     // opens the schedule form with this meeting's data, for one more meeting
}) {
  const isLeadMeeting = meeting.type === 'lead_meeting' && !!meeting.leadId;
  const [writingOutcome, setWritingOutcome] = useState(false);
  const [outcome, setOutcome] = useState(meeting.outcome ?? '');

  const config = MEETING_STATUS_STYLE[meeting.status];
  // Only the person who created the meeting can update its status; everyone else just views it.
  const canUpdate = meeting.createdBy === currentUser.id;

  const getDisplayParticipants = (m: Meeting): string => {
    if (m.type === 'lead_meeting' && m.companyName) return m.participantNames.join(', ');
    const isCreator = currentUser.id === m.createdBy;
    if (isCreator) return m.participantNames.join(', ');
    return ['Manager', ...m.participantNames].join(', ');
  };
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 animate-slide-up">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">{meeting.title}</h2>
            <p className="text-sm text-slate-600">
              {meeting.type === 'lead_meeting' && meeting.companyName ? `${meeting.companyName} • ` : ''}
              {getDisplayParticipants(meeting)}
            </p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center">
            <X className="w-4 h-4 text-slate-600" />
          </button>
        </div>

        <div className="px-6 py-5 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-xs text-slate-500 mb-1">Date</div>
              <div className="text-sm text-slate-900">{new Date(meeting.date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}</div>
            </div>
            <div>
              <div className="text-xs text-slate-500 mb-1">Time</div>
              <div className="text-sm text-slate-900">{meeting.time} ({meeting.duration}min)</div>
            </div>
          </div>

          {meeting.notes && (
            <div>
              <div className="text-xs text-slate-500 mb-1">Notes</div>
              <div className="text-sm text-slate-700 p-3 bg-slate-50 rounded-lg">{meeting.notes}</div>
            </div>
          )}

          {meeting.outcome && (
            <div>
              <div className="text-xs text-slate-500 mb-1">Meeting outcome</div>
              <div className="text-sm text-slate-700 p-3 bg-emerald-50 border border-emerald-100 rounded-lg whitespace-pre-wrap">{meeting.outcome}</div>
            </div>
          )}

          <div>
            <div className="text-xs text-slate-500 mb-1">Participants</div>
            <div className="text-sm text-slate-700">{getDisplayParticipants(meeting)}</div>
          </div>

          <div>
            <div className="text-xs text-slate-500 mb-2">Status</div>
            <span className={`text-sm px-3 py-1 rounded-full ${config.bg} ${config.color} font-medium`}>{config.label}</span>
          </div>

          {!canUpdate && (
            <div className="border-t border-slate-100 pt-4 text-xs text-slate-600">
              Only the person who created this meeting can update its status.
            </div>
          )}

          {canUpdate && writingOutcome && (
            <div className="border-t border-slate-100 pt-4 space-y-3">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">What happened in the meeting?</label>
                <textarea
                  value={outcome}
                  onChange={e => setOutcome(e.target.value)}
                  placeholder="Describe the meeting: what was discussed, what the lead decided, next steps..."
                  rows={4}
                  autoFocus
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 resize-none"
                />
                <p className="text-xs text-slate-500 mt-1">Required — it is saved on the meeting and in the lead's history.</p>
              </div>
              <div className="flex flex-wrap justify-end gap-2">
                <button onClick={() => setWritingOutcome(false)} className="px-3 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100">Back</button>
                <button
                  onClick={() => { onUpdate({ status: 'completed', outcome: outcome.trim() }); onScheduleAnother(); }}
                  disabled={!outcome.trim()}
                  className="px-3 py-2 rounded-lg text-sm font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 disabled:opacity-40"
                >
                  Save & schedule next meeting
                </button>
                <button
                  onClick={() => onUpdate({ status: 'completed', outcome: outcome.trim() })}
                  disabled={!outcome.trim()}
                  className="px-3 py-2 rounded-lg text-sm font-medium text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40"
                >
                  Save outcome
                </button>
              </div>
            </div>
          )}

          {canUpdate && !writingOutcome && (
          <div className="border-t border-slate-100 pt-4">
            <div className="text-xs text-slate-500 mb-2">Update Status</div>
            <div className="grid grid-cols-2 gap-2">
              {([
                { status: 'completed' as MeetingStatus, label: 'Completed', icon: CheckCircle2, color: 'bg-emerald-600' },
                { status: 'no_show' as MeetingStatus, label: 'No Show', icon: XCircle, color: 'bg-rose-600' },
                { status: 'cancelled' as MeetingStatus, label: 'Cancel', icon: Ban, color: 'bg-slate-600' },
                { status: 'rescheduled' as MeetingStatus, label: 'Reschedule', icon: RefreshCw, color: 'bg-amber-600' },
              ]).map(btn => (
                <button
                  key={btn.status}
                  onClick={() => {
                    if (btn.status === 'completed' && isLeadMeeting) setWritingOutcome(true);   // a lead meeting needs its description first
                    else if (btn.status === 'rescheduled') onReschedule();                       // pick the new time before anything changes
                    else onUpdate({ status: btn.status });
                  }}
                  className={`flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium text-white ${btn.color} hover:opacity-90 transition-all`}
                >
                  <btn.icon className="w-3.5 h-3.5" />
                  {btn.label}
                </button>
              ))}
            </div>
            {isLeadMeeting && (
              <button
                onClick={onScheduleAnother}
                className="mt-2 w-full flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 transition-all"
              >
                <CalendarPlus className="w-3.5 h-3.5" />
                Schedule another meeting with this lead
              </button>
            )}
          </div>
          )}
        </div>
      </div>
    </div>
  );
}

```

---

## `src/features/calendar/meetingStatusStyles.ts`

```ts
/** Label + colours of each meeting status. */
import { Ban, CheckCircle2, RefreshCw, XCircle } from 'lucide-react';
import type { MeetingStatus } from '@/domain/types';

export const MEETING_STATUS_STYLE: Record<MeetingStatus, { label: string; color: string; bg: string; icon?: typeof CheckCircle2 }> = {
  arranged: { label: 'Arranged', color: 'text-violet-700', bg: 'bg-violet-100' },
  completed: { label: 'Completed', color: 'text-emerald-700', bg: 'bg-emerald-100', icon: CheckCircle2 },
  no_show: { label: 'No Show', color: 'text-rose-700', bg: 'bg-rose-100', icon: XCircle },
  cancelled: { label: 'Cancelled', color: 'text-slate-600', bg: 'bg-slate-100', icon: Ban },
  rescheduled: { label: 'Rescheduled', color: 'text-amber-700', bg: 'bg-amber-100', icon: RefreshCw },
};

```

---

## `src/features/dashboard/AgentDashboard.tsx`

```tsx
import { Calendar, Mail, Target, Trophy } from 'lucide-react';
import type { Lead, User } from '@/domain/types';
import { CallBreakdown } from '@/features/dashboard/components/CallBreakdown';
import { StatCard } from '@/features/dashboard/components/StatCard';
import { TodayMeetingsCard } from '@/features/dashboard/components/TodayMeetingsCard';
import { countCallsMadeToday, isTodayDate } from '@/features/dashboard/dashboardCallStats';
import type { AppState } from '@/store/state/AppState';

export function AgentDashboard({ currentUser, leads, meetings, emails, users, salesThisMonth }: {
  currentUser: User; leads: Lead[]; meetings: AppState['meetings']; emails: AppState['emailLogs'];
  users: User[]; salesThisMonth: number;
}) {
  const myLeads = leads.filter(l => l.agentId === currentUser.id && !l.removedFromQueue && !l.expiredAt);
  const allMyCallLogs = myLeads.flatMap(l => l.callLogs);
  const todayCalls = countCallsMadeToday(allMyCallLogs);
  const myEmails = emails.filter(e => e.sentBy === currentUser.id);
  const todayEmails = myEmails.filter(e => isTodayDate(e.sentAt));
  const myMeetings = meetings.filter(m => m.participantIds.includes(currentUser.id) && m.status === 'arranged');
  const todayMeetings = myMeetings.filter(m => isTodayDate(m.date));
  const target = currentUser.dailyCallTarget;
  const progressPct = target > 0 ? Math.min((todayCalls.total / target) * 100, 100) : 0;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-bold text-slate-900 mb-1">My Dashboard</h2>
        <p className="text-sm text-slate-600">
          {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
        </p>
      </div>

      <TodayMeetingsCard meetings={todayMeetings} users={users} />

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Target className="w-4 h-4 text-blue-600" />
            <span className="text-sm font-semibold text-slate-900">Today's Call Progress</span>
          </div>
          <span className="text-sm font-bold text-slate-900">{todayCalls.total} / {target}</span>
        </div>
        <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all ${progressPct >= 100 ? 'bg-emerald-500' : 'bg-blue-600'}`}
            style={{ width: `${Math.max(progressPct, 2)}%` }}
          />
        </div>
        <p className="text-xs text-slate-500 mt-2">{Math.round(progressPct)}% of daily target</p>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-slate-900 mb-3">Today's Call Breakdown</h3>
        <CallBreakdown callLogs={allMyCallLogs} todayOnly />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard label="Emails Sent Today" value={todayEmails.length} icon={Mail} color="text-violet-600 bg-violet-50" />
        <StatCard label="Meetings Today" value={todayMeetings.length} icon={Calendar} color="text-violet-600 bg-violet-50" />
        <StatCard label="Sales This Month" value={salesThisMonth} icon={Trophy} color="text-amber-600 bg-amber-50" />
      </div>

    </div>
  );
}

```

---

## `src/features/dashboard/DashboardPage.tsx`

```tsx
import { AgentDashboard } from '@/features/dashboard/AgentDashboard';
import { OperationManagerDashboard } from '@/features/dashboard/OperationManagerDashboard';
import { TeamLeaderDashboard } from '@/features/dashboard/TeamLeaderDashboard';
import { currentMonthKey } from '@/shared/lib/dates';
import { useStore } from '@/store';

export function DashboardPage() {
  const { state, dispatch } = useStore();
  const currentUser = state.users.find(u => u.id === state.currentUserId)!;

  if (currentUser.role === 'agent') {
    return (
      <div className="p-4 sm:p-6 max-w-6xl mx-auto">
        <AgentDashboard
          currentUser={currentUser} leads={state.leads} meetings={state.meetings} emails={state.emailLogs}
          users={state.users}
          salesThisMonth={state.sales.filter(x => x.agentId === currentUser.id && x.date.startsWith(currentMonthKey())).length}
        />
      </div>
    );
  }

  if (currentUser.role === 'team_leader') {
    return (
      <div className="p-4 sm:p-6 max-w-6xl mx-auto">
        <TeamLeaderDashboard currentUser={currentUser} state={state} dispatch={dispatch} />
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto">
      <OperationManagerDashboard state={state} />
    </div>
  );
}

```

---

## `src/features/dashboard/OperationManagerDashboard.tsx`

```tsx
import { TodayMeetingsCard } from '@/features/dashboard/components/TodayMeetingsCard';
import { countCallsMadeToday, isTodayDate } from '@/features/dashboard/dashboardCallStats';
import type { AppState } from '@/store/state/AppState';

export function OperationManagerDashboard({ state }: { state: AppState }) {
  const teamLeaders = state.users.filter(u => u.role === 'team_leader');
  const todayMeetings = state.meetings.filter(m => m.status === 'arranged' && isTodayDate(m.date));

  const tlStats = teamLeaders.map(tl => {
    const team = state.teams.find(t => t.id === tl.teamId);
    const agents = state.users.filter(u => team?.agentIds.includes(u.id));
    const teamLeads = state.leads.filter(l => team?.agentIds.includes(l.agentId) && !l.removedFromQueue && !l.expiredAt);
    const allCalls = teamLeads.flatMap(l => l.callLogs);
    const todayCalls = countCallsMadeToday(allCalls);
    const teamTarget = agents.reduce((sum, a) => sum + a.dailyCallTarget, 0);
    const teamEmails = state.emailLogs.filter(e => e.sentBy && team?.agentIds.includes(e.sentBy) && isTodayDate(e.sentAt));
    const teamMeetings = state.meetings.filter(m => m.type === 'lead_meeting' && m.status === 'arranged' && isTodayDate(m.date) && team?.agentIds.includes(m.agentId || ''));
    return { tl, team, agents, todayCalls, teamTarget, teamEmails, teamMeetings };
  });

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-bold text-slate-900 mb-1">Operations Overview</h2>
        <p className="text-sm text-slate-600">
          {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
        </p>
      </div>

      <TodayMeetingsCard meetings={todayMeetings} users={state.users} title="Meetings Today" />

      <div>
        <h3 className="text-sm font-semibold text-slate-900 mb-3">Team Leader Performance — Today</h3>
        <div className="space-y-3">
          {tlStats.map(({ tl, team, agents, todayCalls, teamTarget, teamEmails, teamMeetings }) => {
            const pct = teamTarget > 0 ? Math.min((todayCalls.total / teamTarget) * 100, 100) : 0;
            return (
              <div key={tl.id} className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-semibold shrink-0" style={{ backgroundColor: tl.color }}>
                    {tl.initials}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-slate-900">{tl.name}</div>
                    <div className="text-xs text-slate-600">@{tl.username} • {team?.name} • {agents.length} agents</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 mb-3">
                  <div className="flex-1 h-2.5 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${pct >= 100 ? 'bg-emerald-500' : 'bg-blue-600'}`}
                      style={{ width: `${Math.max(pct, 2)}%` }}
                    />
                  </div>
                  <span className="text-xs font-semibold text-slate-700 shrink-0">{todayCalls.total}/{teamTarget} ({Math.round(pct)}%)</span>
                </div>
                <div className="grid grid-cols-6 gap-2 text-center">
                  <div className="bg-blue-50 rounded-lg py-1.5">
                    <div className="text-sm font-bold text-blue-700">{todayCalls.total}</div>
                    <div className="text-[11px] text-slate-600">Calls</div>
                  </div>
                  <div className="bg-emerald-50 rounded-lg py-1.5">
                    <div className="text-sm font-bold text-emerald-700">{todayCalls.discovery}</div>
                    <div className="text-[11px] text-slate-600">Disc.</div>
                  </div>
                  <div className="bg-amber-50 rounded-lg py-1.5">
                    <div className="text-sm font-bold text-amber-700">{todayCalls.lvm}</div>
                    <div className="text-[11px] text-slate-600">LVM</div>
                  </div>
                  <div className="bg-amber-50 rounded-lg py-1.5">
                    <div className="text-sm font-bold text-amber-700">{todayCalls.nvm}</div>
                    <div className="text-[11px] text-slate-600">NVM</div>
                  </div>
                  <div className="bg-violet-50 rounded-lg py-1.5">
                    <div className="text-sm font-bold text-violet-700">{teamEmails.length}</div>
                    <div className="text-[11px] text-slate-600">Emails</div>
                  </div>
                  <div className="bg-violet-50 rounded-lg py-1.5">
                    <div className="text-sm font-bold text-violet-700">{teamMeetings.length}</div>
                    <div className="text-[11px] text-slate-600">Meet.</div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

```

---

## `src/features/dashboard/TeamLeaderDashboard.tsx`

```tsx
import type { User } from '@/domain/types';
import { ReassignRow } from '@/features/dashboard/components/ReassignRow';
import { TodayMeetingsCard } from '@/features/dashboard/components/TodayMeetingsCard';
import { countCallsMadeToday, isTodayDate } from '@/features/dashboard/dashboardCallStats';
import { useConfirm } from '@/shared/components/ConfirmDialog';
import { transferLeadToAgent, useStore } from '@/store';
import type { AppState } from '@/store/state/AppState';

export function TeamLeaderDashboard({ currentUser, state, dispatch }: {
  currentUser: User; state: AppState; dispatch: ReturnType<typeof useStore>['dispatch'];
}) {
  const { ask, dialog: confirmDialog } = useConfirm();
  const myTeam = state.teams.find(t => t.id === currentUser.teamId);
  const teamAgents = state.users.filter(u => myTeam?.agentIds.includes(u.id));
  const teamLeads = state.leads.filter(l => myTeam?.agentIds.includes(l.agentId) && !l.removedFromQueue && !l.expiredAt);
  const expiredLeads = state.leads.filter(l => myTeam?.agentIds.includes(l.agentId) && !l.removedFromQueue && !!l.expiredAt);
  const todayMeetings = state.meetings.filter(m =>
    m.status === 'arranged' && isTodayDate(m.date) && (
      (m.type === 'lead_meeting' && myTeam?.agentIds.includes(m.agentId || '')) ||
      m.participantIds.includes(currentUser.id) || m.createdBy === currentUser.id
    )
  );

  const agentStats = teamAgents.map(agent => {
    const agentLeads = teamLeads.filter(l => l.agentId === agent.id);
    const allCalls = agentLeads.flatMap(l => l.callLogs);
    const todayCalls = countCallsMadeToday(allCalls);
    const agentEmails = state.emailLogs.filter(e => e.sentBy === agent.id && isTodayDate(e.sentAt));
    const agentMeetings = state.meetings.filter(m =>
      m.type === 'lead_meeting' && m.participantIds.includes(agent.id) && m.status === 'arranged' && isTodayDate(m.date)
    );
    return { agent, todayCalls, agentEmails, agentMeetings };
  });

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-bold text-slate-900 mb-1">{myTeam?.name} Dashboard</h2>
        <p className="text-sm text-slate-600">
          {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
        </p>
      </div>

      {confirmDialog}

      <TodayMeetingsCard meetings={todayMeetings} users={state.users} title="Team Meetings Today" />

      {expiredLeads.length > 0 && (
        <div className="bg-rose-50/50 rounded-xl border border-rose-100 p-5">
          <h3 className="text-sm font-semibold text-rose-900 mb-1">Needs reassignment ({expiredLeads.length})</h3>
          <p className="text-xs text-slate-600 mb-3">No progress for 15 days. The new agent starts from touch point 1; the old history is kept.</p>
          <div className="space-y-2">
            {expiredLeads.map(l => (
              <ReassignRow
                key={l.id} lead={l} agents={teamAgents}
                ownerName={state.users.find(u => u.id === l.agentId)?.name ?? '—'}
                onReassign={agentId => ask(
                  { title: 'Reassign this lead?', message: <><b>{l.companyName}</b> will move to <b>{state.users.find(u => u.id === agentId)?.name ?? 'the selected agent'}</b> and start again from touch point 1. The old history is kept.</>, confirmLabel: 'Reassign' },
                  () => dispatch(transferLeadToAgent({ leadId: l.id, newAgentId: agentId })),
                )}
              />
            ))}
          </div>
        </div>
      )}

      <div>
        <h3 className="text-sm font-semibold text-slate-900 mb-3">Agent Performance — Today</h3>
        <div className="space-y-3">
          {agentStats.map(({ agent, todayCalls, agentEmails, agentMeetings }) => {
            const target = agent.dailyCallTarget;
            const pct = target > 0 ? Math.min((todayCalls.total / target) * 100, 100) : 0;
            return (
              <div key={agent.id} className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-semibold shrink-0" style={{ backgroundColor: agent.color }}>
                    {agent.initials}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-slate-900">{agent.name}</div>
                    <div className="text-xs text-slate-600">@{agent.username}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 mb-3">
                  <div className="flex-1 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${pct >= 100 ? 'bg-emerald-500' : 'bg-blue-600'}`}
                      style={{ width: `${Math.max(pct, 2)}%` }}
                    />
                  </div>
                  <span className="text-xs font-semibold text-slate-700 shrink-0">{todayCalls.total}/{target}</span>
                </div>
                <div className="grid grid-cols-6 gap-2 text-center">
                  <div className="bg-blue-50 rounded-lg py-1.5">
                    <div className="text-sm font-bold text-blue-700">{todayCalls.total}</div>
                    <div className="text-[11px] text-slate-600">Calls</div>
                  </div>
                  <div className="bg-emerald-50 rounded-lg py-1.5">
                    <div className="text-sm font-bold text-emerald-700">{todayCalls.discovery}</div>
                    <div className="text-[11px] text-slate-600">Disc.</div>
                  </div>
                  <div className="bg-amber-50 rounded-lg py-1.5">
                    <div className="text-sm font-bold text-amber-700">{todayCalls.lvm}</div>
                    <div className="text-[11px] text-slate-600">LVM</div>
                  </div>
                  <div className="bg-amber-50 rounded-lg py-1.5">
                    <div className="text-sm font-bold text-amber-700">{todayCalls.nvm}</div>
                    <div className="text-[11px] text-slate-600">NVM</div>
                  </div>
                  <div className="bg-violet-50 rounded-lg py-1.5">
                    <div className="text-sm font-bold text-violet-700">{agentEmails.length}</div>
                    <div className="text-[11px] text-slate-600">Emails</div>
                  </div>
                  <div className="bg-violet-50 rounded-lg py-1.5">
                    <div className="text-sm font-bold text-violet-700">{agentMeetings.length}</div>
                    <div className="text-[11px] text-slate-600">Meet.</div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

```

---

## `src/features/dashboard/components/CallBreakdown.tsx`

```tsx
import { Phone, PhoneOutgoing, UserCheck, Voicemail } from 'lucide-react';
import type { Lead } from '@/domain/types';
import { countCallsByType, countCallsMadeToday } from '@/features/dashboard/dashboardCallStats';

export function CallBreakdown({ callLogs, todayOnly }: { callLogs: Lead['callLogs']; todayOnly?: boolean }) {
  const stats = todayOnly ? countCallsMadeToday(callLogs) : countCallsByType(callLogs);
  const items = [
    { label: 'Total Calls', value: stats.total, color: 'bg-blue-50 text-blue-600', icon: Phone },
    { label: 'Discovery', value: stats.discovery, color: 'bg-emerald-50 text-emerald-600', icon: UserCheck },
    { label: 'LVM', value: stats.lvm, color: 'bg-amber-50 text-amber-600', icon: Voicemail },
    { label: 'NVM', value: stats.nvm, color: 'bg-amber-50 text-amber-600', icon: PhoneOutgoing },
  ];
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {items.map(item => (
        <div key={item.label} className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
          <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-3 ${item.color}`}>
            <item.icon className="w-5 h-5" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{item.value}</div>
          <div className="text-sm text-slate-600 mt-0.5">{item.label}</div>
        </div>
      ))}
    </div>
  );
}

```

---

## `src/features/dashboard/components/ReassignRow.tsx`

```tsx
import { useState } from 'react';
import type { Lead, User } from '@/domain/types';

export function ReassignRow({ lead, agents, ownerName, onReassign }: {
  lead: Lead; agents: User[]; ownerName: string; onReassign: (agentId: string) => void;
}) {
  const options = agents.filter(a => a.id !== lead.agentId);
  const [target, setTarget] = useState(options[0]?.id ?? '');
  return (
    <div className="flex items-center gap-3 bg-white rounded-lg p-3 border border-rose-100">
      <div className="flex-1 min-w-0">
        <div className="text-sm font-medium text-slate-900 truncate">{lead.leadCode} — {lead.companyName}</div>
        <div className="text-xs text-slate-600">
          With {ownerName} • left the queue {lead.expiredAt ? new Date(lead.expiredAt).toLocaleDateString() : ''}
        </div>
      </div>
      <select
        value={target} onChange={e => setTarget(e.target.value)}
        className="px-2 py-1.5 rounded-lg border border-slate-200 text-xs bg-white"
      >
        {options.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
      </select>
      <button
        onClick={() => target && onReassign(target)}
        disabled={!target}
        className="px-3 py-1.5 rounded-lg text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-40"
      >
        Reassign
      </button>
    </div>
  );
}

```

---

## `src/features/dashboard/components/StatCard.tsx`

```tsx
import { Phone } from 'lucide-react';

export function StatCard({ label, value, icon: Icon, color }: { label: string; value: number; icon: typeof Phone; color: string }) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-3 ${color}`}>
        <Icon className="w-5 h-5" />
      </div>
      <div className="text-2xl font-bold text-slate-900">{value}</div>
      <div className="text-sm text-slate-600 mt-0.5">{label}</div>
    </div>
  );
}

```

---

## `src/features/dashboard/components/TodayMeetingsCard.tsx`

```tsx
import { Calendar } from 'lucide-react';
import type { Meeting, User } from '@/domain/types';

export function TodayMeetingsCard({ meetings, users, title = "Today's Meetings" }: { meetings: Meeting[]; users: User[]; title?: string }) {
  const sorted = [...meetings].sort((a, b) => a.time.localeCompare(b.time));
  return (
    <div className="bg-violet-50/50 rounded-xl border border-violet-100 p-5">
      <h3 className="text-sm font-semibold text-violet-900 mb-3 flex items-center gap-1.5">
        <Calendar className="w-4 h-4" />
        {title} ({sorted.length})
      </h3>
      {sorted.length === 0 ? (
        <p className="text-sm text-slate-500">No meetings today.</p>
      ) : (
        <div className="space-y-2">
          {sorted.map(m => {
            const agent = users.find(u => u.id === m.agentId);
            const who = m.type === 'lead_meeting'
              ? [m.companyName, agent?.name].filter(Boolean).join(' • ')
              : m.participantNames.join(', ');
            return (
              <div key={m.id} className="flex items-center gap-3 bg-white rounded-lg p-3 border border-violet-100">
                <div className="w-14 text-center shrink-0">
                  <div className="text-sm font-bold text-violet-700">{m.time}</div>
                  <div className="text-[11px] text-slate-500">{m.duration}min</div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-slate-900 truncate">{m.title}</div>
                  {who && <div className="text-xs text-slate-600 truncate">{who}</div>}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

```

---

## `src/features/dashboard/dashboardCallStats.ts`

```ts
/** Call counting helpers for the dashboards. */
import type { Lead } from '@/domain/types';

export function isTodayDate(dateStr: string) {
  return dateStr.split('T')[0] === new Date().toISOString().split('T')[0];
}

export function countCallsByType(callLogs: Lead['callLogs'], filterFn?: (cl: Lead['callLogs'][0]) => boolean) {
  const logs = filterFn ? callLogs.filter(filterFn) : callLogs;
  return {
    nvm: logs.filter(cl => cl.type === 'nvm').length,
    lvm: logs.filter(cl => cl.type === 'lvm').length,
    discovery: logs.filter(cl => cl.type === 'discovery').length,
    total: logs.length,
  };
}

export function countCallsMadeToday(callLogs: Lead['callLogs']) {
  return countCallsByType(callLogs, cl => isTodayDate(cl.timestamp));
}

```

---

## `src/features/email-center/EmailCenterPage.tsx`

```tsx
import { FileText, Mail, PenSquare, Search, Users } from 'lucide-react';
import { useMemo, useState } from 'react';
import { queueBucket } from '@/domain/workflow/leadQueue';
import { findCurrentTouchPoint, isOpenTouchPoint } from '@/domain/workflow/touchPoints';
import { BulkEmailModal } from '@/features/email-center/components/BulkEmailModal';
import { CustomEmailModal } from '@/features/email-center/components/CustomEmailModal';
import { TemplatedEmailModal } from '@/features/email-center/components/TemplatedEmailModal';
import { sendBulkEmailForLeads, sendEmailForLead, sendStandaloneEmail, useStore } from '@/store';

export function EmailCenterPage() {
  const { state, dispatch } = useStore();
  const currentUser = state.users.find(u => u.id === state.currentUserId)!;
  const [search, setSearch] = useState('');
  const [showSend, setShowSend] = useState(false);
  const [showBulk, setShowBulk] = useState(false);

  const isAgent = currentUser.role === 'agent';
  const isManager = currentUser.role === 'team_leader' || currentUser.role === 'operation_manager';

  const visibleLeads = useMemo(() => {
    if (isAgent) return state.leads.filter(l => l.agentId === currentUser.id && !l.removedFromQueue);
    if (currentUser.role === 'team_leader') {
      const team = state.teams.find(t => t.id === currentUser.teamId);
      return state.leads.filter(l => team?.agentIds.includes(l.agentId));
    }
    return state.leads.filter(l => !!l.agentId);   // pool leads have no agent yet
  }, [state.leads, currentUser, state.teams, isAgent]);

  const visibleLogs = useMemo(() => {
    let logs = state.emailLogs;
    if (isAgent) logs = logs.filter(log => log.sentBy === currentUser.id);
    else if (currentUser.role === 'team_leader') {
      const team = state.teams.find(t => t.id === currentUser.teamId);
      logs = logs.filter(log => {
        const lead = state.leads.find(l => l.id === log.leadId);
        return lead && team?.agentIds.includes(lead.agentId);
      });
    }
    if (search) logs = logs.filter(log =>
      log.subject.toLowerCase().includes(search.toLowerCase()) ||
      log.to.toLowerCase().includes(search.toLowerCase())
    );
    return [...logs].sort((a, b) => b.sentAt.localeCompare(a.sentAt));
  }, [state.emailLogs, state.leads, currentUser, state.teams, search, isAgent]);

  const templates = state.emailTemplates;

  // Optional shortcut: the agent's leads whose CURRENT step is an email that is due today (or overdue)
  const emailStepLeads = useMemo(() => state.leads.filter(l => {
    if (l.agentId !== currentUser.id || l.removedFromQueue || l.stopped) return false;
    const tp = findCurrentTouchPoint(l);
    return !!tp && tp.type === 'email' && isOpenTouchPoint(tp) && queueBucket(l) === 'today';
  }), [state.leads, currentUser.id]);

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-bold text-slate-900">Email Center</h2>
          <p className="text-sm text-slate-600">
            {isManager ? 'Send custom emails and track history' : 'Write your own emails (templates are optional) and track history'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {isAgent && (
            <button
              onClick={() => setShowBulk(true)}
              className="px-4 py-2 bg-white text-violet-700 border border-violet-200 rounded-lg text-sm font-medium hover:bg-violet-50 transition-all flex items-center gap-1.5"
            >
              <Users className="w-3.5 h-3.5" />
              Email step leads
              <span className="text-xs bg-violet-100 text-violet-700 px-1.5 py-0.5 rounded-full">{emailStepLeads.length}</span>
            </button>
          )}
          <button
            onClick={() => setShowSend(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-all flex items-center gap-1.5"
          >
            <PenSquare className="w-3.5 h-3.5" />
            {isManager ? 'Compose Email' : 'Write Email'}
          </button>
        </div>
      </div>

      {isAgent && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
          {templates.map(t => {
            const sentCount = state.emailLogs.filter(log => log.templateType === t.type).length;
            return (
              <div key={t.id} className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center shrink-0">
                    <FileText className="w-5 h-5 text-blue-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-semibold text-slate-900">{t.name}</h3>
                    <p className="text-xs text-slate-600 mt-0.5">Subject: {t.subject}</p>
                    <div className="flex items-center gap-3 mt-2">
                      <span className="text-xs text-slate-500 flex items-center gap-1">
                        <Mail className="w-3 h-3" />
                        {sentCount} sent
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-900">Email History</h3>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500" />
            <input
              type="text" value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search..." className="pl-9 pr-3 py-1.5 rounded-lg border border-slate-200 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 w-48"
            />
          </div>
        </div>
        <div className="divide-y divide-slate-100">
          {visibleLogs.length === 0 && (
            <div className="text-center py-12 text-slate-500">
              <Mail className="w-10 h-10 mx-auto mb-2 opacity-30" />
              <p className="text-sm">No emails sent yet</p>
            </div>
          )}
          {visibleLogs.map(log => (
            <div key={log.id} className="px-5 py-3 hover:bg-slate-50/30 transition-colors">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center shrink-0">
                  <Mail className="w-3.5 h-3.5 text-blue-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-slate-900">{log.subject}</span>
                    <span className="text-xs text-slate-500">→ {log.to}</span>
                    {log.auto && (
                      <span className="text-xs px-1.5 py-0.5 bg-violet-100 text-violet-700 rounded-full font-medium">
                        Auto · {log.templateType === 'discovery' ? 'Discovery' : 'No Response'}
                      </span>
                    )}
                    {log.templateType === 'custom' && (
                      <span className="text-xs px-1.5 py-0.5 bg-violet-100 text-violet-700 rounded-full font-medium">Custom</span>
                    )}
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5 truncate">{log.body}</p>
                  <div className="flex items-center gap-3 mt-1 text-xs text-slate-500">
                    <span>{new Date(log.sentAt).toLocaleString()}</span>
                    {log.leadName && <span>• {log.leadName}</span>}
                    <span>• by {log.sentByName}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {showSend && isManager && (
        <CustomEmailModal
          onClose={() => setShowSend(false)}
          onSend={(to, subject, body) => {
            dispatch(sendStandaloneEmail({
              to, subject, body,
              senderId: currentUser.id,
              senderName: currentUser.name,
            }));
            setShowSend(false);
          }}
        />
      )}

      {showBulk && isAgent && (
        <BulkEmailModal
          leads={emailStepLeads}
          templates={templates}
          onClose={() => setShowBulk(false)}
          onSend={(leadIds, subject, body) => {
            dispatch(sendBulkEmailForLeads({ leadIds, subject, body, senderId: currentUser.id, senderName: currentUser.name }));
            setShowBulk(false);
          }}
        />
      )}

      {showSend && isAgent && (
        <TemplatedEmailModal
          leads={visibleLeads}
          templates={templates}
          onClose={() => setShowSend(false)}
          onSend={(to, subject, body, leadId) => {
            const lead = visibleLeads.find(l => l.id === leadId);
            dispatch(sendEmailForLead({
              email: {
                id: crypto.randomUUID(),
                leadId: leadId || '',
                leadName: lead?.companyName || '',
                to,
                subject,
                body,
                templateType: 'custom',
                sentAt: new Date().toISOString(),
                sentBy: currentUser.id,
                sentByName: currentUser.name,
              },
              leadId: leadId || '',
              touchPointOrder: -1,
            }));
            setShowSend(false);
          }}
        />
      )}
    </div>
  );
}

```

---

## `src/features/email-center/components/BulkEmailModal.tsx`

```tsx
import { Send, X } from 'lucide-react';
import { useState } from 'react';
import type { EmailTemplate, Lead } from '@/domain/types';
import { findCurrentTouchPoint, stepLabel } from '@/domain/workflow/touchPoints';

/**
 * Optional shortcut (the main way to email is still writing it by hand).
 * Lists the agent's leads whose current step is a due EMAIL; the agent can send to all of them or pick some.
 * Sending marks that email step complete for every selected lead.
 */
export function BulkEmailModal({
  leads, templates, onClose, onSend,
}: {
  leads: Lead[];
  templates: EmailTemplate[];
  onClose: () => void;
  onSend: (leadIds: string[], subject: string, body: string) => void;
}) {
  const [selected, setSelected] = useState<string[]>([]);
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [templateId, setTemplateId] = useState('');

  const allSelected = leads.length > 0 && selected.length === leads.length;
  const toggle = (id: string) => setSelected(prev => (prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]));
  const withoutEmail = leads.filter(l => selected.includes(l.id) && !l.email).length;

  const applyTemplate = (id: string) => {
    setTemplateId(id);
    const t = templates.find(x => x.id === id);
    if (t) { setSubject(t.subject); setBody(t.body); }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg mx-4 animate-slide-up max-h-[90vh] overflow-y-auto scrollbar-thin">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between sticky top-0 bg-white z-10">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Email step leads</h2>
            <p className="text-sm text-slate-600">Leads whose current step is an email due today</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center">
            <X className="w-4 h-4 text-slate-600" />
          </button>
        </div>

        <div className="px-6 py-5 space-y-4">
          {leads.length === 0 ? (
            <p className="text-sm text-slate-500 text-center py-6">No leads are waiting on an email step right now.</p>
          ) : (
            <>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-medium text-slate-700">
                    Leads <span className="text-xs text-slate-500 font-normal">({selected.length}/{leads.length})</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setSelected(allSelected ? [] : leads.map(l => l.id))}
                    className="text-xs font-medium text-blue-600 hover:text-blue-700"
                  >
                    {allSelected ? 'Clear all' : 'Select all'}
                  </button>
                </div>
                <div className="space-y-1 max-h-48 overflow-y-auto scrollbar-thin border border-slate-200 rounded-xl p-2">
                  {leads.map(l => {
                    const tp = findCurrentTouchPoint(l);
                    return (
                      <label key={l.id} className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-slate-50 cursor-pointer">
                        <input type="checkbox" checked={selected.includes(l.id)} onChange={() => toggle(l.id)} className="rounded" />
                        <span className="text-xs font-mono text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded shrink-0">{l.leadCode}</span>
                        <span className="text-sm text-slate-700 truncate flex-1">{l.companyName}</span>
                        {tp && <span className="text-xs text-slate-500 shrink-0">{stepLabel(tp.order, tp.type)}</span>}
                        {!l.email && <span className="text-xs text-rose-500 shrink-0">no email</span>}
                      </label>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Template (optional)</label>
                <select
                  value={templateId} onChange={e => applyTemplate(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 bg-white"
                >
                  <option value="">Write it myself...</option>
                  {templates.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Subject</label>
                <input
                  type="text" value={subject} onChange={e => setSubject(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Message</label>
                <textarea
                  value={body} onChange={e => setBody(e.target.value)} rows={7}
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 resize-none"
                />
                <p className="text-xs text-slate-500 mt-1">[Name], [Company Name] and [Agent Name] are filled in for each lead.</p>
              </div>

              {withoutEmail > 0 && (
                <p className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
                  {withoutEmail} selected lead{withoutEmail > 1 ? 's have' : ' has'} no email address saved.
                </p>
              )}
            </>
          )}
        </div>

        <div className="px-6 py-4 border-t border-slate-100 flex justify-end gap-2 sticky bottom-0 bg-white">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100">Cancel</button>
          <button
            onClick={() => onSend(selected, subject, body)}
            disabled={selected.length === 0 || !subject.trim() || !body.trim()}
            className="px-4 py-2 rounded-lg text-sm font-medium text-white bg-violet-600 hover:bg-violet-700 disabled:opacity-40 transition-all flex items-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5" />
            Send & Mark Complete ({selected.length})
          </button>
        </div>
      </div>
    </div>
  );
}

```

---

## `src/features/email-center/components/CustomEmailModal.tsx`

```tsx
import { Send, X } from 'lucide-react';
import { useState } from 'react';

export function CustomEmailModal({
  onClose, onSend,
}: {
  onClose: () => void;
  onSend: (to: string, subject: string, body: string) => void;
}) {
  const [to, setTo] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg mx-4 animate-slide-up max-h-[90vh] overflow-y-auto scrollbar-thin">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between sticky top-0 bg-white z-10">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Compose Email</h2>
            <p className="text-sm text-slate-600">Custom email — write from scratch</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center">
            <X className="w-4 h-4 text-slate-600" />
          </button>
        </div>
        <div className="px-6 py-5 space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">To</label>
            <input
              type="text"
              value={to}
              onChange={e => setTo(e.target.value)}
              placeholder="recipient@example.com"
              className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Subject</label>
            <input
              type="text"
              value={subject}
              onChange={e => setSubject(e.target.value)}
              className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Message</label>
            <textarea
              value={body}
              onChange={e => setBody(e.target.value)}
              rows={8}
              className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 resize-none"
            />
          </div>
        </div>
        <div className="px-6 py-4 border-t border-slate-100 flex justify-end gap-2 sticky bottom-0 bg-white">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100">Cancel</button>
          <button
            onClick={() => onSend(to, subject, body)}
            disabled={!to.trim() || !subject.trim()}
            className="px-4 py-2 rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-40 transition-all flex items-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5" />
            Send Email
          </button>
        </div>
      </div>
    </div>
  );
}

```

---

## `src/features/email-center/components/TemplatedEmailModal.tsx`

```tsx
import { Send, X } from 'lucide-react';
import { useState } from 'react';
import type { EmailTemplate, Lead } from '@/domain/types';
import { LeadPicker } from '@/shared/components/LeadPicker';

export function TemplatedEmailModal({
  leads, templates, onClose, onSend,
}: {
  leads: Lead[];
  templates: EmailTemplate[];
  onClose: () => void;
  onSend: (to: string, subject: string, body: string, leadId?: string) => void;
}) {
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [to, setTo] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [linkLeadId, setLinkLeadId] = useState('');

  const handleTemplateChange = (id: string) => {
    setSelectedTemplate(id);
    const tpl = templates.find(t => t.id === id);
    if (tpl) {
      setSubject(tpl.subject);
      setBody(tpl.body);
    }
  };

  const handleLeadLink = (leadId: string) => {
    setLinkLeadId(leadId);
    const lead = leads.find(l => l.id === leadId);
    if (lead?.email) setTo(lead.email);
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg mx-4 animate-slide-up max-h-[90vh] overflow-y-auto scrollbar-thin">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between sticky top-0 bg-white z-10">
          <h2 className="text-lg font-bold text-slate-900">Send Email</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center">
            <X className="w-4 h-4 text-slate-600" />
          </button>
        </div>
        <div className="px-6 py-5 space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Template</label>
            <select
              value={selectedTemplate} onChange={e => handleTemplateChange(e.target.value)}
              className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 bg-white"
            >
              <option value="">Select template...</option>
              {templates.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">To</label>
            <input
              type="email"
              value={to}
              onChange={e => setTo(e.target.value)}
              placeholder="recipient@example.com"
              className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Link to Lead (optional — auto-fills email)</label>
            <LeadPicker leads={leads} value={linkLeadId} onChange={handleLeadLink} />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Subject</label>
            <input
              type="text"
              value={subject}
              onChange={e => setSubject(e.target.value)}
              className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Message</label>
            <textarea
              value={body}
              onChange={e => setBody(e.target.value)}
              rows={8}
              className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 resize-none"
            />
          </div>
        </div>
        <div className="px-6 py-4 border-t border-slate-100 flex justify-end gap-2 sticky bottom-0 bg-white">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100">Cancel</button>
          <button
            onClick={() => {
              if (!to.trim() || !subject.trim()) return;
              onSend(to, subject, body, linkLeadId || undefined);
              setSelectedTemplate(''); setTo(''); setSubject(''); setBody(''); setLinkLeadId('');
            }}
            disabled={!to.trim() || !subject.trim()}
            className="px-4 py-2 rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-40 transition-all flex items-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5" />
            Send Email
          </button>
        </div>
      </div>
    </div>
  );
}

```

---

## `src/features/lead-pool/LeadPoolPage.tsx`

```tsx
import { Building2, Database, Plus, Search, Trash2, Upload } from 'lucide-react';
import { useMemo, useState } from 'react';
import { normalizeLeadCode } from '@/domain/lead/leadCode';
import { isInPool } from '@/domain/lead/leadPool';
import { campaignLabel } from '@/domain/workflow/campaignLabel';
import { AddSingleLeadModal } from '@/features/lead-pool/components/AddSingleLeadModal';
import { PasteLeadsModal } from '@/features/lead-pool/components/PasteLeadsModal';
import { useConfirm } from '@/shared/components/ConfirmDialog';
import { addLeadsToPool, deleteLeadsAsAdmin, useStore } from '@/store';

export function LeadPoolPage() {
  const { state, dispatch } = useStore();
  const me = state.users.find(u => u.id === state.currentUserId)!;
  const [showPaste, setShowPaste] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState<'all' | 'pool' | 'assigned'>('all');
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const { ask, dialog: confirmDialog } = useConfirm();

  const rows = useMemo(() => {
    const nq = normalizeLeadCode(q), raw = q.trim().toLowerCase();
    return state.leads.filter(l => {
      if (filter === 'pool' && !isInPool(l)) return false;
      if (filter === 'assigned' && isInPool(l)) return false;
      if (!raw) return true;
      return (nq && normalizeLeadCode(l.leadCode).includes(nq)) || l.companyName.toLowerCase().includes(raw) || l.contactName.toLowerCase().includes(raw);
    });
  }, [state.leads, q, filter]);

  const poolCount = state.leads.filter(isInPool).length;
  // a lead with a recorded sale cannot be deleted (the sale and the reports point at it)
  const soldIds = useMemo(() => new Set(state.sales.map(s => s.leadId)), [state.sales]);
  const shown = rows.slice(0, 300);
  const deletable = shown.filter(l => !soldIds.has(l.id));
  const allShownSelected = deletable.length > 0 && deletable.every(l => selected.has(l.id));
  const toggle = (id: string) => setSelected(p => { const n = new Set(p); if (n.has(id)) n.delete(id); else n.add(id); return n; });
  const toggleAll = () => setSelected(p => {
    const n = new Set(p);
    if (allShownSelected) deletable.forEach(l => n.delete(l.id)); else deletable.forEach(l => n.add(l.id));
    return n;
  });
  const askDelete = (ids: string[]) => {
    const n = ids.length;
    const only = n === 1 ? state.leads.find(l => l.id === ids[0]) : undefined;
    ask(
      {
        title: n === 1 ? 'Delete this lead?' : `Delete ${n} leads?`,
        message: <>{only ? <><b>{only.leadCode} — {only.companyName}</b> will be</> : <>These {n} leads will be</>} deleted permanently, with their call history and activity log. Their arranged meetings will be cancelled. This can’t be undone.</>,
        confirmLabel: 'Delete permanently', tone: 'danger',
      },
      () => { dispatch(deleteLeadsAsAdmin(ids)); setSelected(p => { const x = new Set(p); ids.forEach(id => x.delete(id)); return x; }); },
    );
  };
  const selectedIds = [...selected].filter(id => state.leads.some(l => l.id === id) && !soldIds.has(id));

  const nameOf = (id: string) => state.users.find(u => u.id === id)?.name ?? '—';

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-6 gap-3 flex-wrap">
        <div>
          <h2 className="text-lg font-bold text-slate-900 mb-1">Lead Pool</h2>
          <p className="text-sm text-slate-600">{state.leads.length} leads · {poolCount} waiting in the pool for an agent</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          {selectedIds.length > 0 && (
            <button onClick={() => askDelete(selectedIds)} className="px-4 py-2 bg-rose-600 text-white rounded-lg text-sm font-medium hover:bg-rose-700 flex items-center gap-1.5">
              <Trash2 className="w-3.5 h-3.5" />Delete selected ({selectedIds.length})
            </button>
          )}
          <button onClick={() => setShowForm(true)} className="px-4 py-2 border border-slate-200 bg-white text-slate-700 rounded-lg text-sm font-medium hover:bg-slate-50 flex items-center gap-1.5">
            <Plus className="w-3.5 h-3.5" />Add One Lead
          </button>
          <button onClick={() => setShowPaste(true)} className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 flex items-center gap-1.5">
            <Upload className="w-3.5 h-3.5" />Paste Leads
          </button>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search by lead ID, company or contact..."
            className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500" />
        </div>
        <select value={filter} onChange={e => setFilter(e.target.value as typeof filter)}
          className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500">
          <option value="all">All leads</option>
          <option value="pool">In the pool</option>
          <option value="assigned">Held by an agent</option>
        </select>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50/50">
                <th className="px-4 py-3 w-10">
                  <input type="checkbox" checked={allShownSelected} onChange={toggleAll} disabled={deletable.length === 0} aria-label="Select all shown leads" />
                </th>
                {['Lead ID', 'Company', 'Contact', 'Phone', 'Email', 'Campaign', 'Held by'].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-slate-600">{h}</th>
                ))}
                <th className="px-4 py-3 w-12" />
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rows.length === 0 && (
                <tr><td colSpan={9} className="px-4 py-12 text-center text-slate-500">
                  <Database className="w-10 h-10 mx-auto mb-2 opacity-30" />No leads found
                </td></tr>
              )}
              {shown.map(l => (
                <tr key={l.id} className={`hover:bg-slate-50/30 ${selected.has(l.id) ? 'bg-blue-50/40' : ''}`}>
                  <td className="px-4 py-3">
                    <input type="checkbox" checked={selected.has(l.id)} onChange={() => toggle(l.id)} disabled={soldIds.has(l.id)}
                      title={soldIds.has(l.id) ? 'Has a recorded sale - cannot be deleted' : undefined} aria-label={`Select ${l.leadCode}`} />
                  </td>
                  <td className="px-4 py-3"><span className="text-xs font-mono text-slate-700 bg-slate-100 px-2 py-0.5 rounded">{l.leadCode}</span></td>
                  <td className="px-4 py-3 text-sm font-medium text-slate-900"><span className="inline-flex items-center gap-2"><Building2 className="w-3.5 h-3.5 text-slate-500" />{l.companyName}</span></td>
                  <td className="px-4 py-3 text-sm text-slate-700">{l.contactName || '—'}</td>
                  <td className="px-4 py-3 text-sm text-slate-600 whitespace-nowrap">{l.phone || '—'}</td>
                  <td className="px-4 py-3 text-sm text-slate-600">{l.email || '—'}</td>
                  <td className="px-4 py-3"><span className="text-xs text-slate-600 bg-slate-100 px-2 py-0.5 rounded">{campaignLabel(state.workflows, l.campaignCode)}</span></td>
                  <td className="px-4 py-3">
                    {isInPool(l)
                      ? <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-emerald-100 text-emerald-700">{l.agentId ? 'Back in pool' : 'In pool'}</span>
                      : <span className="text-sm text-slate-700">{nameOf(l.agentId)}</span>}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => askDelete([l.id])} disabled={soldIds.has(l.id)}
                      title={soldIds.has(l.id) ? 'Has a recorded sale - cannot be deleted' : 'Delete lead'} aria-label={`Delete ${l.leadCode}`}
                      className="w-8 h-8 inline-flex items-center justify-center rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:text-slate-500">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {rows.length > 300 && <div className="px-4 py-2 text-xs text-slate-500 border-t border-slate-100">Showing 300 of {rows.length} - search to narrow it down</div>}
      </div>

      {confirmDialog}

      {showPaste && (
        <PasteLeadsModal
          workflows={state.workflows} existing={state.leads}
          onClose={() => setShowPaste(false)}
          onAdd={leads => dispatch(addLeadsToPool(leads))}
          adminId={me.id} adminName={me.name}
        />
      )}
      {showForm && (
        <AddSingleLeadModal
          workflows={state.workflows} existing={state.leads}
          onClose={() => setShowForm(false)}
          onAdd={lead => dispatch(addLeadsToPool([lead]))}
          adminId={me.id} adminName={me.name}
        />
      )}
    </div>
  );
}

```

---

## `src/features/lead-pool/components/AddSingleLeadModal.tsx`

```tsx
import { Plus } from 'lucide-react';
import { useState } from 'react';
import { createPoolLead } from '@/domain/lead/createPoolLead';
import { cleanLeadCode, isValidEmail, isValidLeadCode, normalizeLeadCode } from '@/domain/lead/leadCode';
import type { Lead, Workflow } from '@/domain/types';
import { campaignLabel } from '@/domain/workflow/campaignLabel';
import { LeadImportModalShell } from '@/features/lead-pool/components/LeadImportModalShell';
import { TEXT_INPUT_CLASS } from '@/features/lead-pool/formStyles';

export function AddSingleLeadModal({ workflows, existing, onClose, onAdd, adminId, adminName }: {
  workflows: Workflow[]; existing: Lead[]; onClose: () => void; onAdd: (l: Lead) => void; adminId: string; adminName: string;
}) {
  const [f, setF] = useState({ leadCode: '', companyName: '', contactName: '', phone: '', email: '', campaignCode: workflows[0]?.campaignCode || '' });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF(p => ({ ...p, [k]: e.target.value }));

  const code = cleanLeadCode(f.leadCode);
  const error =
    !code ? '' :
    !isValidLeadCode(code) ? 'Lead ID must contain letters and numbers only' :
    existing.some(l => normalizeLeadCode(l.leadCode) === normalizeLeadCode(code)) ? 'This lead ID already exists' :
    f.email && !isValidEmail(f.email.trim()) ? 'Invalid email' : '';
  const canAdd = !!code && !error && !!f.companyName.trim() && !!f.campaignCode;

  const submit = () => {
    if (!canAdd) return;
    onAdd(createPoolLead(adminId, adminName, {
      leadCode: code, campaignCode: f.campaignCode, companyName: f.companyName.trim(),
      contactName: f.contactName.trim(), phone: f.phone.trim(), email: f.email.trim(),
    }));
    onClose();
  };

  return (
    <LeadImportModalShell title="Add One Lead" subtitle="It goes to the shared pool" onClose={onClose}
      footer={<>
        <button onClick={onClose} className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100">Cancel</button>
        <button onClick={submit} disabled={!canAdd} className="px-4 py-2 rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-40 flex items-center gap-1.5">
          <Plus className="w-3.5 h-3.5" />Add Lead
        </button>
      </>}>
      <div className="grid grid-cols-2 gap-3">
        <div><label className="block text-sm font-medium text-slate-700 mb-1.5">Lead ID *</label><input className={TEXT_INPUT_CLASS} value={f.leadCode} onChange={set('leadCode')} autoFocus /></div>
        <div><label className="block text-sm font-medium text-slate-700 mb-1.5">Campaign *</label>
          <select className={TEXT_INPUT_CLASS} value={f.campaignCode} onChange={set('campaignCode')}>
            {workflows.map(w => <option key={w.id} value={w.campaignCode}>{campaignLabel(workflows, w.campaignCode)}</option>)}
          </select></div>
        <div className="col-span-2"><label className="block text-sm font-medium text-slate-700 mb-1.5">Company *</label><input className={TEXT_INPUT_CLASS} value={f.companyName} onChange={set('companyName')} /></div>
        <div><label className="block text-sm font-medium text-slate-700 mb-1.5">Contact person</label><input className={TEXT_INPUT_CLASS} value={f.contactName} onChange={set('contactName')} /></div>
        <div><label className="block text-sm font-medium text-slate-700 mb-1.5">Phone</label><input className={TEXT_INPUT_CLASS} value={f.phone} onChange={set('phone')} /></div>
        <div className="col-span-2"><label className="block text-sm font-medium text-slate-700 mb-1.5">Email</label><input className={TEXT_INPUT_CLASS} value={f.email} onChange={set('email')} /></div>
      </div>
      {error && <p className="text-xs text-rose-700 bg-rose-50 rounded-lg px-3 py-2">{error}</p>}
    </LeadImportModalShell>
  );
}

```

---

## `src/features/lead-pool/components/LeadImportModalShell.tsx`

```tsx
import { XCircle } from 'lucide-react';

export function LeadImportModalShell({ title, subtitle, onClose, children, footer }: {
  title: string; subtitle: string; onClose: () => void; children: React.ReactNode; footer: React.ReactNode;
}) {
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg mx-4 animate-slide-up max-h-[90vh] overflow-y-auto scrollbar-thin">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between sticky top-0 bg-white z-10">
          <div><h2 className="text-lg font-bold text-slate-900">{title}</h2><p className="text-sm text-slate-600">{subtitle}</p></div>
          <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center" aria-label="Close"><XCircle className="w-4 h-4 text-slate-600" /></button>
        </div>
        <div className="px-6 py-5 space-y-4">{children}</div>
        <div className="px-6 py-4 border-t border-slate-100 flex justify-end gap-2 sticky bottom-0 bg-white">{footer}</div>
      </div>
    </div>
  );
}

```

---

## `src/features/lead-pool/components/PasteLeadsModal.tsx`

```tsx
import { Plus, Upload } from 'lucide-react';
import { useMemo, useState } from 'react';
import { createPoolLead } from '@/domain/lead/createPoolLead';
import { parseAdminRows } from '@/domain/lead/leadImport';
import type { Lead, Workflow } from '@/domain/types';
import { campaignLabel } from '@/domain/workflow/campaignLabel';
import { LeadImportModalShell } from '@/features/lead-pool/components/LeadImportModalShell';
import { TEXT_INPUT_CLASS } from '@/features/lead-pool/formStyles';

export function PasteLeadsModal({ workflows, existing, onClose, onAdd, adminId, adminName }: {
  workflows: Workflow[]; existing: Lead[]; onClose: () => void; onAdd: (l: Lead[]) => void; adminId: string; adminName: string;
}) {
  const [campaign, setCampaign] = useState(workflows[0]?.campaignCode || '');
  const [text, setText] = useState('');
  const [added, setAdded] = useState(0);
  const parsed = useMemo(() => parseAdminRows(text, existing, workflows, campaign), [text, existing, workflows, campaign]);

  const handleAdd = () => {
    if (!parsed.accepted.length) return;
    onAdd(parsed.accepted.map(r => createPoolLead(adminId, adminName, {
      leadCode: r.leadCode, campaignCode: r.campaignCode, companyName: r.companyName,
      contactName: r.contactName, phone: r.phone, email: r.email,
    })));
    setAdded(n => n + parsed.accepted.length);
    if (parsed.rejected.length === 0) onClose(); else setText(parsed.rejected.map(r => r.raw).join('\n'));
  };

  return (
    <LeadImportModalShell title="Paste Leads" subtitle="They go to the shared pool - no agent yet" onClose={onClose}
      footer={<>
        <button onClick={onClose} className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100">Cancel</button>
        <button onClick={handleAdd} disabled={parsed.accepted.length === 0}
          className="px-4 py-2 rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-40 flex items-center gap-1.5">
          <Plus className="w-3.5 h-3.5" />{parsed.accepted.length > 0 ? `Add ${parsed.accepted.length} lead${parsed.accepted.length === 1 ? '' : 's'}` : 'Add Leads'}
        </button>
      </>}>
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1.5">Default campaign</label>
        <select value={campaign} onChange={e => setCampaign(e.target.value)} className={TEXT_INPUT_CLASS}>
          {workflows.map(w => <option key={w.id} value={w.campaignCode}>{campaignLabel(workflows, w.campaignCode)}</option>)}
        </select>
        <p className="text-xs text-slate-500 mt-1">Used for every row that has no campaign column.</p>
      </div>
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1.5"><Upload className="w-3.5 h-3.5 inline mr-1" />Paste lead rows</label>
        <div className="text-xs text-slate-500 mb-2 bg-slate-50 rounded-lg p-2">
          Lead ID [Tab] Company [Tab] Contact [Tab] Phone [Tab] Email [Tab] Campaign (optional)
          <br />One lead per line. The ID must be letters and numbers only and must not exist yet.
        </div>
        <textarea value={text} onChange={e => setText(e.target.value)} rows={8}
          placeholder={'LD101\tTechCorp\tJohn Smith\t+20 100 111 2222\tjohn@techcorp.com\tACT-001\nLD102\tDataSys\tJane Doe\t+20 101 333 4444\tjane@datasys.com\tRET-002'}
          className={`${TEXT_INPUT_CLASS} font-mono resize-none`} />
        {added > 0 && <p className="mt-2 text-xs text-emerald-700 bg-emerald-50 rounded-lg px-3 py-2">{added} lead{added === 1 ? '' : 's'} added to the pool. The rows below need fixing.</p>}
        {text.trim() && (
          <div className="mt-2 text-xs space-y-1.5" aria-live="polite">
            <p><span className="font-medium text-emerald-700">{parsed.accepted.length} ready</span>
              {parsed.rejected.length > 0 && <span className="font-medium text-rose-600"> · {parsed.rejected.length} with a problem</span>}</p>
            {parsed.rejected.length > 0 && (
              <ul className="max-h-32 overflow-y-auto scrollbar-thin rounded-lg bg-rose-50 border border-rose-100 divide-y divide-rose-100">
                {parsed.rejected.slice(0, 50).map(r => (
                  <li key={r.line} className="px-3 py-1.5 text-rose-700"><span className="font-mono">Line {r.line}{r.leadCode ? ` · ${r.leadCode}` : ''}</span> — {r.reason}</li>
                ))}
                {parsed.rejected.length > 50 && <li className="px-3 py-1.5 text-rose-600">…and {parsed.rejected.length - 50} more</li>}
              </ul>
            )}
          </div>
        )}
      </div>
    </LeadImportModalShell>
  );
}

```

---

## `src/features/lead-pool/formStyles.ts`

```ts
export const TEXT_INPUT_CLASS = 'w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 bg-white';

```

---

## `src/features/my-leads/MyLeadsPage.tsx`

```tsx
import { Ban, Building2, Download, Hash, History, Mail, Phone, Play, Users, X, XCircle } from 'lucide-react';
import { useMemo, useState } from 'react';
import type { Lead } from '@/domain/types';
import { campaignLabel } from '@/domain/workflow/campaignLabel';
import { TakeLeadsModal } from '@/features/take-leads/TakeLeadsModal';
import { useConfirm } from '@/shared/components/ConfirmDialog';
import { LeadPicker } from '@/shared/components/LeadPicker';
import { LEAD_STATUS_STYLE } from '@/shared/ui/leadStatusStyles';
import { removeLeadFromAgentQueue, resumeLeadWorkflow, stopLeadWorkflow, takeLeadsFromPool, useStore } from '@/store';

export function MyLeadsPage() {
  const { state, dispatch } = useStore();
  const currentUser = state.users.find(u => u.id === state.currentUserId)!;
  const [filterCampaign, setFilterCampaign] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  // keep only the id: the drawer always shows the live lead from the store (a copy would go stale after Stop / Resume)
  const [selectedLeadId, setSelectedLeadId] = useState<string | null>(null);
  const selectedLead = selectedLeadId ? state.leads.find(l => l.id === selectedLeadId) ?? null : null;
  const setSelectedLead = (l: Lead | null) => setSelectedLeadId(l?.id ?? null);
  const { ask, dialog: confirmDialog } = useConfirm();
  const [showTake, setShowTake] = useState(false);

  const visibleLeads = useMemo(() => {
    // a removed lead is out of "My Leads" (its history is kept in the data)
    let leads = state.leads.filter(l => l.agentId === currentUser.id && !l.removedFromQueue);
    if (filterCampaign) leads = leads.filter(l => l.campaignCode === filterCampaign);
    if (filterStatus) leads = leads.filter(l => l.status === filterStatus);
    return leads;
  }, [state.leads, currentUser, filterCampaign, filterStatus]);

  const campaigns = [...new Set(state.leads.map(l => l.campaignCode))];

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-bold text-slate-900 mb-1">My Leads</h2>
          <p className="text-sm text-slate-600">{visibleLeads.length} leads</p>
        </div>
        <button
          onClick={() => setShowTake(true)}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-all flex items-center gap-1.5"
        >
          <Download className="w-3.5 h-3.5" />
          Take Leads
        </button>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="flex-1">
          <LeadPicker
            leads={visibleLeads}
            value=""
            onChange={id => { const l = state.leads.find(x => x.id === id); if (l) setSelectedLead(l); }}
            placeholder="Search a lead by name, code, email or phone, then select it..."
          />
        </div>
        <select
          value={filterCampaign} onChange={e => setFilterCampaign(e.target.value)}
          className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="">All Campaigns</option>
          {campaigns.map(c => <option key={c} value={c}>{campaignLabel(state.workflows, c)}</option>)}
        </select>
        <select
          value={filterStatus} onChange={e => setFilterStatus(e.target.value)}
          className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="">All Statuses</option>
          {Object.entries(LEAD_STATUS_STYLE).map(([key, cfg]) => (
            <option key={key} value={key}>{cfg.label}</option>
          ))}
        </select>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50/50">
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600">Lead Code</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600">Company</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600">Contact</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600">Campaign</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600">Status</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600">Progress</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {visibleLeads.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-4 py-12 text-center text-slate-500">
                    <Users className="w-10 h-10 mx-auto mb-2 opacity-30" />
                    No leads found
                  </td>
                </tr>
              )}
              {visibleLeads.map(lead => {
                const completed = lead.touchPoints.filter(tp => tp.status === 'completed').length;
                const total = lead.touchPoints.length;
                const cfg = LEAD_STATUS_STYLE[lead.status];

                return (
                  <tr key={lead.id} className="hover:bg-slate-50/30 transition-colors">
                    <td className="px-4 py-3">
                      <span className="text-xs font-mono text-slate-700 bg-slate-100 px-2 py-0.5 rounded">{lead.leadCode}</span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <Building2 className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                        <span className="text-sm font-medium text-slate-900">{lead.companyName}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="text-sm text-slate-700">{lead.contactName}</div>
                      <div className="text-xs text-slate-500">{lead.phone || 'No phone'}</div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-xs text-slate-600 bg-slate-100 px-2 py-0.5 rounded">{campaignLabel(state.workflows, lead.campaignCode)}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${cfg.color}`}>{cfg.label}</span>
                      {lead.expiredAt && (
                        <span className="ml-1.5 text-xs px-2 py-0.5 rounded-full font-medium bg-rose-100 text-rose-700">Expired</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-20 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-blue-500 rounded-full transition-all"
                            style={{ width: `${total ? (completed / total) * 100 : 0}%` }}
                          />
                        </div>
                        <span className="text-xs text-slate-600">{completed}/{total}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => setSelectedLead(lead)}
                        className="text-xs text-blue-600 hover:underline font-medium"
                      >
                        Details
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {selectedLead && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div className="absolute inset-0 bg-black/30 animate-fade-in" onClick={() => setSelectedLead(null)} />
          <div className="relative w-full max-w-lg bg-white h-full overflow-y-auto scrollbar-thin animate-slide-in shadow-2xl">
            <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 z-10 flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-slate-900">{selectedLead.leadCode}</h2>
                <p className="text-sm text-slate-600">{selectedLead.companyName} • {selectedLead.contactName}</p>
              </div>
              <button onClick={() => setSelectedLead(null)} className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center">
                <X className="w-4 h-4 text-slate-600" />
              </button>
            </div>

            <div className="px-6 py-4 border-b border-slate-200">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-xs text-slate-500 mb-1 flex items-center gap-1"><Phone className="w-3 h-3" />Phone</div>
                  <div className="text-sm text-slate-900">{selectedLead.phone || '—'}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500 mb-1 flex items-center gap-1"><Mail className="w-3 h-3" />Email</div>
                  <div className="text-sm text-slate-900 truncate">{selectedLead.email || '—'}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500 mb-1 flex items-center gap-1"><Hash className="w-3 h-3" />Lead Code</div>
                  <div className="text-sm font-mono text-slate-900">{selectedLead.leadCode}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500 mb-1">Status</div>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${LEAD_STATUS_STYLE[selectedLead.status].color}`}>
                    {LEAD_STATUS_STYLE[selectedLead.status].label}
                  </span>
                </div>
              </div>
            </div>

            <div className="px-6 py-4 border-b border-slate-200">
              <h3 className="text-sm font-semibold text-slate-900 mb-3">Touch Points Progress</h3>
              <div className="space-y-2">
                {selectedLead.touchPoints.map(tp => (
                  <div key={tp.order} className="flex items-center gap-3 p-2.5 rounded-lg bg-slate-50">
                    <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 ${
                      tp.status === 'completed' ? 'bg-emerald-100' : 'bg-slate-200'
                    }`}>
                      {tp.type === 'call' ? <Phone className="w-3.5 h-3.5 text-slate-600" /> : <Mail className="w-3.5 h-3.5 text-slate-600" />}
                    </div>
                    <span className="text-sm text-slate-700 flex-1">{tp.label}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      tp.status === 'completed' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'
                    }`}>{tp.status}</span>
                  </div>
                ))}
              </div>
            </div>

            {selectedLead.callLogs.length > 0 && (
              <div className="px-6 py-4 border-b border-slate-200">
                <h3 className="text-sm font-semibold text-slate-900 mb-3">Call Logs</h3>
                <div className="space-y-2">
                  {selectedLead.callLogs.map(cl => (
                    <div key={cl.id} className="p-3 bg-slate-50 rounded-lg">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 font-medium">{cl.type.toUpperCase()}</span>
                        <span className="text-xs text-slate-500">{new Date(cl.timestamp).toLocaleString()}</span>
                      </div>
                      <p className="text-sm text-slate-700">{cl.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="px-6 py-4">
              <h3 className="text-sm font-semibold text-slate-900 mb-3 flex items-center gap-1.5">
                <History className="w-3.5 h-3.5 text-slate-500" />
                Activity History
              </h3>
              <div className="space-y-2">
                {selectedLead.history.map(h => (
                  <div key={h.id} className="flex items-start gap-2 text-xs">
                    <div className="w-1.5 h-1.5 bg-slate-300 rounded-full mt-1.5 shrink-0" />
                    <div className="flex-1">
                      <span className="text-slate-600">
                        <span className="font-medium text-slate-900">{h.userName}</span> — {h.action.replace(/_/g, ' ')}
                        {h.detail && <span className="text-slate-500"> • {h.detail}</span>}
                      </span>
                      <div className="text-slate-500">{new Date(h.timestamp).toLocaleString()}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {!selectedLead.removedFromQueue && !selectedLead.expiredAt && (
              <div className="px-6 py-4 border-t border-slate-100 flex gap-2">
                {selectedLead.stopped ? (
                  <button
                    onClick={() => { dispatch(resumeLeadWorkflow(selectedLead.id)); setSelectedLead(null); }}
                    className="px-4 py-2 rounded-lg text-sm font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 transition-colors flex items-center gap-1.5"
                  >
                    <Play className="w-3.5 h-3.5" />
                    Resume Workflow
                  </button>
                ) : (
                  <button
                    onClick={() => ask(
                      { title: 'Stop this workflow?', message: <><b>{selectedLead.companyName}</b> will stop moving through its touch points. You can resume it later.</>, confirmLabel: 'Stop workflow' },
                      () => { dispatch(stopLeadWorkflow(selectedLead.id)); setSelectedLead(null); },
                    )}
                    className="px-4 py-2 rounded-lg text-sm font-medium text-amber-700 bg-amber-50 hover:bg-amber-100 transition-colors flex items-center gap-1.5"
                  >
                    <Ban className="w-3.5 h-3.5" />
                    Stop Workflow
                  </button>
                )}
                <button
                  onClick={() => ask(
                    { title: 'Remove this lead?', message: <><b>{selectedLead.companyName}</b> leaves your leads and will not continue its steps. Its history and activity are kept. It goes back to the shared pool and its lead ID becomes free for any agent to take again.</>, confirmLabel: 'Remove lead', tone: 'danger' },
                    () => { dispatch(removeLeadFromAgentQueue(selectedLead.id)); setSelectedLead(null); },
                  )}
                  className="px-4 py-2 rounded-lg text-sm font-medium text-rose-700 bg-rose-50 hover:bg-rose-100 transition-colors flex items-center gap-1.5"
                >
                  <XCircle className="w-3.5 h-3.5" />
                  Remove Lead
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {confirmDialog}

      {showTake && (
        <TakeLeadsModal
          leads={state.leads} users={state.users} workflows={state.workflows} me={currentUser}
          onTake={ids => dispatch(takeLeadsFromPool(ids))}
          onClose={() => setShowTake(false)}
        />
      )}
    </div>
  );
}

```

---

## `src/features/sales/SalesPage.tsx`

```tsx
import { ChevronDown, ChevronLeft, ChevronRight, Crown, Plus, Target, Trash2, Trophy } from 'lucide-react';
import { useMemo, useState } from 'react';
import { topAgentsOfMonth } from '@/domain/sales/salesLeaderboard';
import { saleTypeConfig } from '@/domain/sales/saleTypes';
import { AGENT_SALES_TARGET, teamSalesTarget } from '@/domain/sales/salesTargets';
import type { Team } from '@/domain/types';
import { AgentSalesDetails } from '@/features/sales/components/AgentSalesDetails';
import { RecordSaleModal } from '@/features/sales/components/RecordSaleModal';
import { SaleTypeChips } from '@/features/sales/components/SaleTypeChips';
import { SortDirectionButton } from '@/features/sales/components/SortDirectionButton';
import { TargetProgressBar } from '@/features/sales/components/TargetProgressBar';
import { TopAgentsCard } from '@/features/sales/components/TopAgentsCard';
import type { SortDirection, TeamGroup } from '@/features/sales/salesTypes';
import { useConfirm } from '@/shared/components/ConfirmDialog';
import { UserAvatar } from '@/shared/components/UserAvatar';
import { currentMonthKey, monthLabel, shiftMonth } from '@/shared/lib/dates';
import { deleteSale, recordSale, useStore } from '@/store';

// ---------------------------------------------------------------------------
// page
// ---------------------------------------------------------------------------
export function SalesPage() {
  const { state, dispatch } = useStore();
  const { ask, dialog: confirmDialog } = useConfirm();
  const me = state.users.find(u => u.id === state.currentUserId)!;
  const isQuality = me.role === 'quality';
  const isAgent = me.role === 'agent';
  const isTL = me.role === 'team_leader';
  const isOM = me.role === 'operation_manager';

  const [month, setMonth] = useState(currentMonthKey());
  const [rowDir, setRowDir] = useState<SortDirection>('desc');     // order of agents / teams by number of sales
  const [listDir, setListDir] = useState<SortDirection>('desc');   // order of the sales list by date
  const [showForm, setShowForm] = useState(false);
  const [expanded, setExpanded] = useState<Set<string>>(new Set());   // agents whose "More details" is open
  const toggleExpanded = (id: string) => setExpanded(prev => { const n = new Set(prev); if (n.has(id)) n.delete(id); else n.add(id); return n; });

  // Everyone can see every team's sales (it keeps the floor motivated).
  const groups: TeamGroup[] = useMemo(() => {
    const build = (t: Team): TeamGroup => ({
      team: t,
      leader: state.users.find(u => u.id === t.leaderId),
      agents: state.users.filter(u => t.agentIds.includes(u.id)),
    });
    return state.teams.map(build);
  }, [state.teams, state.users]);

  // "My" scope: what the summary card and the sales list below it are about
  const scopeGroups = useMemo(() => {
    if (isAgent) return groups.map(g => ({ ...g, agents: g.agents.filter(a => a.id === me.id) })).filter(g => g.agents.length > 0);
    if (isTL) return groups.filter(g => g.team.leaderId === me.id);
    if (isOM) return groups.filter(g => g.team.managerId === me.id);
    return groups;                                      // quality: the whole company
  }, [groups, me, isAgent, isTL, isOM]);

  const scopeAgentIds = useMemo(() => new Set(scopeGroups.flatMap(g => g.agents.map(a => a.id))), [scopeGroups]);

  const allMonthSales = useMemo(() => state.sales.filter(s => s.date.startsWith(month)), [state.sales, month]);
  const monthSales = useMemo(() => allMonthSales.filter(s => scopeAgentIds.has(s.agentId)), [allMonthSales, scopeAgentIds]);

  const topAgents = useMemo(
    () => topAgentsOfMonth(state.users.filter(u => u.role === 'agent'), state.sales, state.leads, month, 5),
    [state.users, state.sales, state.leads, month],
  );

  // Lead details are private: an agent opens only their own, a team leader only their team's, the OM and Quality everyone's.
  const canSeeDetails = (agentId: string) => {
    if (isAgent) return agentId === me.id;
    if (isTL) return groups.some(g => g.team.leaderId === me.id && g.agents.some(a => a.id === agentId));
    return true;
  };

  const salesOf = (agentIds: string[]) => allMonthSales.filter(s => agentIds.includes(s.agentId));
  const targetOf = (g: TeamGroup) => teamSalesTarget({ agentIds: g.agents.map(a => a.id) });

  const totalTarget = scopeGroups.reduce((n, g) => n + targetOf(g), 0);
  const totalCount = monthSales.length;

  const dirMul = rowDir === 'desc' ? -1 : 1;
  const sortedGroups = useMemo(() => {
    const countOf = (g: TeamGroup) => allMonthSales.filter(s => g.agents.some(a => a.id === s.agentId)).length;
    return [...groups]
      .map(g => ({
        ...g,
        agents: [...g.agents].sort((a, b) =>
          dirMul * (allMonthSales.filter(s => s.agentId === a.id).length - allMonthSales.filter(s => s.agentId === b.id).length)
          || a.name.localeCompare(b.name)),
      }))
      .sort((a, b) => dirMul * (countOf(a) - countOf(b)) || a.team.name.localeCompare(b.team.name));
  }, [groups, allMonthSales, dirMul]);

  const sortedSales = useMemo(
    () => [...monthSales].sort((a, b) => (listDir === 'desc' ? -1 : 1) * (a.date.localeCompare(b.date) || a.createdAt.localeCompare(b.createdAt))),
    [monthSales, listDir],
  );

  const title = isAgent ? 'My Sales' : isTL ? `${scopeGroups[0]?.team.name ?? 'Team'} Sales` : isOM ? 'Team Sales' : 'Sales';
  const summaryLabel = isAgent ? 'My monthly target' : isTL ? 'Team monthly target' : isOM ? 'All teams monthly target' : 'Company monthly target';

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900">{title}</h2>
          <p className="text-sm text-slate-600">
            {isQuality ? 'Record every sale and follow each agent\u2019s progress' : 'Sales recorded by Quality \u00b7 everyone can see everyone\u2019s sales'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-white border border-slate-200 rounded-lg">
            <button onClick={() => setMonth(shiftMonth(month, -1))} className="w-8 h-8 flex items-center justify-center hover:bg-slate-50 rounded-l-lg" aria-label="Previous month">
              <ChevronLeft className="w-4 h-4 text-slate-600" />
            </button>
            <span className="px-3 text-sm font-medium text-slate-700 min-w-[130px] text-center">{monthLabel(month)}</span>
            <button onClick={() => setMonth(shiftMonth(month, 1))} className="w-8 h-8 flex items-center justify-center hover:bg-slate-50 rounded-r-lg" aria-label="Next month">
              <ChevronRight className="w-4 h-4 text-slate-600" />
            </button>
          </div>
          {isQuality && (
            <button
              onClick={() => setShowForm(true)}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-all flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              Record Sale
            </button>
          )}
        </div>
      </div>

      {/* Summary */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Target className="w-4 h-4 text-blue-600" />
            <span className="text-sm font-semibold text-slate-900">{summaryLabel}</span>
          </div>
          <span className="text-sm font-bold text-slate-900">{totalCount} / {totalTarget}</span>
        </div>
        <TargetProgressBar count={totalCount} target={totalTarget} />
        <div className="mt-3"><SaleTypeChips sales={monthSales} /></div>
        {!isAgent && (
          <p className="text-xs text-slate-500 mt-3">
            Each agent: {AGENT_SALES_TARGET} sales a month. A team's target is its number of agents × {AGENT_SALES_TARGET}.
          </p>
        )}
      </div>

      {/* Top 5 */}
      <TopAgentsCard ranks={topAgents} teams={state.teams} meId={me.id} monthName={monthLabel(month)} />

      {/* All teams: team leader is clearly marked, agents below can open "More details" */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-slate-900">All teams</h3>
          <SortDirectionButton dir={rowDir} onToggle={() => setRowDir(d => (d === 'desc' ? 'asc' : 'desc'))} label="Sales" />
        </div>

        {sortedGroups.length === 0 && <p className="text-sm text-slate-500">No teams to show.</p>}

        <div className="space-y-4">
          {sortedGroups.map(g => {
            const gSales = salesOf(g.agents.map(a => a.id));
            return (
              <div key={g.team.id} className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                {/* Team leader: violet header so nobody mistakes the leader for an agent */}
                <div className="p-4 bg-violet-50 border-b border-violet-100 border-l-4 border-l-violet-500">
                  <div className="flex items-center gap-3 mb-3">
                    {g.leader && (
                      <div className="rounded-full ring-2 ring-violet-400 ring-offset-2 ring-offset-violet-50"><UserAvatar user={g.leader} /></div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-semibold text-slate-900">{g.leader?.name ?? g.team.name}</span>
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-violet-700 bg-violet-100 border border-violet-200 px-2 py-0.5 rounded-full">
                          <Crown className="w-3 h-3" /> Team Leader
                        </span>
                      </div>
                      <div className="text-xs text-slate-600">{g.team.name} • {g.agents.length} agents</div>
                    </div>
                    <div className="flex items-center gap-1 text-sm font-bold text-slate-900">
                      <Trophy className="w-4 h-4 text-amber-500" /> {gSales.length}
                    </div>
                  </div>
                  <TargetProgressBar count={gSales.length} target={targetOf(g)} />
                  <div className="mt-2"><SaleTypeChips sales={gSales} /></div>
                </div>

                <div className="divide-y divide-slate-100">
                  {g.agents.map(a => {
                    const aSales = allMonthSales.filter(s => s.agentId === a.id);
                    const canOpen = canSeeDetails(a.id);
                    const open = canOpen && expanded.has(a.id);
                    const isMe = a.id === me.id;
                    return (
                      <div key={a.id} className={`p-4 flex flex-col gap-2 ${isMe ? 'bg-blue-50/40' : ''}`}>
                        <div className="flex items-center gap-3">
                          <UserAvatar user={a} size="w-8 h-8" />
                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-medium text-slate-900">
                              {a.name}
                              <span className="ml-1.5 text-[10px] font-medium text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded-full">Agent</span>
                              {isMe && <span className="ml-1 text-[10px] font-semibold text-blue-700 bg-blue-100 px-1.5 py-0.5 rounded-full">You</span>}
                            </div>
                            <div className="text-xs text-slate-600">@{a.username}</div>
                          </div>
                          {canOpen && <button
                            onClick={() => toggleExpanded(a.id)}
                            aria-expanded={open}
                            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 transition-colors shrink-0"
                          >
                            More details
                            <ChevronDown className={`w-3.5 h-3.5 transition-transform ${open ? 'rotate-180' : ''}`} />
                          </button>}
                        </div>
                        <TargetProgressBar count={aSales.length} target={AGENT_SALES_TARGET} />
                        <SaleTypeChips sales={aSales} />
                        {open && (
                          <div className="mt-1 pt-3 border-t border-slate-100">
                            <AgentSalesDetails sales={aSales} leads={state.leads} />
                          </div>
                        )}
                      </div>
                    );
                  })}
                  {g.agents.length === 0 && <div className="p-4 text-sm text-slate-500">No agents in this team.</div>}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Sales list */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-900">
            {isAgent ? 'My sales' : isTL ? 'Team sales' : isOM ? 'My teams\u2019 sales' : 'Sales'} <span className="text-slate-500 font-normal">({sortedSales.length})</span>
          </h3>
          <SortDirectionButton dir={listDir} onToggle={() => setListDir(d => (d === 'desc' ? 'asc' : 'desc'))} label="Date" />
        </div>

        {sortedSales.length === 0 ? (
          <div className="text-center py-12 text-slate-500">
            <Trophy className="w-10 h-10 mx-auto mb-2 opacity-30" />
            <p className="text-sm">No sales in {monthLabel(month)}</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {sortedSales.map(s => {
              const agent = state.users.find(u => u.id === s.agentId);
              const cfg = saleTypeConfig(s.saleType);
              const lead = state.leads.find(l => l.id === s.leadId);
              const sameLead = monthSales.filter(x => x.leadId === s.leadId).length;
              return (
                <div key={s.id} className="px-5 py-3 flex items-center gap-3 hover:bg-slate-50/40">
                  <div className="w-20 text-xs text-slate-600 shrink-0">
                    {new Date(`${s.date}T00:00:00`).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-slate-900 truncate">{s.leadName}</div>
                    <div className="text-xs text-slate-600 truncate">
                      {!isAgent && agent && <>{agent.name} · </>}
                      {lead ? `${lead.leadCode} · ${lead.campaignCode}` : ''}
                    </div>
                  </div>
                  {sameLead > 1 && <span className="text-[11px] px-2 py-0.5 rounded-full font-semibold bg-blue-50 text-blue-700 shrink-0">{sameLead} sales on this lead</span>}
                  <span className={`text-[11px] px-2 py-0.5 rounded-full font-medium shrink-0 ${cfg.chip}`}>{cfg.label}</span>
                  {isQuality && (
                    <button
                      onClick={() => ask(
                        { title: 'Delete this sale?', message: <>The {s.saleType} sale for <b>{s.leadName}</b> will be deleted. This can’t be undone.</>, confirmLabel: 'Delete', tone: 'danger' },
                        () => dispatch(deleteSale(s.id)),
                      )}
                      className="w-8 h-8 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 flex items-center justify-center shrink-0"
                      title="Delete sale"
                      aria-label="Delete sale"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {confirmDialog}

      {showForm && isQuality && (
        <RecordSaleModal
          state={state}
          me={me}
          onClose={() => setShowForm(false)}
          onSave={sale => {
            dispatch(recordSale(sale));
            // jump to the month of the sale so Quality sees it appear
            setMonth(sale.date.slice(0, 7));
            setShowForm(false);
          }}
        />
      )}
    </div>
  );
}

```

---

## `src/features/sales/components/AgentSalesDetails.tsx`

```tsx
import { saleTypeConfig } from '@/domain/sales/saleTypes';
import type { Lead, Sale } from '@/domain/types';

/** An agent's sales for the month, grouped by lead (one lead can bring more than one sale). */
export function AgentSalesDetails({ sales, leads }: { sales: Sale[]; leads: Lead[] }) {
  if (sales.length === 0) return <p className="text-xs text-slate-500">No sales this month.</p>;

  const byLead = new Map<string, Sale[]>();
  for (const s of [...sales].sort((a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt))) {
    byLead.set(s.leadId, [...(byLead.get(s.leadId) ?? []), s]);
  }

  return (
    <ul className="space-y-2">
      {[...byLead.entries()].map(([leadId, leadSales]) => {
        const lead = leads.find(l => l.id === leadId);
        return (
          <li key={leadId} className="rounded-lg border border-slate-200 bg-white px-3 py-2">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="text-sm font-medium text-slate-900 truncate">{lead?.companyName ?? leadSales[0].leadName}</div>
                {lead && <div className="text-xs text-slate-600">{lead.leadCode} · {lead.campaignCode}</div>}
              </div>
              {leadSales.length > 1 && (
                <span className="text-[11px] px-2 py-0.5 rounded-full font-semibold bg-blue-50 text-blue-700 shrink-0">
                  {leadSales.length} sales
                </span>
              )}
            </div>
            <div className="mt-1.5 flex flex-wrap gap-x-3 gap-y-1">
              {leadSales.map(s => (
                <span key={s.id} className="flex items-center gap-1.5 text-xs text-slate-600">
                  <span className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${saleTypeConfig(s.saleType).chip}`}>{saleTypeConfig(s.saleType).label}</span>
                  {new Date(`${s.date}T00:00:00`).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                </span>
              ))}
            </div>
          </li>
        );
      })}
    </ul>
  );
}

```

---

## `src/features/sales/components/RecordSaleModal.tsx`

```tsx
import { X } from 'lucide-react';
import { useMemo, useState } from 'react';
import { hasReachedPerson } from '@/domain/analytics/performanceMetrics';
import { SALE_TYPES } from '@/domain/sales/saleTypes';
import type { Sale, SaleType, User } from '@/domain/types';
import { AgentPicker } from '@/shared/components/AgentPicker';
import { LeadPicker } from '@/shared/components/LeadPicker';
import { localDateStr } from '@/shared/lib/dates';
import type { AppState } from '@/store/state/AppState';

// ---------------------------------------------------------------------------
// Quality: record a sale  (agent, lead, sale type, date)
// ---------------------------------------------------------------------------
export function RecordSaleModal({
  state, me, onClose, onSave,
}: {
  state: AppState;
  me: User;
  onClose: () => void;
  onSave: (sale: Sale) => void;
}) {
  const agents = state.users.filter(u => u.role === 'agent');
  const [agentId, setAgentId] = useState('');
  const [leadId, setLeadId] = useState('');
  const [saleType, setSaleType] = useState<SaleType | ''>('');
  const [date, setDate] = useState(localDateStr());

  const agentLeads = useMemo(() => state.leads.filter(l => l.agentId === agentId), [state.leads, agentId]);
  const pickedLead = state.leads.find(l => l.id === leadId);

  const leadName = pickedLead?.companyName ?? '';
  const neverReached = !!pickedLead && !hasReachedPerson(pickedLead);
  const canSave = !!agentId && !!pickedLead && !!saleType && !!date;

  const handleSave = () => {
    if (!canSave || !saleType) return;
    onSave({
      id: crypto.randomUUID(),
      agentId,
      leadId,
      leadName,
      saleType,
      date,
      createdBy: me.id,
      createdAt: new Date().toISOString(),
    });
  };

  const input = 'w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 bg-white';

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 animate-slide-up max-h-[90vh] overflow-y-auto scrollbar-thin">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between sticky top-0 bg-white z-10">
          <h2 className="text-lg font-bold text-slate-900">Record Sale</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center">
            <X className="w-4 h-4 text-slate-600" />
          </button>
        </div>

        <div className="px-6 py-5 space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Agent</label>
            <AgentPicker agents={agents} teams={state.teams} value={agentId} onChange={id => { setAgentId(id); setLeadId(''); }} />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Lead</label>
            {agentId ? (
              <LeadPicker leads={agentLeads} value={leadId} onChange={setLeadId} placeholder="Search this agent's leads..." />
            ) : (
              <div className="px-4 py-2.5 rounded-xl border border-dashed border-slate-200 text-sm text-slate-500">Choose an agent first</div>
            )}
            {pickedLead && (
              <div className="mt-1.5 text-xs text-slate-600">{pickedLead.leadCode} · {pickedLead.campaignCode}</div>
            )}
            {neverReached && (
              <div className="mt-2 px-3 py-2 rounded-lg bg-amber-50 border border-amber-200 text-xs text-amber-800">
                Nobody has spoken to this lead yet (no Discovery call or meeting). Check that this is the right lead before saving.
              </div>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Sale type</label>
            <select value={saleType} onChange={e => setSaleType(e.target.value as SaleType | '')} className={input}>
              <option value="">Select sale type...</option>
              {SALE_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Sale date</label>
            <input type="date" value={date} max={localDateStr()} onChange={e => setDate(e.target.value)} className={input} />
          </div>
        </div>

        <div className="px-6 py-4 border-t border-slate-100 flex justify-end gap-2 sticky bottom-0 bg-white">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100">Cancel</button>
          <button
            onClick={handleSave}
            disabled={!canSave}
            className="px-4 py-2 rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-40 transition-all"
          >
            Save Sale
          </button>
        </div>
      </div>
    </div>
  );
}

```

---

## `src/features/sales/components/SaleTypeChips.tsx`

```tsx
import { SALE_TYPES, countByType } from '@/domain/sales/saleTypes';
import type { Sale } from '@/domain/types';

export function SaleTypeChips({ sales }: { sales: Sale[] }) {
  const counts = countByType(sales);
  return (
    <div className="flex flex-wrap gap-1.5">
      {SALE_TYPES.map(t => (
        <span
          key={t.value}
          className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${counts[t.value] > 0 ? t.chip : 'bg-slate-50 text-slate-500'}`}
        >
          {t.label} {counts[t.value]}
        </span>
      ))}
    </div>
  );
}

```

---

## `src/features/sales/components/SortDirectionButton.tsx`

```tsx
import { ArrowDownWideNarrow, ArrowUpNarrowWide } from 'lucide-react';
import type { SortDirection } from '@/features/sales/salesTypes';

export function SortDirectionButton({ dir, onToggle, label }: { dir: SortDirection; onToggle: () => void; label: string }) {
  const Icon = dir === 'desc' ? ArrowDownWideNarrow : ArrowUpNarrowWide;
  return (
    <button
      onClick={onToggle}
      className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 transition-colors"
      title="Switch between descending and ascending"
    >
      <Icon className="w-3.5 h-3.5" />
      {label}: {dir === 'desc' ? 'Descending' : 'Ascending'}
    </button>
  );
}

```

---

## `src/features/sales/components/TargetProgressBar.tsx`

```tsx

// ---------------------------------------------------------------------------
// small building blocks
// ---------------------------------------------------------------------------
export function TargetProgressBar({ count, target }: { count: number; target: number }) {
  const pct = target > 0 ? Math.min((count / target) * 100, 100) : 0;
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 bg-slate-200 rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all ${pct >= 100 ? 'bg-emerald-500' : 'bg-blue-500'}`}
          style={{ width: `${Math.max(pct, count > 0 ? 2 : 0)}%` }}
        />
      </div>
      <span className="text-xs font-semibold text-slate-700 shrink-0 w-24 text-right">
        {count}/{target} ({Math.round(pct)}%)
      </span>
    </div>
  );
}

```

---

## `src/features/sales/components/TopAgentsCard.tsx`

```tsx
import { Trophy } from 'lucide-react';
import type { AgentRank } from '@/domain/sales/salesLeaderboard';
import type { Team } from '@/domain/types';
import { UserAvatar } from '@/shared/components/UserAvatar';

const PODIUM = [
  'bg-amber-100 text-amber-700 ring-amber-300',
  'bg-slate-100 text-slate-600 ring-slate-300',
  'bg-amber-100 text-amber-700 ring-amber-300',
];

/** Top 5 agents of the month: only the number of sales is shown (not the type). */
export function TopAgentsCard({ ranks, teams, meId, monthName }: { ranks: AgentRank[]; teams: Team[]; meId: string; monthName: string }) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-2">
        <Trophy className="w-4 h-4 text-amber-500" />
        <h3 className="text-sm font-semibold text-slate-900">Top 5 agents</h3>
        <span className="text-xs text-slate-500">· {monthName}</span>
      </div>

      {ranks.length === 0 ? (
        <p className="px-5 py-8 text-sm text-slate-500 text-center">No sales yet this month</p>
      ) : (
        <ol className="divide-y divide-slate-100">
          {ranks.map((r, i) => {
            const team = teams.find(t => t.agentIds.includes(r.agent.id));
            const isMe = r.agent.id === meId;
            return (
              <li key={r.agent.id} className={`px-5 py-3 flex items-center gap-3 ${isMe ? 'bg-blue-50/60' : ''}`}>
                <span className={`w-7 h-7 rounded-full ring-1 flex items-center justify-center text-xs font-bold shrink-0 ${PODIUM[i] ?? 'bg-slate-50 text-slate-500 ring-slate-200'}`}>
                  {i + 1}
                </span>
                <UserAvatar user={r.agent} size="w-8 h-8" />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-slate-900 truncate">
                    {r.agent.name}
                    {isMe && <span className="ml-1.5 text-[10px] font-semibold text-blue-700 bg-blue-100 px-1.5 py-0.5 rounded-full">You</span>}
                  </div>
                  {team && <div className="text-xs text-slate-600 truncate">{team.name}</div>}
                </div>
                <div className="text-sm font-bold text-slate-900 shrink-0">
                  {r.sales} <span className="text-xs font-normal text-slate-500">{r.sales === 1 ? 'sale' : 'sales'}</span>
                </div>
              </li>
            );
          })}
        </ol>
      )}
    </div>
  );
}

```

---

## `src/features/sales/salesTypes.ts`

```ts
/** Types used only by the Sales screen. */
import type { Team, User } from '@/domain/types';

export type SortDirection = 'desc' | 'asc';

export interface TeamGroup { team: Team; leader?: User; agents: User[] }

```

---

## `src/features/take-leads/ClaimResultRow.tsx`

```tsx
import { AlertCircle, CheckCircle2 } from 'lucide-react';
import { CLAIM_STATUS_TEXT } from '@/domain/lead/leadPool';
import type { ClaimResult } from '@/domain/lead/leadPool';

/** One line of the result list: the ID and what happened to it. */
export function ClaimResultRow({ r }: { r: ClaimResult }) {
  const ok = r.status === 'ready';
  const text = r.status === 'taken' ? `Held by ${r.holderName}` : CLAIM_STATUS_TEXT[r.status];
  return (
    <li className={`px-3 py-1.5 flex items-center gap-2 ${ok ? 'text-emerald-700' : 'text-rose-700'}`}>
      {ok ? <CheckCircle2 className="w-3.5 h-3.5 shrink-0" /> : <AlertCircle className="w-3.5 h-3.5 shrink-0" />}
      <span className="font-mono">{r.code}</span>
      <span className="ml-auto text-right">{ok ? 'Added' : text}</span>
    </li>
  );
}

```

---

## `src/features/take-leads/TakeLeadsModal.tsx`

```tsx
import { Download, Search, XCircle } from 'lucide-react';
import { useMemo, useState } from 'react';
import { normalizeLeadCode } from '@/domain/lead/leadCode';
import { isInPool, planTakeFromPool, splitLeadIds } from '@/domain/lead/leadPool';
import type { ClaimResult } from '@/domain/lead/leadPool';
import type { Lead, User, Workflow } from '@/domain/types';
import { campaignLabel } from '@/domain/workflow/campaignLabel';
import { ClaimResultRow } from '@/features/take-leads/ClaimResultRow';

/**
 * How an agent gets leads. Agents do not create leads - the Admin does. Here the agent either
 *  1) types ONE full lead ID in the search box: the lead appears only when the ID matches exactly (the pool is never listed), or
 *  2) types / pastes lead IDs one under the other and all of them are taken at once.
 * Every ID gets a result: added, not found, or held by another agent (with the name).
 */
export function TakeLeadsModal({
  leads, users, workflows, me, onTake, onClose,
}: {
  leads: Lead[];
  users: User[];
  workflows: Workflow[];
  me: User;
  onTake: (leadIds: string[]) => void;
  onClose: () => void;
}) {
  const [tab, setTab] = useState<'search' | 'paste'>('search');
  const [query, setQuery] = useState('');
  const [picked, setPicked] = useState<Set<string>>(new Set());
  const [text, setText] = useState('');
  const [report, setReport] = useState<ClaimResult[] | null>(null);

  const nameOf = (id: string) => users.find(u => u.id === id)?.name ?? '';

  // ---- search tab: the agent must type the FULL id. The pool is never listed, so nothing shows until the id matches exactly ----
  // (upper / lower case, dashes and spaces do not matter: "ld-013" finds LD013, but "LD01" never finds LD013)
  const found = useMemo(() => {
    const q = normalizeLeadCode(query);
    if (!q) return { lead: null as Lead | null, heldBy: null as { code: string; name: string } | null };
    const lead = leads.find(l => isInPool(l) && normalizeLeadCode(l.leadCode) === q) ?? null;
    if (lead) return { lead, heldBy: null };
    const h = leads.find(x => !isInPool(x) && normalizeLeadCode(x.leadCode) === q);
    return { lead: null, heldBy: h ? { code: h.leadCode, name: h.agentId === me.id ? 'you' : nameOf(h.agentId) || 'another agent' } : null };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [leads, query, me.id, users]);
  const typed = normalizeLeadCode(query).length > 0;
  const pickedLeads = useMemo(() => leads.filter(l => picked.has(l.id) && isInPool(l)), [leads, picked]);

  const togglePick = (id: string) => setPicked(p => { const n = new Set(p); if (n.has(id)) n.delete(id); else n.add(id); return n; });

  // ---- paste tab: live check of every ID ----
  const plan = useMemo(
    () => planTakeFromPool(splitLeadIds(text), leads, me.id, nameOf),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [text, leads, me.id, users],
  );
  const ready = plan.filter(r => r.status === 'ready');
  const problems = plan.filter(r => r.status !== 'ready');

  const takePicked = () => {
    const ids = pickedLeads.map(l => l.id);
    if (!ids.length) return;
    onTake(ids);
    setReport(planTakeFromPool(ids.map(id => ({ line: 0, code: leads.find(l => l.id === id)!.leadCode })), leads, me.id, nameOf));
    setPicked(new Set());
  };
  const takePasted = () => {
    if (!ready.length) return;
    onTake(ready.map(r => r.leadId!));
    setReport(plan);
    setText('');
  };

  const tabClass = (t: typeof tab) =>
    `px-4 py-2 text-sm font-medium border-b-2 -mb-px ${tab === t ? 'border-blue-600 text-blue-700' : 'border-transparent text-slate-600 hover:text-slate-700'}`;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg mx-4 animate-slide-up max-h-[90vh] flex flex-col">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Take Leads</h2>
            <p className="text-sm text-slate-600">Get leads from the shared pool into your work queue</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center" aria-label="Close">
            <XCircle className="w-4 h-4 text-slate-600" />
          </button>
        </div>

        <div className="px-6 border-b border-slate-100 flex gap-2">
          <button className={tabClass('search')} onClick={() => { setTab('search'); setReport(null); }}>Search by exact ID</button>
          <button className={tabClass('paste')} onClick={() => { setTab('paste'); setReport(null); }}>Type / paste IDs</button>
        </div>

        <div className="px-6 py-4 overflow-y-auto scrollbar-thin flex-1 space-y-3">
          {report && (
            <div className="rounded-lg border border-slate-200 text-xs" aria-live="polite">
              <div className="px-3 py-2 bg-slate-50 font-medium text-slate-700 rounded-t-lg">
                {report.filter(r => r.status === 'ready').length} added
                {report.some(r => r.status !== 'ready') && ` · ${report.filter(r => r.status !== 'ready').length} not added`}
              </div>
              <ul className="max-h-44 overflow-y-auto scrollbar-thin divide-y divide-slate-100">
                {report.map((r, i) => <ClaimResultRow key={`${r.code}-${i}`} r={r} />)}
              </ul>
            </div>
          )}

          {tab === 'search' && (
            <>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  value={query} onChange={e => setQuery(e.target.value)} autoFocus
                  placeholder="Type the full lead ID, e.g. LD013"
                  className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              {!typed && <p className="text-xs text-slate-600 bg-slate-50 rounded-lg p-2">Leads are not listed. Write the exact ID of the lead you want and it will show up here.</p>}

              {found.lead && (
                <label className="flex items-center gap-3 px-4 py-2.5 rounded-xl border border-slate-200 cursor-pointer hover:bg-slate-50">
                  <input type="checkbox" checked={picked.has(found.lead.id)} onChange={() => togglePick(found.lead!.id)} />
                  <span className="font-mono text-xs bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded shrink-0">{found.lead.leadCode}</span>
                  <span className="truncate text-sm text-slate-900">{found.lead.companyName}</span>
                  <span className="ml-auto text-xs text-slate-500 shrink-0">{campaignLabel(workflows, found.lead.campaignCode)}</span>
                </label>
              )}

              {found.heldBy && (
                <p className="text-xs text-amber-700 bg-amber-50 rounded-lg px-3 py-2">
                  <span className="font-mono">{found.heldBy.code}</span> exists but is held by {found.heldBy.name}.
                </p>
              )}

              {typed && !found.lead && !found.heldBy && (
                <p className="text-sm text-slate-500 text-center py-3">No lead with this exact ID in the pool</p>
              )}

              {pickedLeads.length > 0 && (
                <div className="rounded-xl border border-blue-100 bg-blue-50/40">
                  <div className="px-3 py-2 text-xs font-medium text-blue-800">Selected ({pickedLeads.length})</div>
                  <ul className="divide-y divide-blue-100/70 max-h-40 overflow-y-auto scrollbar-thin">
                    {pickedLeads.map(l => (
                      <li key={l.id} className="flex items-center gap-2 px-3 py-1.5 text-sm">
                        <span className="font-mono text-xs bg-white text-slate-600 px-1.5 py-0.5 rounded shrink-0">{l.leadCode}</span>
                        <span className="truncate text-slate-800">{l.companyName}</span>
                        <button onClick={() => togglePick(l.id)} className="ml-auto text-xs text-slate-500 hover:text-rose-600 shrink-0" aria-label={`Unselect ${l.leadCode}`}>Remove</button>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </>
          )}

          {tab === 'paste' && (
            <>
              <p className="text-xs text-slate-600 bg-slate-50 rounded-lg p-2">
                Write or paste the lead IDs one under the other. All of them are added automatically - no need to pick each one.
              </p>
              <textarea
                value={text} onChange={e => { setText(e.target.value); setReport(null); }}
                rows={7} autoFocus
                placeholder={'LD012\nLD013\nLD014'}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-mono focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 resize-none"
              />
              {plan.length > 0 && (
                <div className="text-xs space-y-1.5" aria-live="polite">
                  <p>
                    <span className="font-medium text-emerald-700">{ready.length} ready</span>
                    {problems.length > 0 && <span className="font-medium text-rose-600"> · {problems.length} with a problem</span>}
                  </p>
                  {problems.length > 0 && (
                    <ul className="max-h-32 overflow-y-auto scrollbar-thin rounded-lg bg-rose-50 border border-rose-100 divide-y divide-rose-100">
                      {problems.slice(0, 50).map((r, i) => <ClaimResultRow key={`${r.code}-${i}`} r={r} />)}
                      {problems.length > 50 && <li className="px-3 py-1.5 text-rose-600">…and {problems.length - 50} more</li>}
                    </ul>
                  )}
                </div>
              )}
            </>
          )}
        </div>

        <div className="px-6 py-4 border-t border-slate-100 flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100">Close</button>
          {tab === 'search' ? (
            <button onClick={takePicked} disabled={pickedLeads.length === 0}
              className="px-4 py-2 rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-40 flex items-center gap-1.5">
              <Download className="w-3.5 h-3.5" />
              {pickedLeads.length > 0 ? `Take ${pickedLeads.length} lead${pickedLeads.length === 1 ? '' : 's'}` : 'Take leads'}
            </button>
          ) : (
            <button onClick={takePasted} disabled={ready.length === 0}
              className="px-4 py-2 rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-40 flex items-center gap-1.5">
              <Download className="w-3.5 h-3.5" />
              {ready.length > 0 ? `Take ${ready.length} lead${ready.length === 1 ? '' : 's'}` : 'Take leads'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

```

---

## `src/features/tasks/TasksPage.tsx`

```tsx
import { AlertCircle, Check, CheckCircle2, Circle, Clock, Plus, User } from 'lucide-react';
import { useState } from 'react';
import { CreateTaskModal } from '@/features/tasks/components/CreateTaskModal';
import { createTask, toggleTaskCompletion, useStore } from '@/store';

export function TasksPage() {
  const { state, dispatch } = useStore();
  const currentUser = state.users.find(u => u.id === state.currentUserId)!;
  const [showCreate, setShowCreate] = useState(false);

  const canCreate = currentUser.role === 'team_leader' || currentUser.role === 'operation_manager';
  const myTeam = state.teams.find(t => t.id === currentUser.teamId);

  const relevantTasks = state.tasks.filter(t => {
    if (currentUser.role === 'operation_manager') return t.authorId === currentUser.id || t.assignedTo.includes(currentUser.id);
    if (currentUser.role === 'team_leader') return t.assignedTo.includes(currentUser.id) || (t.authorId === currentUser.id);
    if (currentUser.role === 'agent') return t.assignedTo.includes(currentUser.id);
    return false;
  });

  const assignees = currentUser.role === 'operation_manager'
    ? state.users.filter(u => u.role === 'team_leader')
    : state.users.filter(u => myTeam?.agentIds.includes(u.id));

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-bold text-slate-900">Tasks</h2>
          <p className="text-sm text-slate-600">
            {currentUser.role === 'agent' ? 'Your assigned tasks' :
             currentUser.role === 'operation_manager' ? 'Assign tasks to team leaders' :
             'Assign tasks to your team agents'}
          </p>
        </div>
        {canCreate && (
          <button
            onClick={() => setShowCreate(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-all flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            New Task
          </button>
        )}
      </div>

      <div className="space-y-4">
        {relevantTasks.length === 0 && (
          <div className="text-center py-12 text-slate-500">
            <CheckCircle2 className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No tasks yet</p>
          </div>
        )}

        {relevantTasks.map(task => {
          const isCompleted = task.completedBy.includes(currentUser.id);
          const isOverdue = new Date(task.deadline) < new Date() && !isCompleted;
          const completedCount = task.completedBy.filter(id => task.assignedTo.includes(id)).length;
          const canToggle = task.assignedTo.includes(currentUser.id);

          return (
            <div key={task.id} className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
              <div className="flex items-start gap-3">
                {canToggle ? (
                  <button
                    onClick={() => dispatch(toggleTaskCompletion({ taskId: task.id, userId: currentUser.id }))}
                    className="mt-0.5 shrink-0"
                  >
                    {isCompleted ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    ) : (
                      <Circle className="w-5 h-5 text-slate-300 hover:text-slate-500" />
                    )}
                  </button>
                ) : (
                  <div className="mt-0.5 shrink-0">
                    <CheckCircle2 className={`w-5 h-5 ${completedCount === task.assignedTo.length ? 'text-emerald-600' : 'text-slate-300'}`} />
                  </div>
                )}

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className={`font-semibold text-sm ${isCompleted ? 'text-slate-500 line-through' : 'text-slate-900'}`}>
                      {task.title}
                    </h3>
                    {isOverdue && (
                      <span className="text-xs px-2 py-0.5 bg-rose-100 text-rose-700 rounded-full font-medium flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        Overdue
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-slate-600 mb-3">{task.description}</p>

                  <div className="flex items-center gap-4 text-xs text-slate-600">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      Due: {new Date(task.deadline).toLocaleDateString()}
                    </span>
                    <span className="flex items-center gap-1">
                      <User className="w-3 h-3" />
                      {task.authorName}
                    </span>
                    <span>
                      {completedCount}/{task.assignedTo.length} completed
                    </span>
                  </div>

                  {currentUser.role !== 'agent' && (
                    <div className="mt-3 border-t border-slate-100 pt-3">
                      <div className="flex flex-wrap gap-1.5">
                        {task.assignedTo.map(id => {
                          const person = state.users.find(u => u.id === id);
                          const done = task.completedBy.includes(id);
                          return (
                            <div
                              key={id}
                              className={`flex items-center gap-1.5 px-2 py-1 rounded-lg text-xs ${
                                done ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-50 text-slate-600'
                              }`}
                            >
                              {done ? <Check className="w-3 h-3" /> : <Circle className="w-3 h-3" />}
                              {person?.name}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {showCreate && (
        <CreateTaskModal
          currentUser={currentUser}
          assignees={assignees}
          onClose={() => setShowCreate(false)}
          onCreate={(task) => {
            dispatch(createTask(task));
            setShowCreate(false);
          }}
        />
      )}
    </div>
  );
}

```

---

## `src/features/tasks/components/CreateTaskModal.tsx`

```tsx
import { Send, X } from 'lucide-react';
import { useState } from 'react';
import type { Task, User } from '@/domain/types';

export function CreateTaskModal({
  currentUser, assignees, onClose, onCreate,
}: {
  currentUser: User;
  assignees: User[];
  onClose: () => void;
  onCreate: (task: Task) => void;
}) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [deadline, setDeadline] = useState('');
  const [assignAll, setAssignAll] = useState(true);
  const [selectedAssignees, setSelectedAssignees] = useState<string[]>([]);

  const assigneeLabel = currentUser.role === 'operation_manager' ? 'Team Leaders' : 'Agents';

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 animate-slide-up">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900">New Task</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center">
            <X className="w-4 h-4 text-slate-600" />
          </button>
        </div>
        <div className="px-6 py-5 space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Title</label>
            <input
              type="text" value={title} onChange={e => setTitle(e.target.value)}
              placeholder="Task title..."
              className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Description</label>
            <textarea
              value={description} onChange={e => setDescription(e.target.value)}
              placeholder="Task details..." rows={3}
              className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 resize-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Deadline</label>
            <input
              type="date" value={deadline} onChange={e => setDeadline(e.target.value)}
              className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Assign To</label>
            <div className="flex gap-2 mb-2">
              <button
                onClick={() => { setAssignAll(true); setSelectedAssignees([]); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium ${assignAll ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}
              >
                All {assigneeLabel}
              </button>
              <button
                onClick={() => setAssignAll(false)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium ${!assignAll ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}
              >
                Select Specific
              </button>
            </div>
            {!assignAll && (
              <div className="space-y-1.5 max-h-40 overflow-y-auto scrollbar-thin">
                {assignees.map(a => (
                  <label key={a.id} className="flex items-center gap-2 px-3 py-1.5 rounded-lg hover:bg-slate-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={selectedAssignees.includes(a.id)}
                      onChange={e => {
                        if (e.target.checked) setSelectedAssignees([...selectedAssignees, a.id]);
                        else setSelectedAssignees(selectedAssignees.filter(id => id !== a.id));
                      }}
                      className="rounded"
                    />
                    <span className="text-sm text-slate-700">{a.name}</span>
                  </label>
                ))}
              </div>
            )}
          </div>
        </div>
        <div className="px-6 py-4 border-t border-slate-100 flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100">Cancel</button>
          <button
            onClick={() => {
              if (!title.trim()) return;
              const assignedTo = assignAll ? assignees.map(a => a.id) : selectedAssignees;
              const task: Task = {
                id: crypto.randomUUID(),
                authorId: currentUser.id, authorName: currentUser.name,
                title, description,
                createdAt: new Date().toISOString(),
                deadline: deadline || new Date(Date.now() + 7 * 86400000).toISOString(),
                assignedTo, completedBy: [],
              };
              onCreate(task);
              setTitle(''); setDescription(''); setDeadline('');
            }}
            disabled={!title.trim() || (!assignAll && selectedAssignees.length === 0)}
            className="px-4 py-2 rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-40 transition-all flex items-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5" />
            Create Task
          </button>
        </div>
      </div>
    </div>
  );
}

```

---

## `src/features/team-updates/TeamUpdatesPage.tsx`

```tsx
import { Bell, Check, CheckCircle2, Clock, Send, UserCheck } from 'lucide-react';
import { useState } from 'react';
import type { TeamUpdate } from '@/domain/types';
import { CreateUpdateModal } from '@/features/team-updates/components/CreateUpdateModal';
import { acknowledgeTeamUpdate, addNotification, postTeamUpdate, useStore } from '@/store';

export function TeamUpdatesPage() {
  const { state, dispatch } = useStore();
  const currentUser = state.users.find(u => u.id === state.currentUserId)!;
  const [showCreate, setShowCreate] = useState(false);

  const canCreate = currentUser.role === 'team_leader' || currentUser.role === 'operation_manager';

  const relevantUpdates = state.updates.filter(u => {
    if (currentUser.role === 'agent') {
      return u.audience === 'all' || (u.audience === 'specific_team' && u.teamId === currentUser.teamId);
    }
    if (currentUser.role === 'team_leader') {
      return u.audience === 'all' || u.audience === 'team_leaders' || (u.audience === 'specific_team' && u.teamId === currentUser.teamId);
    }
    return true;
  });

  const getUpdateRecipients = (update: TeamUpdate) => {
    if (update.audience === 'all') return state.users.filter(u => u.role !== 'operation_manager' && u.role !== 'admin');
    if (update.audience === 'team_leaders') return state.users.filter(u => u.role === 'team_leader');
    if (update.audience === 'specific_team') {
      const team = state.teams.find(t => t.id === update.teamId);
      return state.users.filter(u => team?.agentIds.includes(u.id));
    }
    return [];
  };

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-bold text-slate-900">Team Updates</h2>
          <p className="text-sm text-slate-600">
            {currentUser.role === 'agent' ? 'Updates from your team leader and management' :
             currentUser.role === 'operation_manager' ? 'Send updates to team leaders or everyone' :
             'Send updates to your team agents'}
          </p>
        </div>
        {canCreate && (
          <button
            onClick={() => setShowCreate(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-all flex items-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5" />
            New Update
          </button>
        )}
      </div>

      <div className="space-y-4">
        {relevantUpdates.length === 0 && (
          <div className="text-center py-12 text-slate-500">
            <Bell className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No updates yet</p>
          </div>
        )}

        {relevantUpdates.map(update => {
          const author = state.users.find(u => u.id === update.authorId);
          const acknowledged = update.acknowledgedBy.includes(currentUser.id);
          const recipients = getUpdateRecipients(update);
          const ackRecipients = recipients.filter(r => update.acknowledgedBy.includes(r.id));
          const pendingRecipients = recipients.filter(r => !update.acknowledgedBy.includes(r.id));
          const canAck = recipients.some(r => r.id === currentUser.id);

          const audienceLabel = update.audience === 'all' ? 'Everyone' :
            update.audience === 'team_leaders' ? 'All Team Leaders' :
            state.teams.find(t => t.id === update.teamId)?.name || 'Team';

          return (
            <div key={update.id} className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-5">
                <div className="flex items-start gap-3 mb-3">
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-white text-sm font-semibold shrink-0"
                    style={{ backgroundColor: author?.color || '#64748b' }}
                  >
                    {author?.initials || '?'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm text-slate-900">{update.authorName}</span>
                      <span className="text-xs text-slate-500">
                        {new Date(update.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <h3 className="font-semibold text-slate-900 mt-0.5">{update.title}</h3>
                    <span className="inline-block mt-1 text-xs px-2 py-0.5 bg-slate-100 text-slate-600 rounded-full">
                      To: {audienceLabel}
                    </span>
                  </div>
                  {!acknowledged && canAck && (
                    <span className="w-2 h-2 bg-rose-500 rounded-full animate-pulse-ring shrink-0 mt-2" />
                  )}
                </div>

                <p className="text-sm text-slate-600 leading-relaxed mb-4">{update.content}</p>

                {currentUser.role !== 'agent' && (
                <div className="border-t border-slate-100 pt-3">
                  <div className="flex items-center gap-2 mb-2">
                    <UserCheck className="w-3.5 h-3.5 text-slate-500" />
                    <span className="text-xs font-medium text-slate-600">Acknowledgments</span>
                    <span className="text-xs text-slate-500">
                      {ackRecipients.length}/{recipients.length}
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    {ackRecipients.map(r => (
                      <div key={r.id} className="flex items-center gap-1.5 px-2 py-1 bg-emerald-50 rounded-lg">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        <span className="text-xs text-emerald-700 font-medium">{r.name}</span>
                      </div>
                    ))}
                    {pendingRecipients.map(r => (
                      <div key={r.id} className="flex items-center gap-1.5 px-2 py-1 bg-slate-50 rounded-lg">
                        <Clock className="w-3 h-3 text-slate-500" />
                        <span className="text-xs text-slate-600">{r.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
                )}

                {canAck && (
                    <button
                      onClick={() => dispatch(acknowledgeTeamUpdate({ updateId: update.id, userId: currentUser.id }))}
                      disabled={acknowledged}
                      className={`mt-3 px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-1.5 ${
                        acknowledged
                          ? 'bg-emerald-100 text-emerald-700 cursor-default'
                          : 'bg-slate-900 text-white hover:bg-slate-800'
                      }`}
                    >
                      <Check className="w-3.5 h-3.5" />
                      {acknowledged ? 'Acknowledged' : 'Acknowledge'}
                    </button>
                  )}
              </div>
            </div>
          );
        })}
      </div>

      {showCreate && (
        <CreateUpdateModal
          currentUser={currentUser}
          state={state}
          onClose={() => setShowCreate(false)}
          onCreate={(update) => {
            dispatch(postTeamUpdate(update));
            dispatch(addNotification({
              id: crypto.randomUUID(),
              type: 'update',
              title: 'New update',
              message: `${currentUser.name} posted: ${update.title}`,
              timestamp: new Date().toISOString(),
              read: false,
            }));
            setShowCreate(false);
          }}
        />
      )}
    </div>
  );
}

```

---

## `src/features/team-updates/components/CreateUpdateModal.tsx`

```tsx
import { AlertCircle, Users as UsersIcon, X } from 'lucide-react';
import { useState } from 'react';
import type { TeamUpdate, UpdateAudience, User } from '@/domain/types';
import type { AppState } from '@/store/state/AppState';

export function CreateUpdateModal({
  currentUser, state, onClose, onCreate,
}: {
  currentUser: User;
  state: AppState;
  onClose: () => void;
  onCreate: (update: TeamUpdate) => void;
}) {
  const isOM = currentUser.role === 'operation_manager';
  const myTeam = state.teams.find(t => t.id === currentUser.teamId);

  const [audience, setAudience] = useState<UpdateAudience>(isOM ? 'all' : 'specific_team');
  const [selectedTeamId, setSelectedTeamId] = useState(myTeam?.id || state.teams[0]?.id || '');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  const audienceOptions: { value: UpdateAudience; label: string; show: boolean }[] = [
    { value: 'all', label: 'Everyone (all TLs + all agents)', show: isOM },
    { value: 'team_leaders', label: 'All Team Leaders only', show: isOM },
    { value: 'specific_team', label: isOM ? 'Specific Team' : 'My Team Agents', show: true },
  ];

  const availableTeams = isOM ? state.teams : state.teams.filter(t => t.id === currentUser.teamId);

  const handleCreate = () => {
    if (!title.trim() || !content.trim()) return;
    const update: TeamUpdate = {
      id: crypto.randomUUID(),
      audience,
      teamId: audience === 'specific_team' ? selectedTeamId : null,
      authorId: currentUser.id,
      authorName: currentUser.name,
      title,
      content,
      createdAt: new Date().toISOString(),
      acknowledgedBy: [],
    };
    onCreate(update);
    setTitle(''); setContent('');
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 animate-slide-up">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900">New Update</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center">
            <X className="w-4 h-4 text-slate-600" />
          </button>
        </div>
        <div className="px-6 py-5 space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Audience</label>
            <div className="space-y-2">
              {audienceOptions.filter(o => o.show).map(opt => (
                <button
                  key={opt.value}
                  onClick={() => setAudience(opt.value)}
                  className={`w-full flex items-center gap-2 p-3 rounded-xl border-2 text-left transition-all ${
                    audience === opt.value ? 'border-blue-500 bg-blue-50' : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <UsersIcon className={`w-4 h-4 ${audience === opt.value ? 'text-blue-600' : 'text-slate-500'}`} />
                  <span className="text-sm text-slate-700">{opt.label}</span>
                </button>
              ))}
            </div>
          </div>

          {audience === 'specific_team' && availableTeams.length > 1 && (
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Team</label>
              <select
                value={selectedTeamId}
                onChange={e => setSelectedTeamId(e.target.value)}
                className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 bg-white"
              >
                {availableTeams.map(t => (
                  <option key={t.id} value={t.id}>{t.name}</option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Title</label>
            <input
              type="text"
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="Update title..."
              className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Content</label>
            <textarea
              value={content}
              onChange={e => setContent(e.target.value)}
              placeholder="Write your update..."
              rows={5}
              className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 resize-none"
            />
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <AlertCircle className="w-3.5 h-3.5" />
            {audience === 'all' ? 'All team leaders and agents will see this' :
             audience === 'team_leaders' ? 'Only team leaders will see this' :
             'Agents in the selected team will see this'}
          </div>
        </div>
        <div className="px-6 py-4 border-t border-slate-100 flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100">Cancel</button>
          <button
            onClick={handleCreate}
            disabled={!title.trim() || !content.trim()}
            className="px-4 py-2 rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-40 transition-all"
          >
            Send Update
          </button>
        </div>
      </div>
    </div>
  );
}

```

---

## `src/features/teams/TeamsPage.tsx`

```tsx
import { ArrowRightLeft, Crown, Shield } from 'lucide-react';
import { useState } from 'react';
import type { Team, User } from '@/domain/types';
import { MoveAgentModal } from '@/features/teams/components/MoveAgentModal';
import { UserAvatar } from '@/shared/components/UserAvatar';
import { moveAgentToTeam, useStore } from '@/store';

/** Everybody sees who is in which team: Operation Manager on top, then each Team Leader with their agents. */
export function TeamsPage() {
  const { state, dispatch } = useStore();
  const me = state.users.find(u => u.id === state.currentUserId)!;
  const [moving, setMoving] = useState<User | null>(null);

  const userOf = (id: string) => state.users.find(u => u.id === id);
  const managers = state.users.filter(u => u.role === 'operation_manager');
  const teamOf = (agentId: string) => state.teams.find(t => t.agentIds.includes(agentId));
  const unassigned = state.users.filter(u => u.role === 'agent' && !teamOf(u.id));
  const canMove = (agent: User) => {
    if (me.role !== 'operation_manager') return false;
    const t = teamOf(agent.id);
    return !t || t.managerId === me.id;
  };
  const myTeams = state.teams.filter(t => t.managerId === me.id);

  const person = (u: User, extra?: React.ReactNode) => (
    <div className="flex items-center gap-3 min-w-0">
      <UserAvatar user={u} />
      <div className="min-w-0">
        <div className="text-sm font-medium text-slate-900 truncate">{u.name}{u.id === me.id && <span className="ml-1.5 text-xs font-normal text-blue-600">(you)</span>}</div>
        <div className="text-xs text-slate-600 truncate">@{u.username}</div>
      </div>
      {extra}
    </div>
  );

  const agentRow = (agent: User) => (
    <li key={agent.id} className="flex items-center justify-between gap-2 px-4 py-2.5">
      {person(agent)}
      {canMove(agent) && (
        <button
          onClick={() => setMoving(agent)}
          className="shrink-0 px-2.5 py-1.5 rounded-lg text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 flex items-center gap-1.5"
        >
          <ArrowRightLeft className="w-3.5 h-3.5" />Move
        </button>
      )}
    </li>
  );

  const teamCard = (team: Team) => {
    const leader = userOf(team.leaderId);
    const agents = team.agentIds.map(userOf).filter((u): u is User => !!u);
    return (
      <div key={team.id} className="flex flex-col items-stretch">
        <div className="mx-auto w-px h-5 bg-slate-300" />
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="px-4 py-3 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">{team.name}</h3>
            <span className="text-xs text-slate-600">{agents.length} agent{agents.length === 1 ? '' : 's'}</span>
          </div>
          {leader && (
            <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between gap-2">
              {person(leader)}
              <span className="shrink-0 text-[11px] font-semibold text-violet-700 bg-violet-50 px-2 py-0.5 rounded-full flex items-center gap-1"><Shield className="w-3 h-3" />Team Leader</span>
            </div>
          )}
          <ul className="divide-y divide-slate-100">
            {agents.map(agentRow)}
            {agents.length === 0 && <li className="px-4 py-4 text-sm text-slate-500">No agents in this team</li>}
          </ul>
        </div>
      </div>
    );
  };

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-8">
      <div>
        <h2 className="text-lg font-bold text-slate-900 mb-1">Teams</h2>
        <p className="text-sm text-slate-600">
          {state.teams.length} teams · {state.users.filter(u => u.role === 'agent').length} agents
          {me.role === 'operation_manager' && ' · use Move to put an agent in another team'}
        </p>
      </div>

      {managers.map(m => {
        const teams = state.teams.filter(t => t.managerId === m.id);
        return (
          <section key={m.id}>
            <div className="mx-auto max-w-xs bg-white rounded-xl border-2 border-blue-200 shadow-sm px-4 py-3 flex items-center justify-between gap-2">
              {person(m)}
              <span className="shrink-0 text-[11px] font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full flex items-center gap-1"><Crown className="w-3 h-3" />Manager</span>
            </div>
            {teams.length > 0 && (
              <>
                <div className="mx-auto w-px h-5 bg-slate-300" />
                <div className="border-t border-slate-300 mx-6 sm:mx-16" />
                <div className="grid gap-x-4 sm:grid-cols-2 lg:grid-cols-3 -mt-px">{teams.map(teamCard)}</div>
              </>
            )}
          </section>
        );
      })}

      {unassigned.length > 0 && (
        <section className="bg-white rounded-xl border border-dashed border-slate-300 overflow-hidden">
          <div className="px-4 py-3 bg-slate-50 border-b border-slate-100 text-sm font-bold text-slate-900">Agents without a team</div>
          <ul className="divide-y divide-slate-100">{unassigned.map(agentRow)}</ul>
        </section>
      )}

      {moving && (
        <MoveAgentModal
          agent={moving} fromTeam={teamOf(moving.id)} teams={myTeams} users={state.users}
          onClose={() => setMoving(null)}
          onMove={toTeamId => { dispatch(moveAgentToTeam({ agentId: moving.id, toTeamId })); setMoving(null); }}
        />
      )}
    </div>
  );
}

```

---

## `src/features/teams/components/MoveAgentModal.tsx`

```tsx
import { XCircle } from 'lucide-react';
import { useState } from 'react';
import type { Team, User } from '@/domain/types';
import { UserAvatar } from '@/shared/components/UserAvatar';

/** The Operation Manager picks the new team for one agent. Only the team changes - the agent keeps every lead and all the data. */
export function MoveAgentModal({ agent, fromTeam, teams, users, onMove, onClose }: {
  agent: User; fromTeam: Team | undefined; teams: Team[]; users: User[];
  onMove: (toTeamId: string) => void; onClose: () => void;
}) {
  const options = teams.filter(t => t.id !== fromTeam?.id);
  const [toId, setToId] = useState(options[0]?.id ?? '');
  const to = options.find(t => t.id === toId);
  const leaderOf = (t?: Team) => users.find(u => u.id === t?.leaderId)?.name ?? '—';

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center" role="dialog" aria-modal="true" aria-label="Move agent">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 animate-slide-up">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900">Move agent to another team</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center" aria-label="Close">
            <XCircle className="w-4 h-4 text-slate-600" />
          </button>
        </div>
        <div className="px-6 py-5 space-y-4">
          <div className="flex items-center gap-3">
            <UserAvatar user={agent} />
            <div>
              <div className="text-sm font-medium text-slate-900">{agent.name}</div>
              <div className="text-xs text-slate-600">{fromTeam ? `${fromTeam.name} · ${leaderOf(fromTeam)}` : 'No team yet'}</div>
            </div>
          </div>

          <label className="block">
            <span className="text-xs font-semibold text-slate-600">New team</span>
            <select
              value={toId} onChange={e => setToId(e.target.value)}
              className="mt-1 w-full px-3 py-2.5 rounded-lg border border-slate-300 text-sm bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            >
              {options.map(t => <option key={t.id} value={t.id}>{t.name} · Team Leader: {leaderOf(t)}</option>)}
            </select>
          </label>

          <p className="text-xs text-slate-600 bg-slate-50 rounded-lg p-3">
            Only the team changes. {agent.name.split(' ')[0]} keeps all their leads, calls, meetings and sales exactly as they are,
            and continues under {to ? leaderOf(to) : 'the new Team Leader'}.
          </p>
        </div>
        <div className="px-6 py-4 border-t border-slate-100 flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100">Cancel</button>
          <button
            onClick={() => to && onMove(to.id)} disabled={!to}
            className="px-4 py-2 rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-40"
          >
            Move agent
          </button>
        </div>
      </div>
    </div>
  );
}

```

---

## `src/features/work-queue/WorkQueuePage.tsx`

```tsx
import { useCollapsibleSections } from '@/features/work-queue/useCollapsibleSections';
import type { QueueHandlers } from '@/features/work-queue/queueHandlers';
import { WorkQueueStats } from '@/features/work-queue/components/WorkQueueStats';
import { TodayMeetingsBanner } from '@/features/work-queue/components/TodayMeetingsBanner';
import { CampaignSection } from '@/features/work-queue/components/CampaignSection';
import { Download, Inbox } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import type { Lead, TouchPoint } from '@/domain/types';
import { queueCategory } from '@/domain/workflow/callClassification';
import { queueBucket } from '@/domain/workflow/leadQueue';
import { describeDueDate, findCurrentTouchPoint, stepLabel } from '@/domain/workflow/touchPoints';
import { TakeLeadsModal } from '@/features/take-leads/TakeLeadsModal';
import { buildWorkQueue } from '@/features/work-queue/buildWorkQueue';
import { CallLogModal } from '@/features/work-queue/components/CallLogModal';
import { DeleteLeadModal } from '@/features/work-queue/components/DeleteLeadModal';
import { LeadDetailDrawer } from '@/features/work-queue/components/LeadDetailDrawer';
import { TouchPointEmailModal } from '@/features/work-queue/components/TouchPointEmailModal';
import { useConfirm } from '@/shared/components/ConfirmDialog';
import { LeadPicker } from '@/shared/components/LeadPicker';
import { deleteLeadPermanently, logCallAndCompleteTouchPoint, removeLeadFromAgentQueue, restoreSkippedTouchPoint, resumeLeadWorkflow, sendEmailForLead, skipTouchPoint, stopLeadWorkflow, takeLeadsFromPool, useStore } from '@/store';

export function WorkQueuePage() {
  const { state, dispatch } = useStore();
  const currentUser = state.users.find(u => u.id === state.currentUserId)!;
  const sections = useCollapsibleSections();
  const [selectedLeadId, setSelectedLeadId] = useState<string | null>(null);
  const [callLeadId, setCallLeadId] = useState<string | null>(null);
  const [emailLeadId, setEmailLeadId] = useState<string | null>(null);
  const [deleteLeadId, setDeleteLeadId] = useState<string | null>(null);
  const [showTake, setShowTake] = useState(false);
  const { ask, dialog: confirmDialog } = useConfirm();
  const askSkip = (lead: Lead, tp: TouchPoint) => ask(
    { title: 'Skip this touch point?', message: <>Step <b>{stepLabel(tp.order, tp.type)}</b> ({tp.label}) for <b>{lead.companyName}</b> will be skipped and the lead moves to the next step. You can restore it later.</>, confirmLabel: 'Skip' },
    () => dispatch(skipTouchPoint({ leadId: lead.id, order: tp.order })),
  );

  // live clock: a lead moves from Next to Today by itself when its day arrives
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 30000);
    return () => clearInterval(t);
  }, []);

  // always read the live lead from the store (so modals/drawers never act on a stale copy)
  const leadById = (id: string | null) => (id ? state.leads.find(l => l.id === id) : undefined);
  const selectedLead = leadById(selectedLeadId);
  const callLead = leadById(callLeadId);
  const emailLead = leadById(emailLeadId);
  const leadToDelete = leadById(deleteLeadId);

  const myLeads = useMemo(
    () => state.leads.filter(l => !l.removedFromQueue && !l.expiredAt && l.agentId === currentUser.id),
    [state.leads, currentUser.id],
  );
  const queue = useMemo(() => buildWorkQueue(myLeads, state.workflows, now), [myLeads, state.workflows, now]);

  const todayStr = new Date().toISOString().split('T')[0];
  const arrangedMeetingsToday = useMemo(() => state.meetings.filter(m =>
    m.type === 'lead_meeting' && m.date === todayStr && m.status === 'arranged' &&
    m.participantIds.includes(currentUser.id)
  ), [state.meetings, currentUser.id, todayStr]);

  const currentTP = findCurrentTouchPoint;

  const handleMarkComplete = (lead: Lead, tp: TouchPoint) => {
    if (tp.type === 'call') setCallLeadId(lead.id);
    else setEmailLeadId(lead.id);
  };

  const todayTotal = queue.reduce((n, c) => n + c.todayCount, 0);
  const nextTotal = queue.reduce((n, c) => n + c.nextCount, 0);
  const stoppedTotal = queue.reduce((n, c) => n + c.stopped.length, 0);
  const overdueCount = myLeads.filter(l => queueBucket(l, now) === 'today' && describeDueDate(currentTP(l)).tone === 'overdue').length;

  const handlers: QueueHandlers = {
    onMarkComplete: handleMarkComplete,
    onSkip: askSkip,
    onDetails: l => setSelectedLeadId(l.id),
    onResume: leadId => dispatch(resumeLeadWorkflow(leadId)),
    onRequestDelete: leadId => setDeleteLeadId(leadId),
  };

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto">
      <WorkQueueStats
        todayTotal={todayTotal} overdueCount={overdueCount} nextTotal={nextTotal}
        stoppedTotal={stoppedTotal} meetingsTodayCount={arrangedMeetingsToday.length}
      />

      <TodayMeetingsBanner
        meetings={arrangedMeetingsToday}
        onOpenMeeting={m => { if (m.leadId && leadById(m.leadId)) setSelectedLeadId(m.leadId); }}
      />

      {/* Find a lead: type to search, then select it to open its details (same picker as the email form) */}
      <div className="mb-6 flex gap-3">
        <div className="flex-1">
          <LeadPicker
            leads={myLeads}
            value=""
            onChange={id => { if (id) setSelectedLeadId(id); }}
            placeholder="Search a lead by name, code, email or phone, then select it..."
          />
        </div>
        <button
          onClick={() => setShowTake(true)}
          className="px-4 py-2 bg-blue-600 text-white rounded-xl text-sm font-medium hover:bg-blue-700 transition-all flex items-center gap-1.5 shrink-0"
        >
          <Download className="w-3.5 h-3.5" />
          Take Leads
        </button>
      </div>

      {showTake && (
        <TakeLeadsModal
          leads={state.leads} users={state.users} workflows={state.workflows} me={currentUser}
          onTake={ids => dispatch(takeLeadsFromPool(ids))}
          onClose={() => setShowTake(false)}
        />
      )}

      {/* Work queue: campaign -> Today / Next / Stop */}
      <div className="space-y-3">
        {queue.length === 0 && (
          <div className="text-center py-12 text-slate-500">
            <Inbox className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No leads in your work queue</p>
            <p className="text-xs mt-1">Use “Take Leads” to get leads from the pool.</p>
          </div>
        )}

        {queue.map(campaign => (
          <CampaignSection key={campaign.code} campaign={campaign} now={now} sections={sections} handlers={handlers} />
        ))}
      </div>

      {/* Lead detail drawer */}
      {selectedLead && (
        <LeadDetailDrawer
          lead={selectedLead}
          onClose={() => setSelectedLeadId(null)}
          onMarkComplete={tp => handleMarkComplete(selectedLead, tp)}
          onSkip={tp => askSkip(selectedLead, tp)}
          onRestore={tp => dispatch(restoreSkippedTouchPoint({ leadId: selectedLead.id, order: tp.order }))}
          onStop={() => ask(
            { title: 'Stop this workflow?', message: <><b>{selectedLead.companyName}</b> leaves Today / Next and moves to Stop. You can resume it later.</>, confirmLabel: 'Stop workflow' },
            () => dispatch(stopLeadWorkflow(selectedLead.id)),
          )}
          onResume={() => dispatch(resumeLeadWorkflow(selectedLead.id))}
          onRemove={() => ask(
            { title: 'Remove from queue?', message: <><b>{selectedLead.companyName}</b> leaves your work queue and your leads and will not continue its steps. Its history and activity are kept, and its lead ID becomes free for anyone to add again.</>, confirmLabel: 'Remove', tone: 'danger' },
            () => { dispatch(removeLeadFromAgentQueue(selectedLead.id)); setSelectedLeadId(null); },
          )}
          onDelete={() => setDeleteLeadId(selectedLead.id)}
          onScheduleMeeting={() => setSelectedLeadId(null)}
          agentName={state.users.find(u => u.id === selectedLead.agentId)?.name || ''}
        />
      )}

      {/* Call log modal */}
      {callLead && (
        <CallLogModal
          lead={callLead}
          onClose={() => setCallLeadId(null)}
          onSave={(type, description) => {
            const order = callLead.currentTouchPoint;
            // one atomic action: the call log and the completed step can never get out of sync
            dispatch(logCallAndCompleteTouchPoint({
              leadId: callLead.id,
              log: { id: crypto.randomUUID(), type, description: description.trim(), timestamp: new Date().toISOString(), touchPointOrder: order },
            }));
            setCallLeadId(null);
          }}
        />
      )}

      {/* Email modal */}
      {emailLead && (
        <TouchPointEmailModal
          lead={emailLead}
          category={queueCategory(emailLead)}
          templates={state.emailTemplates}
          onClose={() => setEmailLeadId(null)}
          onSend={(to, subject, body, templateType) => {
            dispatch(sendEmailForLead({
              email: {
                id: crypto.randomUUID(),
                leadId: emailLead.id,
                leadName: emailLead.companyName,
                to, subject, body, templateType,
                sentAt: new Date().toISOString(),
                sentBy: state.currentUserId,
                sentByName: currentUser.name,
              },
              leadId: emailLead.id,
              touchPointOrder: emailLead.currentTouchPoint,
            }));
            setEmailLeadId(null);
          }}
        />
      )}

      {confirmDialog}

      {/* Delete confirmation */}
      {leadToDelete && (
        <DeleteLeadModal
          lead={leadToDelete}
          hasSales={state.sales.some(x => x.leadId === leadToDelete.id)}
          onCancel={() => setDeleteLeadId(null)}
          onConfirm={() => {
            dispatch(deleteLeadPermanently(leadToDelete.id));
            setDeleteLeadId(null);
            setSelectedLeadId(null);
          }}
        />
      )}
    </div>
  );
}

```

---

## `src/features/work-queue/buildWorkQueue.ts`

```ts
/** Turns the agent's leads into: campaign -> Today / Next / Stop -> touch point step -> category. */
import type { Lead, TouchPointType, Workflow } from '@/domain/types';
import { queueCategory } from '@/domain/workflow/callClassification';
import type { QueueCategory } from '@/domain/workflow/callClassification';
import { campaignLabel } from '@/domain/workflow/campaignLabel';
import { queueBucket } from '@/domain/workflow/leadQueue';
import { findCurrentTouchPoint } from '@/domain/workflow/touchPoints';
import { QUEUE_CATEGORY_ORDER } from '@/features/work-queue/queueStyles';

export interface TouchPointStepGroup {
  order: number;
  type: TouchPointType;
  label: string;
  byCategory: Record<QueueCategory, Lead[]>;
  total: number;
}

export interface CampaignQueue {
  code: string;
  name: string;            // "Activation" - what the agent sees instead of ACT-001
  today: TouchPointStepGroup[];
  next: TouchPointStepGroup[];
  todayCount: number;
  nextCount: number;
  stopped: Lead[];         // leads whose workflow the agent stopped
  finished: Lead[];        // leads that finished every touch point
  total: number;
}

const createEmptyLeadsByCategory = (): Record<QueueCategory, Lead[]> => ({ new: [], discovery: [], lvm: [], nvm: [], meeting: [] });

/**
 * Campaign -> Today / Next / Stop.
 *   Today = touch point is due today (or overdue)     Next = due tomorrow or later     Stop = stopped by the agent
 * Inside Today / Next the leads are grouped by touch point step (1: CALL, 2: EMAIL ...) and then by category.
 */
export function buildWorkQueue(leads: Lead[], workflows: Workflow[], now: number): CampaignQueue[] {
  const byCampaign = new Map<string, Lead[]>();
  for (const l of leads) {
    if (!byCampaign.has(l.campaignCode)) byCampaign.set(l.campaignCode, []);
    byCampaign.get(l.campaignCode)!.push(l);
  }

  return [...byCampaign.entries()].map(([code, campaignLeads]) => {
    const maps = { today: new Map<number, TouchPointStepGroup>(), next: new Map<number, TouchPointStepGroup>() };
    const stopped: Lead[] = [];
    const finished: Lead[] = [];
    let todayCount = 0, nextCount = 0;

    for (const lead of campaignLeads) {
      const bucket = queueBucket(lead, now);
      if (bucket === 'stop') { stopped.push(lead); continue; }
      if (bucket === 'finished') { finished.push(lead); continue; }
      const tp = findCurrentTouchPoint(lead)!;
      const stepMap = maps[bucket];
      if (!stepMap.has(tp.order)) stepMap.set(tp.order, { order: tp.order, type: tp.type, label: tp.label, byCategory: createEmptyLeadsByCategory(), total: 0 });
      const step = stepMap.get(tp.order)!;
      step.byCategory[queueCategory(lead)].push(lead);
      step.total++;
      if (bucket === 'today') todayCount++; else nextCount++;
    }

    // inside a step: the lead that has waited longest comes first
    const dueOf = (l: Lead) => new Date(findCurrentTouchPoint(l)?.dueDate ?? 0).getTime();
    const finish = (m: Map<number, TouchPointStepGroup>) => [...m.values()]
      .sort((a, b) => a.order - b.order)
      .map(s => { QUEUE_CATEGORY_ORDER.forEach(c => s.byCategory[c].sort((a, b) => dueOf(a) - dueOf(b))); return s; });

    return {
      code, name: campaignLabel(workflows, code),
      today: finish(maps.today), next: finish(maps.next),
      todayCount, nextCount, stopped, finished, total: campaignLeads.length,
    };
  }).sort((a, b) => a.name.localeCompare(b.name));
}

```

---

## `src/features/work-queue/components/CallLogModal.tsx`

```tsx
import { XCircle } from 'lucide-react';
import { useState } from 'react';
import type { CallType, Lead } from '@/domain/types';

export function CallLogModal({
  lead, onClose, onSave,
}: {
  lead: Lead;
  onClose: () => void;
  onSave: (type: CallType, description: string) => void;
}) {
  const [callType, setCallType] = useState<CallType>('nvm');
  const [description, setDescription] = useState('');

  const callTypes: { value: CallType; label: string; desc: string; color: string }[] = [
    { value: 'nvm', label: 'NVM', desc: 'No Voicemail', color: 'border-amber-300 bg-amber-50 text-amber-700' },
    { value: 'lvm', label: 'LVM', desc: 'Left Voicemail', color: 'border-amber-300 bg-amber-50 text-amber-700' },
    { value: 'discovery', label: 'Discovery', desc: 'Client Responded', color: 'border-emerald-300 bg-emerald-50 text-emerald-700' },
  ];

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 animate-slide-up">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Log Call</h2>
            <p className="text-sm text-slate-600">{lead.companyName} — {lead.contactName}</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center">
            <XCircle className="w-4 h-4 text-slate-600" />
          </button>
        </div>

        <div className="px-6 py-5 space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Call Type</label>
            <div className="grid grid-cols-3 gap-2">
              {callTypes.map(ct => (
                <button
                  key={ct.value}
                  onClick={() => setCallType(ct.value)}
                  className={`p-3 rounded-xl border-2 text-center transition-all ${
                    callType === ct.value ? ct.color : 'border-slate-200 text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <div className="font-bold text-sm">{ct.label}</div>
                  <div className="text-xs mt-0.5 opacity-80">{ct.desc}</div>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Call Description</label>
            <textarea
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="What happened during the call?"
              rows={4}
              className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 focus:border-transparent resize-none"
            />
            <p className="text-xs text-slate-500 mt-1">Required — this will be used for AI analysis</p>
          </div>
        </div>

        <div className="px-6 py-4 border-t border-slate-100 flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100 transition-colors">
            Cancel
          </button>
          <button
            onClick={() => onSave(callType, description)}
            disabled={!description.trim()}
            className="px-4 py-2 rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
          >
            Save & Mark Complete
          </button>
        </div>
      </div>
    </div>
  );
}

```

---

## `src/features/work-queue/components/CampaignSection.tsx`

```tsx
import { CheckCircle2, ChevronDown, ChevronRight } from 'lucide-react';
import { QueueBucketSection } from '@/features/work-queue/components/QueueBucketSection';
import { QueueLeadRow } from '@/features/work-queue/components/QueueLeadRow';
import type { CampaignQueue } from '@/features/work-queue/buildWorkQueue';
import type { QueueHandlers } from '@/features/work-queue/queueHandlers';
import type { CollapsibleSections } from '@/features/work-queue/useCollapsibleSections';

interface CampaignSectionProps {
  campaign: CampaignQueue;
  now: number;
  sections: CollapsibleSections;
  handlers: QueueHandlers;
}

/** One campaign: its Today / Next / Stop blocks and the leads that finished every touch point. */
export function CampaignSection({ campaign, now, sections, handlers }: CampaignSectionProps) {
  const { isOpen, toggle } = sections;
  const campKey = campaign.code;
  const campOpen = isOpen(campKey, true);
  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
      <button
        onClick={() => toggle(campKey)}
        className="w-full flex items-center gap-3 px-5 py-3.5 hover:bg-slate-50 transition-colors"
      >
        {campOpen ? <ChevronDown className="w-4 h-4 text-slate-500" /> : <ChevronRight className="w-4 h-4 text-slate-500" />}
        <span className="text-base font-bold text-slate-900">{campaign.name}</span>
        <div className="ml-auto flex items-center gap-1.5 text-xs">
          <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 font-medium">Today {campaign.todayCount}</span>
          <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-medium">Next {campaign.nextCount}</span>
          {campaign.stopped.length > 0 && (
            <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 font-medium">Stop {campaign.stopped.length}</span>
          )}
        </div>
      </button>

      {campOpen && (
        <div className="border-t border-slate-100 pb-1">
          <QueueBucketSection campaign={campaign} bucket="today" now={now} sections={sections} handlers={handlers} />
          <QueueBucketSection campaign={campaign} bucket="next" now={now} sections={sections} handlers={handlers} />
          <QueueBucketSection campaign={campaign} bucket="stop" now={now} sections={sections} handlers={handlers} />

          {campaign.finished.length > 0 && (
            <div className="mx-3 mb-3 rounded-xl border border-emerald-200 overflow-hidden">
              <button
                onClick={() => toggle(`${campKey}|done`)}
                className="w-full flex items-center gap-2.5 px-4 py-2.5 bg-emerald-50/60 hover:bg-emerald-50"
              >
                {isOpen(`${campKey}|done`, false) ? <ChevronDown className="w-3.5 h-3.5 text-slate-500" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-500" />}
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span className="text-sm font-medium text-slate-800">Workflow finished</span>
                <span className="ml-auto text-xs text-slate-600 bg-white px-2 py-0.5 rounded-full">{campaign.finished.length}</span>
              </button>
              {isOpen(`${campKey}|done`, false) && (
                <div className="divide-y divide-slate-100 bg-white">
                  {campaign.finished.map(lead => (
                    <QueueLeadRow
                      key={lead.id} lead={lead} tp={undefined} bucket="finished" now={now}
                      onAction={handlers.onMarkComplete} onSkip={() => {}} onDetails={handlers.onDetails}
                    />
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

```

---

## `src/features/work-queue/components/DeleteLeadModal.tsx`

```tsx
import { Trash2 } from 'lucide-react';
import type { Lead } from '@/domain/types';

export function DeleteLeadModal({ lead, hasSales, onCancel, onConfirm }: { lead: Lead; hasSales: boolean; onCancel: () => void; onConfirm: () => void }) {
  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-fade-in" onClick={onCancel} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-sm mx-4 animate-slide-up p-6">
        <div className="w-10 h-10 rounded-full bg-rose-100 flex items-center justify-center mb-3">
          <Trash2 className="w-5 h-5 text-rose-600" />
        </div>
        <h2 className="text-lg font-bold text-slate-900 mb-1">Delete this lead?</h2>
        <p className="text-sm text-slate-600 mb-5">
          <span className="font-medium text-slate-700">{lead.leadCode} — {lead.companyName}</span> will be deleted permanently
          with its call history and activity log. Its arranged meetings will be cancelled. This can’t be undone.
        </p>
        {hasSales && (
          <p className="text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mb-4">
            This lead has a recorded sale, so it can’t be deleted. Use “Remove from queue” instead — the sale and its history stay intact.
          </p>
        )}
        <div className="flex justify-end gap-2">
          <button onClick={onCancel} className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100">Cancel</button>
          <button onClick={onConfirm} disabled={hasSales} className="px-4 py-2 rounded-lg text-sm font-medium text-white bg-rose-600 hover:bg-rose-700 disabled:opacity-40 disabled:cursor-not-allowed">Delete permanently</button>
        </div>
      </div>
    </div>
  );
}

```

---

## `src/features/work-queue/components/LeadDetailDrawer.tsx`

```tsx
import { Ban, Calendar, CheckCircle2, Mail, MoreVertical, PauseCircle, Phone, Play, SkipForward, Trash2, Undo2, XCircle } from 'lucide-react';
import { useState } from 'react';
import type { Lead, TouchPoint } from '@/domain/types';
import { queueCategory } from '@/domain/workflow/callClassification';
import { describeDueDate, isOpenTouchPoint } from '@/domain/workflow/touchPoints';
import { QUEUE_CATEGORY_STYLE } from '@/features/work-queue/queueStyles';
import { LEAD_STATUS_STYLE } from '@/shared/ui/leadStatusStyles';

export function LeadDetailDrawer({
  lead, onClose, onMarkComplete, onSkip, onRestore, onStop, onResume, onRemove, onDelete, onScheduleMeeting, agentName,
}: {
  lead: Lead;
  onClose: () => void;
  onMarkComplete: (tp: TouchPoint) => void;
  onSkip: (tp: TouchPoint) => void;
  onRestore: (tp: TouchPoint) => void;
  onStop: () => void;
  onResume: () => void;
  onRemove: () => void;
  onDelete: () => void;
  onScheduleMeeting: () => void;
  agentName: string;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const config = LEAD_STATUS_STYLE[lead.status];
  const category = queueCategory(lead);

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div className="absolute inset-0 bg-black/30 animate-fade-in" onClick={onClose} />
      <div className="relative w-full max-w-lg bg-white h-full overflow-y-auto scrollbar-thin animate-slide-in shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 z-10 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">{lead.leadCode}</h2>
            <p className="text-sm text-slate-600">{lead.companyName} • {lead.contactName}</p>
          </div>
          <div className="flex items-center gap-2">
            {lead.stopped && <span className="text-xs px-2.5 py-1 rounded-full font-medium bg-amber-100 text-amber-700">Stopped</span>}
            <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${config.color}`}>{config.label}</span>
            <div className="relative">
              <button onClick={() => setMenuOpen(o => !o)} className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center">
                <MoreVertical className="w-4 h-4 text-slate-600" />
              </button>
              {menuOpen && (
                <div className="absolute right-0 top-full mt-1 w-52 bg-white rounded-lg shadow-lg border border-slate-200 z-20 py-1">
                  {lead.stopped ? (
                    <>
                      <button onClick={() => { onResume(); setMenuOpen(false); }} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-emerald-700 hover:bg-emerald-50">
                        <Play className="w-3.5 h-3.5" /> Resume Workflow
                      </button>
                      <button onClick={() => { onDelete(); setMenuOpen(false); }} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-rose-600 hover:bg-rose-50">
                        <Trash2 className="w-3.5 h-3.5" /> Delete Permanently
                      </button>
                    </>
                  ) : (
                    <>
                      <button onClick={() => { onScheduleMeeting(); setMenuOpen(false); }} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-slate-700 hover:bg-slate-50">
                        <Calendar className="w-3.5 h-3.5" /> Schedule Meeting
                      </button>
                      <button onClick={() => { onStop(); setMenuOpen(false); }} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-amber-600 hover:bg-amber-50">
                        <Ban className="w-3.5 h-3.5" /> Stop Workflow
                      </button>
                      <button onClick={() => { onRemove(); setMenuOpen(false); }} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-rose-600 hover:bg-rose-50">
                        <XCircle className="w-3.5 h-3.5" /> Remove from Queue
                      </button>
                    </>
                  )}
                </div>
              )}
            </div>
            <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center">
              <XCircle className="w-4 h-4 text-slate-600" />
            </button>
          </div>
        </div>

        {lead.stopped && (
          <div className="mx-6 mt-4 p-3 rounded-lg bg-amber-50 border border-amber-200 flex items-center gap-3">
            <PauseCircle className="w-4 h-4 text-amber-600 shrink-0" />
            <p className="text-xs text-amber-800 flex-1">This workflow is stopped. Resume it to bring the lead back to the queue, or delete it.</p>
            <button onClick={onResume} className="px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-600 text-white hover:bg-emerald-700 shrink-0">Resume</button>
          </div>
        )}

        {/* Contact info */}
        <div className="px-6 py-4 border-b border-slate-200">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-xs text-slate-500 mb-1">Phone</div>
              <div className="text-sm text-slate-900">{lead.phone || '—'}</div>
            </div>
            <div>
              <div className="text-xs text-slate-500 mb-1">Email</div>
              <div className="text-sm text-slate-900 truncate">{lead.email || '—'}</div>
            </div>
            <div>
              <div className="text-xs text-slate-500 mb-1">Agent</div>
              <div className="text-sm text-slate-900">{agentName}</div>
            </div>
            <div>
              <div className="text-xs text-slate-500 mb-1">Queue category</div>
              <div className="text-sm text-slate-900">{QUEUE_CATEGORY_STYLE[category].label}</div>
            </div>
          </div>
        </div>

        {/* Touch points timeline */}
        <div className="px-6 py-4 border-b border-slate-200">
          <h3 className="text-sm font-semibold text-slate-900 mb-3">Workflow Touch Points</h3>
          <div className="space-y-2">
            {lead.touchPoints.map(tp => {
              const isCurrent = tp.order === lead.currentTouchPoint;
              const skipped = tp.status === 'skipped';
              const open = isOpenTouchPoint(tp);
              const due = describeDueDate(open ? tp : undefined);
              const overdue = due.tone === 'overdue';
              return (
                <div
                  key={tp.order}
                  className={`flex items-center gap-3 p-3 rounded-lg border transition-all ${
                    isCurrent && !lead.stopped ? 'border-blue-300 bg-blue-50/50' : 'border-slate-100'
                  } ${skipped ? 'opacity-70' : ''}`}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                    tp.status === 'completed' ? 'bg-emerald-100' : overdue ? 'bg-rose-100' : 'bg-slate-100'
                  }`}>
                    {tp.status === 'completed' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    ) : skipped ? (
                      <SkipForward className="w-4 h-4 text-slate-500" />
                    ) : tp.type === 'call' ? (
                      <Phone className={`w-4 h-4 ${overdue ? 'text-rose-600' : 'text-slate-600'}`} />
                    ) : (
                      <Mail className={`w-4 h-4 ${overdue ? 'text-rose-600' : 'text-slate-600'}`} />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className={`text-sm font-medium text-slate-900 ${skipped ? 'line-through text-slate-600' : ''}`}>
                      {tp.order + 1}. {tp.label}
                    </div>
                    <div className="text-xs text-slate-600">
                      {tp.status === 'completed' && tp.completedAt
                        ? `Completed ${new Date(tp.completedAt).toLocaleDateString()}`
                        : skipped
                        ? `Skipped${tp.skippedAt ? ' ' + new Date(tp.skippedAt).toLocaleDateString() : ''}`
                        : tp.dueDate
                        ? <>Due {new Date(tp.dueDate).toLocaleDateString()}{overdue && <span className="text-rose-600 ml-1">• Overdue</span>}</>
                        : 'Pending'}
                    </div>
                  </div>

                  {!lead.stopped && (
                    <div className="flex items-center gap-1.5 shrink-0">
                      {isCurrent && open && (
                        <button
                          onClick={() => onMarkComplete(tp)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium text-white transition-all ${
                            tp.type === 'call' ? 'bg-cyan-600 hover:bg-cyan-700' : 'bg-violet-600 hover:bg-violet-700'
                          }`}
                        >
                          {tp.type === 'call' ? 'Log Call' : 'Send Email'}
                        </button>
                      )}
                      {open && (
                        <button
                          onClick={() => onSkip(tp)}
                          title="Skip this touch point"
                          aria-label="Skip this touch point"
                          className="w-8 h-8 rounded-lg text-slate-600 hover:bg-slate-100 flex items-center justify-center"
                        >
                          <SkipForward className="w-3.5 h-3.5" />
                        </button>
                      )}
                      {skipped && (
                        <button
                          onClick={() => onRestore(tp)}
                          className="px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 hover:bg-slate-100 flex items-center gap-1"
                        >
                          <Undo2 className="w-3 h-3" /> Restore
                        </button>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Call logs */}
        <div className="px-6 py-4 border-b border-slate-200">
          <h3 className="text-sm font-semibold text-slate-900 mb-3">Call History ({lead.callLogs.length})</h3>
          {lead.callLogs.length === 0 ? (
            <p className="text-sm text-slate-500">No calls logged yet</p>
          ) : (
            <div className="space-y-2">
              {lead.callLogs.map(cl => (
                <div key={cl.id} className="p-3 bg-slate-50 rounded-lg">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                      cl.type === 'discovery' ? 'bg-emerald-100 text-emerald-700' :
                      cl.type === 'lvm' ? 'bg-amber-100 text-amber-700' :
                      'bg-amber-100 text-amber-700'
                    }`}>
                      {cl.type.toUpperCase()}
                    </span>
                    <span className="text-xs text-slate-500">{new Date(cl.timestamp).toLocaleString()}</span>
                  </div>
                  <p className="text-sm text-slate-700">{cl.description}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* History */}
        <div className="px-6 py-4">
          <h3 className="text-sm font-semibold text-slate-900 mb-3">Activity History</h3>
          <div className="space-y-2">
            {lead.history.map(h => (
              <div key={h.id} className="flex items-start gap-2 text-xs">
                <div className="w-1.5 h-1.5 bg-slate-300 rounded-full mt-1.5 shrink-0" />
                <div className="flex-1">
                  <span className="text-slate-600">
                    <span className="font-medium text-slate-900">{h.userName}</span> — {h.action.replace(/_/g, ' ')}
                    {h.detail && <span className="text-slate-500"> • {h.detail}</span>}
                  </span>
                  <div className="text-slate-500">{new Date(h.timestamp).toLocaleString()}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

```

---

## `src/features/work-queue/components/QueueBucketSection.tsx`

```tsx
import { ChevronDown, ChevronRight } from 'lucide-react';
import { QUEUE_BUCKET_STYLE } from '@/features/work-queue/queueStyles';
import { StoppedLeadRow } from '@/features/work-queue/components/StoppedLeadRow';
import { TouchPointStepSection } from '@/features/work-queue/components/TouchPointStepSection';
import type { CampaignQueue } from '@/features/work-queue/buildWorkQueue';
import type { QueueHandlers } from '@/features/work-queue/queueHandlers';
import type { CollapsibleSections } from '@/features/work-queue/useCollapsibleSections';

interface QueueBucketSectionProps {
  campaign: CampaignQueue;
  bucket: 'today' | 'next' | 'stop';
  now: number;
  sections: CollapsibleSections;
  handlers: QueueHandlers;
}

/** The big Today / Next / Stop block of one campaign. */
export function QueueBucketSection({ campaign, bucket, now, sections, handlers }: QueueBucketSectionProps) {
  const { isOpen, toggle } = sections;
  const style = QUEUE_BUCKET_STYLE[bucket];
  const Icon = style.icon;
  const key = `${campaign.code}|${bucket}`;
  const open = isOpen(key, bucket === 'today');
  const count = bucket === 'today' ? campaign.todayCount : bucket === 'next' ? campaign.nextCount : campaign.stopped.length;
  return (
    <div className={`mx-3 my-3 rounded-xl border overflow-hidden ${style.wrap}`}>
      <button onClick={() => toggle(key)} className={`w-full flex items-center gap-3 px-4 py-3 transition-colors ${style.head}`}>
        {open ? <ChevronDown className={`w-4 h-4 ${style.text}`} /> : <ChevronRight className={`w-4 h-4 ${style.text}`} />}
        <Icon className={`w-4 h-4 ${style.text}`} />
        <span className={`text-sm font-bold ${style.text}`}>{style.label}</span>
        <span className="text-xs text-slate-600 hidden sm:inline">{style.hint}</span>
        <span className={`ml-auto text-xs font-semibold px-2.5 py-0.5 rounded-full ${style.pill}`}>{count}</span>
      </button>

      {open && (
        <div className="bg-white border-t border-slate-100">
          {count === 0 && (
            <div className="px-5 py-5 text-sm text-slate-500">
              {bucket === 'today' ? 'Nothing due today in this campaign.' : bucket === 'next' ? 'Nothing coming up.' : 'No stopped workflows.'}
            </div>
          )}

          {bucket !== 'stop' && count > 0 && (bucket === 'today' ? campaign.today : campaign.next).map(step => (
            <TouchPointStepSection
              key={`${campaign.code}|${bucket}|${step.order}`}
              campaignCode={campaign.code} bucket={bucket} step={step} now={now} sections={sections} handlers={handlers}
            />
          ))}

          {bucket === 'stop' && campaign.stopped.length > 0 && (
            <div className="divide-y divide-slate-100">
              {campaign.stopped.map(lead => (
                <StoppedLeadRow key={lead.id} lead={lead} handlers={handlers} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

```

---

## `src/features/work-queue/components/QueueLeadRow.tsx`

```tsx
import { AlertCircle, Building2, Clock, Hourglass, Mail, Phone, SkipForward, User } from 'lucide-react';
import type { Lead, TouchPoint } from '@/domain/types';
import { daysUntilExpiry } from '@/domain/workflow/leadExpiry';
import { becomesTodayAt } from '@/domain/workflow/leadQueue';
import { describeDueDate, lastTouchTimestamp } from '@/domain/workflow/touchPoints';
import { DUE_TONE_CLASS } from '@/features/work-queue/queueStyles';
import { formatDuration } from '@/shared/lib/dates';

export function QueueLeadRow({
  lead, tp, bucket, now, onAction, onSkip, onDetails,
}: {
  lead: Lead;
  tp: TouchPoint | undefined;
  bucket: 'today' | 'next' | 'finished';
  now: number;
  onAction: (lead: Lead, tp: TouchPoint) => void;
  onSkip: (lead: Lead, tp: TouchPoint) => void;
  onDetails: (lead: Lead) => void;
}) {
  const due = describeDueDate(tp);
  const overdue = due.tone === 'overdue';
  // 15-day rule: warn the agent when a lead is about to leave the queue
  const daysLeft = lead.status === 'arranged_meeting' ? null : daysUntilExpiry(lead, now);
  const expiring = daysLeft !== null && daysLeft <= 3;
  // an email step with no address cannot be sent automatically
  const missingEmail = !!tp && tp.type === 'email' && !lead.email;

  // Counting runs FORWARD from the last touch point the agent did - not down from the day the lead was assigned.
  const lastTouch = lastTouchTimestamp(lead);
  const enterTodayAt = becomesTodayAt(tp);

  return (
    <div className="flex items-center gap-3 px-5 py-3 hover:bg-slate-50 transition-colors">
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-mono text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded shrink-0">{lead.leadCode}</span>
          <Building2 className="w-3.5 h-3.5 text-slate-500 shrink-0" />
          <span className="text-sm font-medium text-slate-900 truncate">{lead.companyName}</span>
        </div>
        <div className="flex items-center gap-3 text-xs text-slate-600 flex-wrap">
          <span className="flex items-center gap-1"><User className="w-3 h-3" />{lead.contactName}</span>
          {expiring && (
            <span className="flex items-center gap-1 text-amber-600 font-medium">
              <Hourglass className="w-3 h-3" />
              {daysLeft === 0 ? 'Leaves queue today' : `Leaves queue in ${daysLeft}d`}
            </span>
          )}
          {missingEmail && (
            <span className="flex items-center gap-1 text-rose-600 font-medium">
              <AlertCircle className="w-3 h-3" />
              No email - can't auto-send
            </span>
          )}
          {tp && (
            <span className={`flex items-center gap-1 ${DUE_TONE_CLASS[due.tone]}`}>
              {tp.type === 'call' ? <Phone className="w-3 h-3" /> : <Mail className="w-3 h-3" />}
              {due.label}
              {overdue && <AlertCircle className="w-3 h-3" />}
            </span>
          )}
        </div>
      </div>

      <div className="hidden md:flex flex-col items-end gap-0.5 text-xs shrink-0 text-right">
        {bucket === 'next' && enterTodayAt !== null && (
          <span className="text-slate-700 font-medium flex items-center gap-1">
            <Hourglass className="w-3 h-3" />
            Today in {formatDuration(enterTodayAt - now)}
          </span>
        )}
        {bucket === 'today' && (
          <span className={`font-medium flex items-center gap-1 ${overdue ? 'text-rose-600' : 'text-blue-600'}`}>
            <Clock className="w-3 h-3" />
            {overdue && tp?.dueDate ? `Waiting ${formatDuration(now - new Date(tp.dueDate).getTime())}` : 'Your turn now'}
          </span>
        )}
        <span className="text-slate-500">
          {lastTouch === null ? 'No touch yet' : `Last touch ${formatDuration(now - lastTouch)} ago`}
        </span>
      </div>

      <div className="flex items-center gap-1.5 shrink-0">
        {tp && bucket === 'today' && (
          <>
            <button
              onClick={() => onAction(lead, tp)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 ${
                overdue ? 'bg-rose-600 text-white hover:bg-rose-700'
                : tp.type === 'call' ? 'bg-cyan-600 text-white hover:bg-cyan-700'
                : 'bg-violet-600 text-white hover:bg-violet-700'
              }`}
            >
              {tp.type === 'call' ? <Phone className="w-3 h-3" /> : <Mail className="w-3 h-3" />}
              Mark {tp.type === 'call' ? 'Call' : 'Email'}
            </button>
            <button
              onClick={() => onSkip(lead, tp)}
              title="Skip this touch point"
              aria-label="Skip this touch point"
              className="w-8 h-8 rounded-lg text-slate-600 hover:bg-slate-100 flex items-center justify-center"
            >
              <SkipForward className="w-3.5 h-3.5" />
            </button>
          </>
        )}
        <button
          onClick={() => onDetails(lead)}
          className="px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 hover:bg-slate-100 transition-colors"
        >
          Details
        </button>
      </div>
    </div>
  );
}

```

---

## `src/features/work-queue/components/StoppedLeadRow.tsx`

```tsx
import { Building2, Play, Trash2 } from 'lucide-react';
import type { Lead } from '@/domain/types';
import { findCurrentTouchPoint, stepLabel } from '@/domain/workflow/touchPoints';
import type { QueueHandlers } from '@/features/work-queue/queueHandlers';

interface StoppedLeadRowProps {
  lead: Lead;
  handlers: QueueHandlers;
}

/** A lead whose workflow the agent stopped: resume it, delete it, or open its details. */
export function StoppedLeadRow({ lead, handlers }: StoppedLeadRowProps) {
  const tp = findCurrentTouchPoint(lead);
  return (
    <div className="flex items-center gap-3 px-5 py-3">
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-mono text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded shrink-0">{lead.leadCode}</span>
          <Building2 className="w-3.5 h-3.5 text-slate-500 shrink-0" />
          <span className="text-sm font-medium text-slate-900 truncate">{lead.companyName}</span>
        </div>
        <div className="text-xs text-slate-600">
          {tp ? `Stopped at ${stepLabel(tp.order, tp.type)} · ${tp.label}` : 'Stopped after finishing all touch points'}
        </div>
      </div>
      <div className="flex items-center gap-1.5 shrink-0">
        <button
          onClick={() => handlers.onResume(lead.id)}
          className="px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-600 text-white hover:bg-emerald-700 flex items-center gap-1.5"
        >
          <Play className="w-3 h-3" /> Resume
        </button>
        <button
          onClick={() => handlers.onRequestDelete(lead.id)}
          className="px-3 py-1.5 rounded-lg text-xs font-medium text-rose-600 hover:bg-rose-50 flex items-center gap-1.5"
        >
          <Trash2 className="w-3 h-3" /> Delete
        </button>
        <button
          onClick={() => handlers.onDetails(lead)}
          className="px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 hover:bg-slate-100"
        >
          Details
        </button>
      </div>
    </div>
  );
}

```

---

## `src/features/work-queue/components/TodayMeetingsBanner.tsx`

```tsx
import { Calendar } from 'lucide-react';
import type { Meeting } from '@/domain/types';

interface TodayMeetingsBannerProps {
  meetings: Meeting[];
  onOpenMeeting: (meeting: Meeting) => void;
}

/** The meetings the agent has arranged for today (shown only when there is at least one). */
export function TodayMeetingsBanner({ meetings, onOpenMeeting }: TodayMeetingsBannerProps) {
  return (
    <>
      {meetings.length > 0 && (
        <div className="bg-violet-50 border border-violet-200 rounded-xl p-4 mb-6">
          <div className="flex items-center gap-2 mb-3">
            <Calendar className="w-4 h-4 text-violet-600" />
            <span className="font-semibold text-sm text-violet-900">Arranged Meetings — Today</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {meetings.map(m => (
              <button
                key={m.id}
                onClick={() => onOpenMeeting(m)}
                className="flex items-center gap-3 bg-white rounded-lg p-3 border border-violet-100 hover:border-violet-300 transition-all text-left"
              >
                <div className="w-10 h-10 bg-violet-600 rounded-lg flex items-center justify-center shrink-0">
                  <Calendar className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm text-slate-900 truncate">{m.companyName}</div>
                  <div className="text-xs text-slate-600">{m.leadName} — {m.time}</div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </>
  );
}

```

---

## `src/features/work-queue/components/TouchPointEmailModal.tsx`

```tsx
import { Send, XCircle } from 'lucide-react';
import { useState } from 'react';
import type { EmailTemplate, Lead } from '@/domain/types';
import type { QueueCategory } from '@/domain/workflow/callClassification';

export function TouchPointEmailModal({
  lead, category, templates, onClose, onSend,
}: {
  lead: Lead;
  category: QueueCategory;
  templates: EmailTemplate[];
  onClose: () => void;
  onSend: (to: string, subject: string, body: string, templateType: 'discovery' | 'no_response' | 'custom') => void;
}) {
  // Writing the email by hand is the main way; a template is only an optional starting point.
  const suggestedType = category === 'discovery' ? 'discovery' : 'no_response';
  const [templateType, setTemplateType] = useState<'discovery' | 'no_response' | 'custom'>('custom');
  const [to, setTo] = useState(lead.email || '');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');

  const applyTemplate = (type: 'discovery' | 'no_response' | 'custom') => {
    setTemplateType(type);
    const t = templates.find(x => x.type === type);
    if (type !== 'custom' && t) { setSubject(t.subject); setBody(t.body); }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg mx-4 animate-slide-up max-h-[90vh] overflow-y-auto scrollbar-thin">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between sticky top-0 bg-white">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Send Email</h2>
            <p className="text-sm text-slate-600">{lead.companyName} — {lead.contactName}</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center">
            <XCircle className="w-4 h-4 text-slate-600" />
          </button>
        </div>

        <div className="px-6 py-5 space-y-4">
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500">Start from:</span>
            {([['custom', 'Blank'], [suggestedType, suggestedType === 'discovery' ? 'Discovery template' : 'No Response template']] as const).map(([val, label]) => (
              <button
                key={val}
                type="button"
                onClick={() => applyTemplate(val)}
                className={`px-2.5 py-1 rounded-full font-medium transition-all ${
                  templateType === val ? 'bg-violet-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">To</label>
            <input
              type="email"
              value={to}
              onChange={e => setTo(e.target.value)}
              placeholder="recipient@example.com"
              className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Subject</label>
            <input
              type="text"
              value={subject}
              onChange={e => setSubject(e.target.value)}
              className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Message</label>
            <textarea
              value={body}
              onChange={e => setBody(e.target.value)}
              rows={8}
              className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 focus:border-transparent resize-none font-mono"
            />
          </div>
        </div>

        <div className="px-6 py-4 border-t border-slate-100 flex justify-end gap-2 sticky bottom-0 bg-white">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100 transition-colors">
            Cancel
          </button>
          <button
            onClick={() => onSend(to, subject, body, templateType)}
            disabled={!to.trim() || !subject.trim()}
            className="px-4 py-2 rounded-lg text-sm font-medium text-white bg-violet-600 hover:bg-violet-700 disabled:opacity-40 disabled:cursor-not-allowed transition-all flex items-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5" />
            Send & Mark Complete
          </button>
        </div>
      </div>
    </div>
  );
}

```

---

## `src/features/work-queue/components/TouchPointStepSection.tsx`

```tsx
import { ChevronDown, ChevronRight, Mail, Phone } from 'lucide-react';
import { findCurrentTouchPoint, stepLabel } from '@/domain/workflow/touchPoints';
import { QUEUE_CATEGORY_ORDER, QUEUE_CATEGORY_STYLE } from '@/features/work-queue/queueStyles';
import { QueueLeadRow } from '@/features/work-queue/components/QueueLeadRow';
import type { TouchPointStepGroup } from '@/features/work-queue/buildWorkQueue';
import type { QueueHandlers } from '@/features/work-queue/queueHandlers';
import type { CollapsibleSections } from '@/features/work-queue/useCollapsibleSections';

interface TouchPointStepSectionProps {
  campaignCode: string;
  bucket: 'today' | 'next';
  step: TouchPointStepGroup;
  now: number;
  sections: CollapsibleSections;
  handlers: QueueHandlers;
}

/** One touch point step (for example "1: CALL") of a campaign, split into its categories (New / Discovery / LVM / NVM / Meeting). */
export function TouchPointStepSection({ campaignCode, bucket, step, now, sections, handlers }: TouchPointStepSectionProps) {
  const { isOpen, toggle } = sections;
  const stepKey = `${campaignCode}|${bucket}|${step.order}`;
  const stepOpen = isOpen(stepKey, true);
  const StepIcon = step.type === 'call' ? Phone : Mail;
  return (
    <div className="border-b border-slate-100 last:border-0">
      <button
        onClick={() => toggle(stepKey)}
        className="w-full flex items-center gap-2.5 px-5 py-2.5 hover:bg-slate-50/60 transition-colors"
      >
        {stepOpen ? <ChevronDown className="w-3.5 h-3.5 text-slate-500" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-500" />}
        <span className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${step.type === 'call' ? 'bg-cyan-50 text-cyan-700' : 'bg-violet-50 text-violet-600'}`}>
          <StepIcon className="w-3 h-3" />
        </span>
        <span className="text-sm font-semibold text-slate-800">{stepLabel(step.order, step.type)}</span>
        <span className="text-xs text-slate-500 truncate">{step.label}</span>
        <span className="ml-auto text-xs text-slate-600 bg-slate-100 px-2 py-0.5 rounded-full">{step.total}</span>
      </button>

      {stepOpen && (
        <div className="pl-6 bg-slate-50/30">
          {QUEUE_CATEGORY_ORDER.filter(cat => step.byCategory[cat].length > 0).map(cat => {
            const cfg = QUEUE_CATEGORY_STYLE[cat];
            const catKey = `${stepKey}|${cat}`;
            const catOpen = isOpen(catKey, true);
            const leads = step.byCategory[cat];
            return (
              <div key={catKey} className="border-t border-slate-100">
                <button
                  onClick={() => toggle(catKey)}
                  className="w-full flex items-center gap-2.5 px-5 py-2 hover:bg-slate-50 transition-colors"
                >
                  {catOpen ? <ChevronDown className="w-3.5 h-3.5 text-slate-500" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-500" />}
                  <div className={`w-2 h-2 rounded-full ${cfg.dot}`} />
                  <span className="text-sm font-medium text-slate-700">{cfg.label}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${cfg.color}`}>{leads.length}</span>
                </button>
                {catOpen && (
                  <div className="divide-y divide-slate-100 bg-white">
                    {leads.map(lead => (
                      <QueueLeadRow
                        key={lead.id}
                        lead={lead}
                        tp={findCurrentTouchPoint(lead)}
                        bucket={bucket}
                        now={now}
                        onAction={handlers.onMarkComplete}
                        onSkip={handlers.onSkip}
                        onDetails={handlers.onDetails}
                      />
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

```

---

## `src/features/work-queue/components/WorkQueueStats.tsx`

```tsx
interface WorkQueueStatsProps {
  todayTotal: number;
  overdueCount: number;
  nextTotal: number;
  stoppedTotal: number;
  meetingsTodayCount: number;
}

/** The five numbers at the top of the work queue. */
export function WorkQueueStats({ todayTotal, overdueCount, nextTotal, stoppedTotal, meetingsTodayCount }: WorkQueueStatsProps) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
      <div className="bg-white rounded-xl border border-blue-200 p-4">
        <div className="text-sm text-slate-600 mb-1">Today</div>
        <div className="text-2xl font-bold text-blue-600">{todayTotal}</div>
      </div>
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
        <div className="text-sm text-slate-600 mb-1">Overdue</div>
        <div className="text-2xl font-bold text-rose-600">{overdueCount}</div>
      </div>
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
        <div className="text-sm text-slate-600 mb-1">Next</div>
        <div className="text-2xl font-bold text-slate-700">{nextTotal}</div>
      </div>
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
        <div className="text-sm text-slate-600 mb-1">Stopped</div>
        <div className="text-2xl font-bold text-amber-600">{stoppedTotal}</div>
      </div>
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 col-span-2 lg:col-span-1">
        <div className="text-sm text-slate-600 mb-1">Meetings Today</div>
        <div className="text-2xl font-bold text-violet-600">{meetingsTodayCount}</div>
      </div>
    </div>
  );
}

```

---

## `src/features/work-queue/queueHandlers.ts`

```ts
import type { Lead, TouchPoint } from '@/domain/types';

/** Everything a row of the work queue can ask the page to do (the page owns the modals and the store calls). */
export interface QueueHandlers {
  onMarkComplete: (lead: Lead, tp: TouchPoint) => void;   // opens the call-log or email modal
  onSkip: (lead: Lead, tp: TouchPoint) => void;           // asks for confirmation, then skips the touch point
  onDetails: (lead: Lead) => void;                        // opens the lead drawer
  onResume: (leadId: string) => void;                     // resumes a stopped workflow
  onRequestDelete: (leadId: string) => void;              // opens the "delete permanently" confirmation
}

```

---

## `src/features/work-queue/queueStyles.ts`

```ts
/** Colours/labels for the work queue sections. */
import { Hourglass, PauseCircle, Sun } from 'lucide-react';
import type { QueueCategory } from '@/domain/workflow/callClassification';
import { LEAD_STATUS_STYLE } from '@/shared/ui/leadStatusStyles';

// The categories a lead can sit in inside a touch point step. Each one is its own section.
export const QUEUE_CATEGORY_ORDER: QueueCategory[] = ['new', 'discovery', 'lvm', 'nvm', 'meeting'];

export const QUEUE_CATEGORY_STYLE: Record<QueueCategory, { label: string; color: string; dot: string }> = {
  new: LEAD_STATUS_STYLE.new,
  discovery: LEAD_STATUS_STYLE.discovery,
  lvm: { ...LEAD_STATUS_STYLE.lvm, label: 'LVM' },
  nvm: { ...LEAD_STATUS_STYLE.nvm, label: 'NVM' },
  meeting: LEAD_STATUS_STYLE.arranged_meeting,
};

export const DUE_TONE_CLASS = {
  overdue: 'text-rose-600 font-medium',
  today: 'text-amber-600 font-medium',
  later: 'text-slate-500',
  none: 'text-slate-500',
};

export const QUEUE_BUCKET_STYLE = {
  today: { label: 'Today', hint: 'due today or overdue', icon: Sun, wrap: 'border-blue-200', head: 'bg-blue-50 hover:bg-blue-100/70', text: 'text-blue-800', pill: 'bg-blue-600 text-white' },
  next: { label: 'Next', hint: 'tomorrow or later', icon: Hourglass, wrap: 'border-slate-200', head: 'bg-slate-50 hover:bg-slate-100', text: 'text-slate-700', pill: 'bg-slate-600 text-white' },
  stop: { label: 'Stop', hint: 'workflows you stopped', icon: PauseCircle, wrap: 'border-amber-200', head: 'bg-amber-50 hover:bg-amber-100/70', text: 'text-amber-800', pill: 'bg-amber-500 text-white' },
} as const;

```

---

## `src/features/work-queue/useCollapsibleSections.ts`

```ts
import { useState } from 'react';

/**
 * Open/closed state of every collapsible block of the work queue (campaign, Today/Next/Stop, step, category).
 * Only the blocks the agent FLIPPED away from their default are remembered: campaign + Today open, Next + Stop closed.
 */
export function useCollapsibleSections() {
  const [flipped, setFlipped] = useState<Set<string>>(new Set());

  const isOpen = (key: string, defaultOpen: boolean) => (flipped.has(key) ? !defaultOpen : defaultOpen);
  const toggle = (key: string) =>
    setFlipped(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key); else next.add(key);
      return next;
    });

  return { isOpen, toggle };
}

export type CollapsibleSections = ReturnType<typeof useCollapsibleSections>;

```

---

## `src/index.css`

```css
@tailwind base;
@tailwind components;
@tailwind utilities;

/*
 * SalesFlow design tokens
 *   Primary (buttons, active nav, focus) ... blue
 *   Success ... emerald   Warning ... amber   Error ... rose
 *   Accent ... violet (meetings, emails)   Secondary accent ... cyan (call touch points)
 *   Neutrals ... slate (bg-slate-50 page, white cards, slate-200 borders)
 * Controls rounded-lg, cards rounded-xl, dialogs rounded-2xl. System UI font stack.
 */
@layer base {
  :root {
    --color-primary-50: #eff6ff;
    --color-primary-100: #dbeafe;
    --color-primary-200: #bfdbfe;
    --color-primary-300: #93c5fd;
    --color-primary-400: #60a5fa;
    --color-primary-500: #3b82f6;
    --color-primary-600: #2563eb;
    --color-primary-700: #1d4ed8;
    --color-primary-800: #1e40af;
    --color-primary-900: #1e3a8a;
  }

  html {
    -webkit-text-size-adjust: 100%;
  }

  body {
    font-family: ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #0f172a;
    background-color: #f8fafc;
    font-feature-settings: 'tnum' 1;
  }

  ::selection {
    background: #bfdbfe;
    color: #1e3a8a;
  }

  /* Keyboard users always see where they are. Mouse clicks stay clean. */
  button:focus-visible,
  a:focus-visible,
  summary:focus-visible,
  [role='button']:focus-visible,
  [tabindex]:focus-visible {
    outline: 2px solid #3b82f6;
    outline-offset: 2px;
  }

  button:disabled,
  input:disabled,
  select:disabled,
  textarea:disabled {
    cursor: not-allowed;
  }

  input:disabled,
  select:disabled,
  textarea:disabled {
    background-color: #f1f5f9;
    color: #64748b;
  }

  /* Date / time / select controls match the text inputs */
  select {
    background-color: #fff;
  }
}

@layer utilities {
  .scrollbar-thin {
    scrollbar-width: thin;
    scrollbar-color: #cbd5e1 transparent;
  }
  .scrollbar-thin::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }
  .scrollbar-thin::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 9999px;
    border: 2px solid transparent;
    background-clip: content-box;
  }
  .scrollbar-thin::-webkit-scrollbar-thumb:hover {
    background: #94a3b8;
    background-clip: content-box;
  }
  .scrollbar-thin::-webkit-scrollbar-track {
    background: transparent;
  }

  .animate-fade-in {
    animation: fadeIn 0.18s ease-out;
  }

  .animate-slide-in {
    animation: slideIn 0.24s cubic-bezier(0.22, 1, 0.36, 1);
  }

  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }

  @keyframes slideIn {
    from { transform: translateX(100%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
  }

  @keyframes slideUp {
    from { transform: translateY(12px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
  }

  .animate-slide-up {
    animation: slideUp 0.22s cubic-bezier(0.22, 1, 0.36, 1);
  }

  @keyframes pulse-ring {
    0% { box-shadow: 0 0 0 0 rgba(244, 63, 94, 0.4); }
    70% { box-shadow: 0 0 0 8px rgba(244, 63, 94, 0); }
    100% { box-shadow: 0 0 0 0 rgba(244, 63, 94, 0); }
  }

  .animate-pulse-ring {
    animation: pulse-ring 2s infinite;
  }
}

@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}

```

---

## `src/main.tsx`

```tsx
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { Provider } from 'react-redux';
import { App } from '@/app/App';
import { ErrorBoundary } from '@/shared/components/ErrorBoundary';
import { StorageBanner } from '@/shared/components/StorageBanner';
import { store } from '@/store';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Provider store={store}>
      <ErrorBoundary>
        <App />
        <StorageBanner />
      </ErrorBoundary>
    </Provider>
  </StrictMode>
);

```

---

## `src/shared/components/AgentPicker.tsx`

```tsx
import { useEffect, useMemo, useRef, useState } from 'react';
import { ChevronDown, Search, X } from 'lucide-react';
import type { Team, User } from '@/domain/types';
import { UserAvatar } from '@/shared/components/UserAvatar';

interface AgentOption {
  agent: User;
  teamName: string;
}

/**
 * Agent selector with BOTH ways to choose:
 *  - open it and pick from the full list (grouped by team), or
 *  - type a name / username / team and pick from the filtered list (mouse or ↑ ↓ Enter).
 */
export function AgentPicker({
  agents, teams, value, onChange, placeholder = 'Search an agent or choose from the list...',
}: {
  agents: User[];
  teams: Team[];
  value: string;
  onChange: (agentId: string) => void;
  placeholder?: string;
}) {
  const selected = agents.find(a => a.id === value);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [active, setActive] = useState(0);
  const rootRef = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  // every agent that belongs to a team, in team order (the same grouping the old drop-down had)
  const options = useMemo<AgentOption[]>(() => {
    const q = query.trim().toLowerCase();
    const all = teams.flatMap(t =>
      agents.filter(a => t.agentIds.includes(a.id)).map(agent => ({ agent, teamName: t.name })));
    return q
      ? all.filter(o => o.agent.name.toLowerCase().includes(q) || o.agent.username.toLowerCase().includes(q) || o.teamName.toLowerCase().includes(q))
      : all;
  }, [agents, teams, query]);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, [open]);

  useEffect(() => { setActive(0); }, [query]);

  useEffect(() => {
    listRef.current?.querySelector<HTMLElement>(`[data-idx="${active}"]`)?.scrollIntoView({ block: 'nearest' });
  }, [active]);

  const choose = (id: string) => {
    onChange(id);
    setOpen(false);
    setQuery('');
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setOpen(true); setActive(a => Math.min(a + 1, options.length - 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(a => Math.max(a - 1, 0)); }
    else if (e.key === 'Enter' && open) { e.preventDefault(); const o = options[active]; if (o) choose(o.agent.id); }
    else if (e.key === 'Escape') { setOpen(false); }
  };

  return (
    <div ref={rootRef} className="relative">
      {selected && !open ? (
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="w-full flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-200 text-sm bg-white text-left hover:border-slate-300"
        >
          <UserAvatar user={selected} size="w-6 h-6" />
          <span className="truncate text-slate-900">{selected.name}</span>
          <span
            role="button"
            aria-label="Clear agent"
            onClick={e => { e.stopPropagation(); onChange(''); }}
            className="ml-auto w-5 h-5 rounded hover:bg-slate-100 flex items-center justify-center shrink-0"
          >
            <X className="w-3.5 h-3.5 text-slate-500" />
          </span>
        </button>
      ) : (
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            type="text"
            value={query}
            autoFocus={open}
            onFocus={() => setOpen(true)}
            onChange={e => { setQuery(e.target.value); setOpen(true); }}
            onKeyDown={onKeyDown}
            placeholder={placeholder}
            className="w-full pl-9 pr-9 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 bg-white"
          />
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
        </div>
      )}

      {open && (
        <div className="absolute left-0 right-0 top-full mt-1 z-30 bg-white rounded-xl border border-slate-200 shadow-lg overflow-hidden">
          <div ref={listRef} className="max-h-60 overflow-y-auto scrollbar-thin py-1">
            {options.length === 0 && (
              <div className="px-4 py-3 text-sm text-slate-500">No agents match “{query}”</div>
            )}
            {options.map((o, i) => (
              <div key={o.agent.id}>
                {(i === 0 || options[i - 1].teamName !== o.teamName) && (
                  <div className="px-4 pt-2 pb-1 text-[11px] font-semibold text-slate-500">{o.teamName}</div>
                )}
                <button
                  type="button"
                  data-idx={i}
                  onMouseEnter={() => setActive(i)}
                  onClick={() => choose(o.agent.id)}
                  className={`w-full flex items-center gap-2 px-4 py-2 text-left text-sm ${i === active ? 'bg-blue-50' : ''} ${o.agent.id === value ? 'font-semibold' : ''}`}
                >
                  <UserAvatar user={o.agent} size="w-6 h-6" />
                  <span className="truncate text-slate-900">{o.agent.name}</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

```

---

## `src/shared/components/ConfirmDialog.tsx`

```tsx
import { AlertTriangle } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { ReactNode } from 'react';

interface ConfirmOptions {
  title: string;
  message: ReactNode;
  confirmLabel?: string;
  /** red for deleting, amber for everything else that changes the workflow */
  tone?: 'danger' | 'warning';
}

export function ConfirmDialog({
  title, message, confirmLabel = 'Confirm', tone = 'warning', onConfirm, onCancel,
}: ConfirmOptions & { onConfirm: () => void; onCancel: () => void }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onCancel(); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onCancel]);

  const danger = tone === 'danger';
  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center" role="dialog" aria-modal="true" aria-label={title}>
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-fade-in" onClick={onCancel} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-sm mx-4 animate-slide-up p-6">
        <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-3 ${danger ? 'bg-rose-100' : 'bg-amber-100'}`}>
          <AlertTriangle className={`w-5 h-5 ${danger ? 'text-rose-600' : 'text-amber-600'}`} />
        </div>
        <h2 className="text-lg font-bold text-slate-900 mb-1">{title}</h2>
        <div className="text-sm text-slate-600 mb-5">{message}</div>
        <div className="flex justify-end gap-2">
          <button onClick={onCancel} autoFocus className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100">Cancel</button>
          <button
            onClick={onConfirm}
            className={`px-4 py-2 rounded-lg text-sm font-medium text-white ${danger ? 'bg-rose-600 hover:bg-rose-700' : 'bg-amber-600 hover:bg-amber-700'}`}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

/**
 * const { ask, dialog } = useConfirm();
 * ask({ title, message, confirmLabel }, () => dispatch(...));   // runs only after the user presses Confirm
 * and render {dialog} once in the component.
 */
export function useConfirm() {
  const [req, setReq] = useState<(ConfirmOptions & { action: () => void }) | null>(null);
  const ask = (opts: ConfirmOptions, action: () => void) => setReq({ ...opts, action });
  const dialog = req ? (
    <ConfirmDialog
      {...req}
      onCancel={() => setReq(null)}
      onConfirm={() => { const run = req.action; setReq(null); run(); }}
    />
  ) : null;
  return { ask, dialog };
}

```

---

## `src/shared/components/ErrorBoundary.tsx`

```tsx
import { AlertTriangle } from 'lucide-react';
import { Component } from 'react';
import type { ErrorInfo, ReactNode } from 'react';

/**
 * Last line of defence: if any screen throws while rendering, show a clear message with a way out
 * instead of a blank white page. The saved data is NOT touched.
 */
export class ErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state = { error: null as Error | null };

  static getDerivedStateFromError(error: Error) { return { error }; }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('Screen crashed:', error, info.componentStack);
  }

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 px-6">
        <div className="w-full max-w-md bg-white rounded-2xl border border-slate-200 shadow-sm p-6 text-center">
          <div className="w-11 h-11 rounded-full bg-rose-100 flex items-center justify-center mx-auto mb-3">
            <AlertTriangle className="w-5 h-5 text-rose-600" />
          </div>
          <h1 className="text-lg font-bold text-slate-900 mb-1">Something went wrong</h1>
          <p className="text-sm text-slate-600 mb-5">
            This screen hit an unexpected error. Your data is safe — nothing was deleted.
          </p>
          <div className="flex justify-center gap-2">
            <button
              onClick={() => this.setState({ error: null })}
              className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100"
            >
              Try again
            </button>
            <button
              onClick={() => window.location.reload()}
              className="px-4 py-2 rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
            >
              Reload
            </button>
          </div>
        </div>
      </div>
    );
  }
}

```

---

## `src/shared/components/LeadPicker.tsx`

```tsx
import { ChevronDown, Search, X } from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import type { Lead } from '@/domain/types';

const MAX_RESULTS = 50;

/**
 * Searchable lead selector (replaces a plain <select> so it stays usable with hundreds of leads).
 * Type company / contact name, lead code, email or phone, then pick with the mouse or ↑ ↓ Enter.
 */
export function LeadPicker({
  leads, value, onChange, placeholder = 'Search by lead name, code or email...',
}: {
  leads: Lead[];
  value: string;
  onChange: (leadId: string) => void;
  placeholder?: string;
}) {
  const selected = leads.find(l => l.id === value);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [active, setActive] = useState(0);
  const rootRef = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  const matches = useMemo(() => {
    const q = query.trim().toLowerCase();
    const all = q
      ? leads.filter(l =>
          l.companyName.toLowerCase().includes(q) ||
          l.contactName.toLowerCase().includes(q) ||
          l.leadCode.toLowerCase().includes(q) ||
          (l.email || '').toLowerCase().includes(q) ||
          (l.phone || '').replace(/\s/g, '').includes(q.replace(/\s/g, '')))
      : leads;
    return { shown: all.slice(0, MAX_RESULTS), total: all.length };
  }, [leads, query]);

  // close on outside click
  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, [open]);

  useEffect(() => { setActive(0); }, [query]);

  // keep the highlighted row visible while using the keyboard
  useEffect(() => {
    listRef.current?.querySelector<HTMLElement>(`[data-idx="${active}"]`)?.scrollIntoView({ block: 'nearest' });
  }, [active]);

  const choose = (id: string) => {
    onChange(id);
    setOpen(false);
    setQuery('');
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setOpen(true); setActive(a => Math.min(a + 1, matches.shown.length - 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(a => Math.max(a - 1, 0)); }
    else if (e.key === 'Enter' && open) { e.preventDefault(); const l = matches.shown[active]; if (l) choose(l.id); }
    else if (e.key === 'Escape') { setOpen(false); }
  };

  const inputClass = 'w-full pl-9 pr-9 py-2.5 rounded-lg border border-slate-300 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 bg-white';

  return (
    <div ref={rootRef} className="relative">
      {selected && !open ? (
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="w-full flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-200 text-sm bg-white text-left hover:border-slate-300"
        >
          <span className="font-mono text-xs bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded shrink-0">{selected.leadCode}</span>
          <span className="truncate text-slate-900">{selected.companyName}</span>
          <span className="truncate text-slate-500 text-xs">{selected.contactName}</span>
          <span
            role="button"
            aria-label="Clear linked lead"
            onClick={e => { e.stopPropagation(); onChange(''); }}
            className="ml-auto w-5 h-5 rounded hover:bg-slate-100 flex items-center justify-center shrink-0"
          >
            <X className="w-3.5 h-3.5 text-slate-500" />
          </span>
        </button>
      ) : (
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            type="text"
            value={query}
            autoFocus={open}
            onFocus={() => setOpen(true)}
            onChange={e => { setQuery(e.target.value); setOpen(true); }}
            onKeyDown={onKeyDown}
            placeholder={placeholder}
            className={inputClass}
          />
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
        </div>
      )}

      {open && (
        <div className="absolute left-0 right-0 top-full mt-1 z-30 bg-white rounded-xl border border-slate-200 shadow-lg overflow-hidden">
          <div ref={listRef} className="max-h-60 overflow-y-auto scrollbar-thin py-1">
            {matches.shown.length === 0 && (
              <div className="px-4 py-3 text-sm text-slate-500">No leads match “{query}”</div>
            )}
            {matches.shown.map((l, i) => (
              <button
                type="button"
                key={l.id}
                data-idx={i}
                onMouseEnter={() => setActive(i)}
                onClick={() => choose(l.id)}
                className={`w-full flex items-center gap-2 px-4 py-2 text-left text-sm ${i === active ? 'bg-blue-50' : ''} ${l.id === value ? 'font-semibold' : ''}`}
              >
                <span className="font-mono text-xs bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded shrink-0">{l.leadCode}</span>
                <span className="truncate text-slate-900">{l.companyName}</span>
                <span className="truncate text-slate-500 text-xs ml-auto">{l.contactName}</span>
              </button>
            ))}
          </div>
          {matches.total > MAX_RESULTS && (
            <div className="px-4 py-2 text-xs text-slate-500 border-t border-slate-100 bg-slate-50">
              Showing {MAX_RESULTS} of {matches.total} — keep typing to narrow it down
            </div>
          )}
        </div>
      )}
    </div>
  );
}

```

---

## `src/shared/components/StorageBanner.tsx`

```tsx
import { AlertTriangle, Download } from 'lucide-react';
import { useEffect, useState } from 'react';
import { PERSIST_FAILED_EVENT, PERSIST_OK_EVENT, store } from '@/store';

/**
 * Shown only when the browser refuses to save (storage full or blocked). Without this the user would keep
 * working while nothing is being saved. Offers a JSON backup so the work can still be rescued.
 */
export function StorageBanner() {
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const bad = () => setFailed(true);
    const ok = () => setFailed(false);
    window.addEventListener(PERSIST_FAILED_EVENT, bad);
    window.addEventListener(PERSIST_OK_EVENT, ok);
    return () => { window.removeEventListener(PERSIST_FAILED_EVENT, bad); window.removeEventListener(PERSIST_OK_EVENT, ok); };
  }, []);

  if (!failed) return null;

  const exportBackup = () => {
    const blob = new Blob([JSON.stringify(store.getState().crm, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `crm-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div role="alert" className="fixed bottom-4 left-1/2 -translate-x-1/2 z-[100] w-[min(92vw,34rem)] bg-rose-600 text-white rounded-xl shadow-2xl px-4 py-3 flex items-center gap-3">
      <AlertTriangle className="w-5 h-5 shrink-0" />
      <p className="text-sm flex-1">Your latest changes could not be saved (browser storage is full or blocked). Download a backup so nothing is lost.</p>
      <button onClick={exportBackup} className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-sm font-medium">
        <Download className="w-4 h-4" /> Backup
      </button>
    </div>
  );
}

```

---

## `src/shared/components/UserAvatar.tsx`

```tsx
import type { User } from '@/domain/types';

export function UserAvatar({ user, size = 'w-9 h-9' }: { user: User; size?: string }) {
  return (
    <div className={`${size} rounded-full flex items-center justify-center text-white text-xs font-semibold shrink-0`} style={{ backgroundColor: user.color }}>
      {user.initials}
    </div>
  );
}

```

---

## `src/shared/lib/dates.ts`

```ts
/** Date helpers (local calendar days, not UTC). */
// ---------------------------------------------------------------------------
// Meetings / templates helpers
// ---------------------------------------------------------------------------
/** Local YYYY-MM-DD (matches what the date input stores in Meeting.date). */
export const localDay = (d: Date | number = Date.now()) => {
  const x = new Date(d);
  return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`;
};

export const startOfDay = (d: Date | number) => { const x = new Date(d); x.setHours(0, 0, 0, 0); return x; };

export const endOfDay = (d: Date | number) => { const x = new Date(d); x.setHours(23, 59, 59, 999); return x; };

/** 15 min / 5h 20m / 2d 5h  -  short, human duration. */
export function formatDuration(ms: number): string {
  const mins = Math.max(1, Math.round(ms / 60000));
  if (mins < 60) return `${mins} min`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) { const m = mins % 60; return m ? `${hours}h ${m}m` : `${hours}h`; }
  const days = Math.floor(hours / 24); const h = hours % 24;
  return h ? `${days}d ${h}h` : `${days}d`;
}

const pad = (n: number) => String(n).padStart(2, '0');

/** Local calendar date as YYYY-MM-DD (not UTC, so the sale lands on the day the user sees). */
export const localDateStr = (d: Date = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

export const currentMonthKey = () => localDateStr().slice(0, 7);

export function shiftMonth(key: string, delta: number): string {
  const [y, m] = key.split('-').map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
}

export function monthLabel(key: string): string {
  const [y, m] = key.split('-').map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
}

```

---

## `src/shared/ui/leadStatusStyles.ts`

```ts
/** Label + colours of every lead status (used by the work queue and My Leads). */

export const LEAD_STATUS_STYLE = {
  new: { label: 'New', color: 'bg-slate-100 text-slate-700', dot: 'bg-slate-400' },
  discovery: { label: 'Discovery', color: 'bg-emerald-100 text-emerald-700', dot: 'bg-emerald-500' },
  lvm: { label: 'LVM', color: 'bg-amber-100 text-amber-700', dot: 'bg-amber-500' },
  nvm: { label: 'NVM', color: 'bg-amber-100 text-amber-700', dot: 'bg-amber-500' },
  no_response: { label: 'No Response', color: 'bg-rose-100 text-rose-700', dot: 'bg-rose-500' },
  arranged_meeting: { label: 'Meeting', color: 'bg-violet-100 text-violet-700', dot: 'bg-violet-500' },
};

```

---

## `src/store/crm/crmSlice.ts`

```ts
import { createSlice } from '@reduxjs/toolkit';
import { loadInitialState } from '@/store/persistence/loadInitialState';
import { sessionReducers } from '@/store/crm/reducers/sessionReducers';
import { touchPointReducers } from '@/store/crm/reducers/touchPointReducers';
import { leadWorkflowReducers } from '@/store/crm/reducers/leadWorkflowReducers';
import { leadPoolReducers } from '@/store/crm/reducers/leadPoolReducers';
import { callLogReducers } from '@/store/crm/reducers/callLogReducers';
import { leadTransferReducers } from '@/store/crm/reducers/leadTransferReducers';
import { teamReducers } from '@/store/crm/reducers/teamReducers';
import { meetingReducers } from '@/store/crm/reducers/meetingReducers';
import { teamUpdateReducers } from '@/store/crm/reducers/teamUpdateReducers';
import { taskReducers } from '@/store/crm/reducers/taskReducers';
import { emailReducers } from '@/store/crm/reducers/emailReducers';
import { salesReducers } from '@/store/crm/reducers/salesReducers';
import { schedulerReducers } from '@/store/crm/reducers/schedulerReducers';
import { notificationReducers } from '@/store/crm/reducers/notificationReducers';

/**
 * The single "crm" slice. It only ASSEMBLES the reducers; the logic of each one lives in
 * store/crm/reducers/<topic>Reducers.ts so every file answers one question.
 */
const slice = createSlice({
  name: 'crm',
  initialState: loadInitialState,
  reducers: {
    ...sessionReducers,
    ...touchPointReducers,
    ...leadWorkflowReducers,
    ...leadPoolReducers,
    ...callLogReducers,
    ...leadTransferReducers,
    ...teamReducers,
    ...meetingReducers,
    ...teamUpdateReducers,
    ...taskReducers,
    ...emailReducers,
    ...salesReducers,
    ...schedulerReducers,
    ...notificationReducers,
  },
});

export const crmActions = slice.actions;
export const {
  setCurrentUser, applyStateFromOtherTab, logCallAndCompleteTouchPoint, completeTouchPoint, skipTouchPoint, restoreSkippedTouchPoint,
  stopLeadWorkflow, resumeLeadWorkflow, removeLeadFromAgentQueue, deleteLeadPermanently,
  addLeadsToPool, deleteLeadsAsAdmin, takeLeadsFromPool, moveAgentToTeam, addCallLogWithoutCompletingTouchPoint, editCallLog, transferLeadToAgent,
  createMeeting, updateMeeting, postTeamUpdate, acknowledgeTeamUpdate, createTask, toggleTaskCompletion,
  sendEmailForLead, sendBulkEmailForLeads, sendStandaloneEmail, recordSale, deleteSale, runScheduledJobs,
  markNotificationRead, markAllNotificationsRead, addNotification, resetToSeedData,
} = slice.actions;
export default slice.reducer;

```

---

## `src/store/crm/helpers/callLogRecording.ts`

```ts
/** Writes a call log + its history row (shared by every action that logs a call). */
import type { CallLog, Lead, TouchPoint } from '@/domain/types';
import { statusFromCalls } from '@/domain/workflow/callClassification';
import { findCurrentUser } from '@/store/crm/helpers/currentUserGuards';
import { createUserHistoryEntry } from '@/store/crm/helpers/leadHistory';
import type { AppState } from '@/store/state/AppState';

/** Writes the call log + history row. Shared by addCallLogWithoutCompletingTouchPoint and logCallAndCompleteTouchPoint so both always record the same things. */
export function recordCallLogOnLead(state: AppState, l: Lead, raw: CallLog): TouchPoint | undefined {
  const tp = l.touchPoints.find(t => t.order === raw.touchPointOrder);
  const actor = findCurrentUser(state);
  const log = { ...raw, agentId: state.currentUserId, agentName: actor?.name || '', touchPointLabel: tp?.label, round: l.round ?? 1 };
  l.callLogs.push(log);
  l.status = statusFromCalls(l);
  l.history.push(createUserHistoryEntry(state, l, 'call_logged', `${log.type.toUpperCase()}: ${log.description}`, tp, { callLogId: log.id, callType: log.type }));
  return tp;
}

```

---

## `src/store/crm/helpers/currentUserGuards.ts`

```ts
/** Who is acting, and who may touch which lead (the UI hides buttons, but the store enforces it too). */
import type { Lead } from '@/domain/types';
import type { AppState } from '@/store/state/AppState';

// ----- who may do what (the UI hides buttons, but the store must enforce it too) -----
export const findCurrentUser = (state: AppState) => state.users.find(u => u.id === state.currentUserId);

/** Workflow actions on a lead (calls, emails, skip, stop...) belong to the agent who owns the lead. */
export const isOwnedByCurrentUser = (state: AppState, lead: Lead) => !!state.currentUserId && lead.agentId === state.currentUserId;

/** Leads that still HOLD their lead id. A removed lead keeps its history but frees the id, so anyone can take it again. */
export const leadsHoldingTheirCode = (state: AppState) => state.leads.filter(l => !l.removedFromQueue);

/** A lead the agent can still work on. */
export const isLeadWorkable = (lead: Lead) => !lead.stopped && !lead.removedFromQueue && !lead.expiredAt;

export const findLeadById = (state: AppState, id: string) => state.leads.find(l => l.id === id);

```

---

## `src/store/crm/helpers/leadHistory.ts`

```ts
/** Builds the rows of a lead's activity history (by a user, or by the system scheduler). */
import type { Lead, LeadHistoryEntry, TouchPoint } from '@/domain/types';
import type { AppState } from '@/store/state/AppState';

// Builds one history row: WHO, WHEN, which ROUND and (optionally) which touch point.
export function createUserHistoryEntry(
  state: AppState, lead: Lead, action: string, detail?: string,
  tp?: Pick<TouchPoint, 'order' | 'label' | 'type'>, meta?: Record<string, unknown>,
): LeadHistoryEntry {
  return {
    id: crypto.randomUUID(),
    action,
    timestamp: new Date().toISOString(),
    userId: state.currentUserId,
    userName: state.users.find(u => u.id === state.currentUserId)?.name || '',
    detail,
    round: lead.round ?? 1,
    agentId: lead.agentId,
    ...(tp ? { touchPointOrder: tp.order, touchPointLabel: tp.label, touchPointType: tp.type } : {}),
    ...(meta ? { meta } : {}),
  };
}

/** History row written by the scheduler (no logged-in user is acting). */
export function createSystemHistoryEntry(
  lead: Lead, action: string, detail?: string,
  tp?: Pick<TouchPoint, 'order' | 'label' | 'type'>, meta?: Record<string, unknown>,
): LeadHistoryEntry {
  return {
    id: crypto.randomUUID(), action, timestamp: new Date().toISOString(),
    userId: 'system', userName: 'System', detail,
    round: lead.round ?? 1, agentId: lead.agentId,
    ...(tp ? { touchPointOrder: tp.order, touchPointLabel: tp.label, touchPointType: tp.type } : {}),
    ...(meta ? { meta } : {}),
  };
}

```

---

## `src/store/crm/helpers/meetingState.ts`

```ts
/** A lead leaves the Meeting section when its meeting is over. */
import type { Lead } from '@/domain/types';
import { highestCallType } from '@/domain/workflow/callClassification';
import { localDay } from '@/shared/lib/dates';
import { createSystemHistoryEntry, createUserHistoryEntry } from '@/store/crm/helpers/leadHistory';
import type { AppState } from '@/store/state/AppState';

/**
 * A lead only stays in the "Meeting" section while it has an arranged meeting that is today or later.
 * When the meeting day is over (or the meeting was completed / cancelled / no-show / rescheduled and there is no
 * other one) the lead goes back to the Discovery queue. Safe to call repeatedly.
 */
export function returnLeadToQueueWhenMeetingEnds(state: AppState, lead: Lead, reason: string, byUser: boolean) {
  if (lead.status !== 'arranged_meeting') return;
  const today = localDay();
  const stillActive = state.meetings.some(m => m.leadId === lead.id && m.status === 'arranged' && m.date >= today);
  if (stillActive) return;
  lead.status = lead.discoveryReached ? 'discovery' : (highestCallType(lead) ?? 'new');
  lead.lastActivityAt = new Date().toISOString();   // the 15-day count starts again from here
  const detail = `${reason} - back in the Discovery queue`;
  lead.history.push(byUser ? createUserHistoryEntry(state, lead, 'meeting_ended', detail) : createSystemHistoryEntry(lead, 'meeting_ended', detail));
}

```

---

## `src/store/crm/helpers/touchPointScheduling.ts`

```ts
/** After any touch point change: move the lead to its next open touch point. */
import type { Lead } from '@/domain/types';
import { isOpenTouchPoint, scheduleNextTouchPoint } from '@/domain/workflow/touchPoints';

/**
 * After any change to touch points: point the lead at the first open touch point.
 * The due date is only re-based when the current step actually changes
 * (so skipping a FUTURE step doesn't resetToSeedData the due date of the current one).
 */
export function pointLeadAtFirstOpenTouchPoint(lead: Lead) {
  const first = lead.touchPoints.find(isOpenTouchPoint);
  if (!first) { lead.currentTouchPoint = -1; return; }
  if (first.order === lead.currentTouchPoint) return;
  const { touchPoints, next } = scheduleNextTouchPoint(lead.touchPoints);
  lead.touchPoints = touchPoints;
  lead.currentTouchPoint = next ? next.order : -1;
}

```

---

## `src/store/crm/reducers/callLogReducers.ts`

```ts
/** Logging and editing calls. */
import type { PayloadAction } from '@reduxjs/toolkit';
import type { CallLog, CallType } from '@/domain/types';
import { statusFromCalls } from '@/domain/workflow/callClassification';
import { isOpenTouchPoint } from '@/domain/workflow/touchPoints';
import { recordCallLogOnLead } from '@/store/crm/helpers/callLogRecording';
import { findLeadById, isLeadWorkable, isOwnedByCurrentUser } from '@/store/crm/helpers/currentUserGuards';
import { createUserHistoryEntry } from '@/store/crm/helpers/leadHistory';
import { pointLeadAtFirstOpenTouchPoint } from '@/store/crm/helpers/touchPointScheduling';
import type { AppState } from '@/store/state/AppState';

export const callLogReducers = {
  addCallLogWithoutCompletingTouchPoint(state: AppState, a: PayloadAction<{ leadId: string; log: CallLog }>) {
    const l = findLeadById(state, a.payload.leadId);
    if (!l || !isOwnedByCurrentUser(state, l) || !isLeadWorkable(l)) return;
    recordCallLogOnLead(state, l, a.payload.log);
  },
  /** Log a call AND complete its touch point in ONE step (so a failure can never leave a log without a completed step). */
  logCallAndCompleteTouchPoint(state: AppState, a: PayloadAction<{ leadId: string; log: CallLog }>) {
    const l = findLeadById(state, a.payload.leadId);
    if (!l || !isOwnedByCurrentUser(state, l) || !isLeadWorkable(l)) return;
    const tp = l.touchPoints.find(t => t.order === a.payload.log.touchPointOrder);
    if (!tp || tp.type !== 'call' || !isOpenTouchPoint(tp)) return;
    recordCallLogOnLead(state, l, a.payload.log);
    tp.status = 'completed';
    tp.completedAt = new Date().toISOString();
    pointLeadAtFirstOpenTouchPoint(l);
    l.history.push(createUserHistoryEntry(state, l, 'mark_complete', `Touch point ${tp.order + 1} completed`, tp));
  },
  editCallLog(state: AppState, a: PayloadAction<{ leadId: string; logId: string; callType: CallType; description: string }>) {
    const l = findLeadById(state, a.payload.leadId); if (!l || !isOwnedByCurrentUser(state, l)) return;
    const cl = l.callLogs.find(c => c.id === a.payload.logId); if (!cl) return;
    const before = `${cl.type.toUpperCase()}: ${cl.description}`;
    cl.type = a.payload.callType;
    cl.description = a.payload.description;
    cl.editedAt = new Date().toISOString();   // the original call time stays untouched (reports use it)
    l.status = statusFromCalls(l);
    l.history.push(createUserHistoryEntry(state, l, 'call_edited', `${before}  →  ${cl.type.toUpperCase()}: ${cl.description}`, undefined, { callLogId: cl.id }));
  },
};

```

---

## `src/store/crm/reducers/emailReducers.ts`

```ts
/** Sending emails (one lead, many leads, or free-form). */
import type { PayloadAction } from '@reduxjs/toolkit';
import { fillEmailTemplate } from '@/domain/email/fillEmailTemplate';
import { isValidEmail } from '@/domain/lead/leadCode';
import type { EmailLog, TouchPoint } from '@/domain/types';
import { isOpenTouchPoint } from '@/domain/workflow/touchPoints';
import { findCurrentUser, findLeadById, isLeadWorkable, isOwnedByCurrentUser } from '@/store/crm/helpers/currentUserGuards';
import { createUserHistoryEntry } from '@/store/crm/helpers/leadHistory';
import { pointLeadAtFirstOpenTouchPoint } from '@/store/crm/helpers/touchPointScheduling';
import type { AppState } from '@/store/state/AppState';

export const emailReducers = {
  sendEmailForLead(state: AppState, a: PayloadAction<{ email: EmailLog; leadId: string; touchPointOrder: number }>) {
    const l = a.payload.leadId ? findLeadById(state, a.payload.leadId) : undefined;
    if (a.payload.leadId && (!l || !isOwnedByCurrentUser(state, l))) return;       // an agent can only email for their own lead
    state.emailLogs.unshift({ ...a.payload.email, sentBy: state.currentUserId || a.payload.email.sentBy });
    if (!l) return;
    const tp = l.touchPoints.find(t => t.order === a.payload.touchPointOrder);
    // Only an open EMAIL touch point is completed; a free email (order -1) leaves the workflow alone.
    if (tp && tp.type === 'email' && isOpenTouchPoint(tp) && isLeadWorkable(l)) {
      tp.status = 'completed';
      tp.completedAt = new Date().toISOString();
      pointLeadAtFirstOpenTouchPoint(l);
    }
    l.history.push(createUserHistoryEntry(state, l, 'email_sent', `Email sent to ${a.payload.email.to}`, tp, { emailLogId: a.payload.email.id, subject: a.payload.email.subject }));
  },
  /**
   * Optional shortcut for agents: send one email to many leads and mark their current EMAIL step complete.
   * Only the lead's CURRENT step is completed (and only if it is an open email step), never later ones.
   * [Name], [Company Name] and [Agent Name] in the subject/body are filled in per lead.
   */
  sendBulkEmailForLeads(state: AppState, a: PayloadAction<{ leadIds: string[]; subject: string; body: string; senderId: string; senderName: string }>) {
    const now = new Date().toISOString();
    const senderName = findCurrentUser(state)?.name ?? a.payload.senderName;

    for (const id of new Set(a.payload.leadIds)) {
      const l = findLeadById(state, id);
      // never "send" to a lead that has no usable email, and never touch someone else's / a stopped lead
      if (!l || !isOwnedByCurrentUser(state, l) || !isLeadWorkable(l) || !isValidEmail(l.email || '')) continue;
      const tp = l.touchPoints.find(t => t.order === l.currentTouchPoint);
      const subject = fillEmailTemplate(a.payload.subject, l, senderName);
      const emailId = crypto.randomUUID();

      state.emailLogs.unshift({
        id: emailId, leadId: id, leadName: l.companyName,
        to: l.email,
        subject, body: fillEmailTemplate(a.payload.body, l, senderName),
        templateType: 'custom',
        sentAt: now, sentBy: state.currentUserId, sentByName: senderName,
      });

      let completed: TouchPoint | undefined;
      if (tp && tp.type === 'email' && isOpenTouchPoint(tp)) {
        tp.status = 'completed';
        tp.completedAt = now;
        completed = tp;
        pointLeadAtFirstOpenTouchPoint(l);
      }
      l.history.push(createUserHistoryEntry(
        state, l, 'bulk_email_sent', `Email sent to ${l.email}`, completed ?? undefined,
        { emailLogId: emailId, subject },
      ));
    }
  },
  sendStandaloneEmail(state: AppState, a: PayloadAction<{ to: string; subject: string; body: string; senderId: string; senderName: string }>) {
    state.emailLogs.unshift({
      id: crypto.randomUUID(), leadId: '', leadName: '', to: a.payload.to,
      subject: a.payload.subject, body: a.payload.body, templateType: 'custom',
      sentAt: new Date().toISOString(), sentBy: a.payload.senderId, sentByName: a.payload.senderName,
    });
  },
};

```

---

## `src/store/crm/reducers/leadPoolReducers.ts`

```ts
/** The shared pool: the Admin adds leads, an agent takes them. */
import type { PayloadAction } from '@reduxjs/toolkit';
import { normalizeLeadCode } from '@/domain/lead/leadCode';
import { dropTakenLeadCodes } from '@/domain/lead/leadImport';
import { isInPool } from '@/domain/lead/leadPool';
import type { Lead, LeadAssignment } from '@/domain/types';
import { findCurrentUser, findLeadById, leadsHoldingTheirCode } from '@/store/crm/helpers/currentUserGuards';
import { createUserHistoryEntry } from '@/store/crm/helpers/leadHistory';
import type { AppState } from '@/store/state/AppState';

export const leadPoolReducers = {
  // Only the Admin creates leads. They go to the shared pool (no agent) and wait until an agent takes them.
  // An id that already exists ANYWHERE (an agent's lead, a pool lead, a removed lead that is back in the pool) is ignored.
  addLeadsToPool(state: AppState, a: PayloadAction<Lead[]>) {
    if (findCurrentUser(state)?.role !== 'admin') return;
    const ok = dropTakenLeadCodes(a.payload, state.leads).map(l => ({
      ...l, agentId: '', touchPoints: [], currentTouchPoint: -1, callLogs: [], status: 'new' as const,
      stopped: false, removedFromQueue: false, removedAt: null, expiredAt: null,
    }));
    if (ok.length) state.leads.unshift(...ok);
  },
  /**
   * The Admin deletes leads for good (from the pool or from an agent). Their arranged meetings are cancelled.
   * A lead with a recorded sale is kept: the sale points at it and the reports would be left dangling.
   */
  deleteLeadsAsAdmin(state: AppState, a: PayloadAction<string[]>) {
    if (findCurrentUser(state)?.role !== 'admin') return;
    const sold = new Set(state.sales.map(s => s.leadId));
    const doomed = new Set(a.payload.filter(id => !sold.has(id)));
    if (!doomed.size) return;
    state.leads = state.leads.filter(l => !doomed.has(l.id));
    state.meetings.forEach(m => {
      if (m.leadId && doomed.has(m.leadId) && m.status === 'arranged') m.status = 'cancelled';
    });
  },
  /**
   * An agent takes leads from the pool. Each lead becomes theirs and its workflow starts in their work queue.
   * A lead the previous agent removed comes back as a new round (the old touch points are archived, nothing is lost).
   * Re-checked here: it must still be in the pool, so two agents can never end up with the same id.
   */
  takeLeadsFromPool(state: AppState, a: PayloadAction<string[]>) {
    const actor = findCurrentUser(state);
    if (!actor || actor.role !== 'agent') return;
    const now = new Date().toISOString();
    const taken = new Set(leadsHoldingTheirCode(state).filter(l => l.agentId).map(l => normalizeLeadCode(l.leadCode)));
    for (const id of new Set(a.payload)) {
      const l = findLeadById(state, id);
      if (!l || !isInPool(l)) continue;
      const key = normalizeLeadCode(l.leadCode);
      if (taken.has(key)) continue;                                   // somebody else already holds this id
      const wf = state.workflows.find(w => w.campaignCode === l.campaignCode);
      if (!wf) continue;                                              // no workflow for its campaign: nothing to start

      const firstTime = !l.agentId;
      const previousAgent = state.users.find(u => u.id === l.agentId);
      if (!firstTime) {
        // a returning lead: freeze the old agent's touch points, then start a new round
        const round = l.round ?? 1;
        const archived: LeadAssignment = {
          round, agentId: l.agentId, agentName: previousAgent?.name || '',
          assignedAt: l.assignedAt, endedAt: l.removedAt ?? now,
          endedBy: l.agentId, endedByName: previousAgent?.name || '',
          touchPoints: JSON.parse(JSON.stringify(l.touchPoints)),
        };
        l.previousAssignments = [...(l.previousAssignments ?? []), archived];
        l.round = round + 1;
      } else {
        l.round = l.round ?? 1;
      }

      l.agentId = actor.id;
      l.assignedAt = now;
      l.touchPoints = wf.touchPoints.map(tp => ({
        order: tp.order, type: tp.type, label: tp.label, dayOffset: tp.dayOffset,
        status: 'pending' as const, completedAt: null,
        dueDate: tp.order === 0 ? now : new Date(Date.now() + tp.dayOffset * 86400000).toISOString(),
      }));
      l.currentTouchPoint = 0;
      l.status = 'new';
      l.stopped = false;
      l.removedFromQueue = false;
      l.removedAt = null;
      l.expiredAt = null;
      l.discoveryReached = false;
      l.lastActivityAt = now;
      l.history.push(createUserHistoryEntry(
        state, l, 'taken_from_pool',
        firstTime ? `Taken from the pool by ${actor.name}` : `Taken again from the pool by ${actor.name} (round ${l.round})`,
      ));
      taken.add(key);
    }
  },
};

```

---

## `src/store/crm/reducers/leadTransferReducers.ts`

```ts
/** Transferring a lead to another agent (starts a new round). */
import type { PayloadAction } from '@reduxjs/toolkit';
import type { LeadAssignment } from '@/domain/types';
import { findCurrentUser, findLeadById } from '@/store/crm/helpers/currentUserGuards';
import { createUserHistoryEntry } from '@/store/crm/helpers/leadHistory';
import type { AppState } from '@/store/state/AppState';

export const leadTransferReducers = {
  transferLeadToAgent(state: AppState, a: PayloadAction<{ leadId: string; newAgentId: string }>) {
    const l = findLeadById(state, a.payload.leadId);
    if (!l || l.removedFromQueue || l.agentId === a.payload.newAgentId) return;   // a removed lead stays archived, it is never brought back
    const actor = findCurrentUser(state);
    const newAgent = state.users.find(u => u.id === a.payload.newAgentId);
    if (!actor || !newAgent || newAgent.role !== 'agent') return;     // a lead can only go to an agent
    // only the Operation Manager, or the Team Leader of the agent who holds the lead, may reassign it
    const allowed = actor.role === 'operation_manager'
      || (actor.role === 'team_leader' && state.teams.some(t => t.leaderId === actor.id && t.agentIds.includes(l.agentId)));
    if (!allowed) return;
    const wf = state.workflows.find(w => w.campaignCode === l.campaignCode);
    const oldAgent = state.users.find(u => u.id === l.agentId);
    const now = new Date().toISOString();
    const round = l.round ?? 1;

    // 1) Freeze the old agent's touch points - they are NEVER deleted.
    const archived: LeadAssignment = {
      round, agentId: l.agentId, agentName: oldAgent?.name || '',
      assignedAt: l.assignedAt, endedAt: now,
      endedBy: state.currentUserId, endedByName: actor?.name || '',
      touchPoints: JSON.parse(JSON.stringify(l.touchPoints)),
    };

    // 2) The new agent starts a fresh copy of the workflow.
    const template = wf ? wf.touchPoints : l.touchPoints;
    const doneCount = l.touchPoints.filter(tp => tp.status === 'completed').length;
    const total = l.touchPoints.length;
    const fromAgentId = l.agentId;
    l.touchPoints = template.map(tp => ({
      order: tp.order, type: tp.type, label: tp.label, dayOffset: tp.dayOffset,
      status: 'pending' as const, completedAt: null,
      dueDate: tp.order === 0 ? now : new Date(Date.now() + tp.dayOffset * 86400000).toISOString(),
    }));
    l.agentId = a.payload.newAgentId;
    l.assignedAt = now;
    l.currentTouchPoint = 0;
    l.status = 'new';
    l.stopped = false;
    l.removedFromQueue = false;
    l.removedAt = null;
    l.round = round + 1;
    l.expiredAt = null;
    l.discoveryReached = false;
    l.lastActivityAt = now;
    l.previousAssignments = [...(l.previousAssignments ?? []), archived];
    l.history.push(createUserHistoryEntry(
      state, l, 'transfer',
      `Transferred from ${oldAgent?.name} to ${newAgent?.name} (round ${round}: ${doneCount}/${total} touch points were completed)`,
      undefined,
      { fromAgentId, toAgentId: a.payload.newAgentId, fromRound: round, toRound: round + 1, completedTouchPoints: doneCount, totalTouchPoints: total },
    ));
  },
};

```

---

## `src/store/crm/reducers/leadWorkflowReducers.ts`

```ts
/** Stopping, resuming, removing and deleting a lead. */
import type { PayloadAction } from '@reduxjs/toolkit';
import { findLeadById, isOwnedByCurrentUser } from '@/store/crm/helpers/currentUserGuards';
import { createUserHistoryEntry } from '@/store/crm/helpers/leadHistory';
import { pointLeadAtFirstOpenTouchPoint } from '@/store/crm/helpers/touchPointScheduling';
import type { AppState } from '@/store/state/AppState';

export const leadWorkflowReducers = {
  stopLeadWorkflow(state: AppState, a: PayloadAction<string>) {
    const l = findLeadById(state, a.payload); if (!l || !isOwnedByCurrentUser(state, l) || l.stopped || l.removedFromQueue) return;
    l.stopped = true;
    l.lastActivityAt = new Date().toISOString();
    l.history.push(createUserHistoryEntry(state, l, 'workflow_stopped'));
  },
  resumeLeadWorkflow(state: AppState, a: PayloadAction<string>) {
    const l = findLeadById(state, a.payload);
    if (!l || !isOwnedByCurrentUser(state, l) || !l.stopped || l.expiredAt || l.removedFromQueue) return;   // an expired lead is brought back only by a transfer
    l.stopped = false;
    l.lastActivityAt = new Date().toISOString();
    pointLeadAtFirstOpenTouchPoint(l);
    l.history.push(createUserHistoryEntry(state, l, 'workflow_resumed'));
  },
  removeLeadFromAgentQueue(state: AppState, a: PayloadAction<string>) {
    const l = findLeadById(state, a.payload); if (!l || !isOwnedByCurrentUser(state, l) || l.removedFromQueue) return;
    l.removedFromQueue = true;
    l.removedAt = new Date().toISOString();
    l.stopped = true;   // it will not continue its steps
    l.history.push(createUserHistoryEntry(state, l, 'removed_from_queue', 'Removed from the agent\'s leads - history kept, the lead is back in the shared pool and its id is free'));
  },
  /** Permanently deletes the lead. Its arranged meetings are cancelled so the calendar has no dangling links. */
  deleteLeadPermanently(state: AppState, a: PayloadAction<string>) {
    const target = findLeadById(state, a.payload);
    if (!target || !isOwnedByCurrentUser(state, target)) return;
    // A recorded sale points at its lead: deleting the lead would leave the sale (and the reports) dangling.
    if (state.sales.some(x => x.leadId === a.payload)) return;
    state.leads = state.leads.filter(l => l.id !== a.payload);
    state.meetings.forEach(m => {
      if (m.leadId === a.payload && m.status === 'arranged') m.status = 'cancelled';
    });
  },
};

```

---

## `src/store/crm/reducers/meetingReducers.ts`

```ts
/** Creating and updating meetings. */
import type { PayloadAction } from '@reduxjs/toolkit';
import type { Meeting } from '@/domain/types';
import { findLeadById } from '@/store/crm/helpers/currentUserGuards';
import { createUserHistoryEntry } from '@/store/crm/helpers/leadHistory';
import { returnLeadToQueueWhenMeetingEnds } from '@/store/crm/helpers/meetingState';
import type { AppState } from '@/store/state/AppState';

export const meetingReducers = {
  createMeeting(state: AppState, a: PayloadAction<Meeting>) {
    state.meetings.push(a.payload);
    const l = a.payload.leadId ? findLeadById(state, a.payload.leadId) : undefined;
    if (l) {
      l.status = 'arranged_meeting';
      l.discoveryReached = true;   // arranging a meeting means the person was reached
      l.history.push(createUserHistoryEntry(state, l, 'meeting_arranged', `${a.payload.date} at ${a.payload.time}`, undefined, { meetingId: a.payload.id }));
    }
  },
  updateMeeting(state: AppState, a: PayloadAction<{ meetingId: string; updates: Partial<Meeting> }>) {
    const m = state.meetings.find(x => x.id === a.payload.meetingId);
    if (!m) return;
    // Only the person who created the meeting can change it. Invited people can see it but not update it.
    if (m.createdBy !== state.currentUserId) return;
    // A meeting with a lead can only be completed together with a description of what happened
    const completingLeadMeeting = a.payload.updates.status === 'completed' && !!m.leadId;
    if (completingLeadMeeting && !(a.payload.updates.outcome ?? m.outcome ?? '').trim()) return;
    Object.assign(m, a.payload.updates);

    const status = a.payload.updates.status;
    const l = m.leadId ? findLeadById(state, m.leadId) : undefined;
    if (l && status && status !== 'arranged') {
      l.history.push(createUserHistoryEntry(state, l, `meeting_${status}`, status === 'completed' && m.outcome ? `${m.date} at ${m.time} - ${m.outcome}` : `${m.date} at ${m.time}`, undefined, { meetingId: m.id }));
      returnLeadToQueueWhenMeetingEnds(state, l, `Meeting ${status.replace('_', ' ')}`, true);
    }
  },
};

```

---

## `src/store/crm/reducers/notificationReducers.ts`

```ts
/** Notifications. */
import type { PayloadAction } from '@reduxjs/toolkit';
import type { Notification } from '@/domain/types';
import type { AppState } from '@/store/state/AppState';

export const notificationReducers = {
  markNotificationRead(state: AppState, a: PayloadAction<string>) {
    const n = state.notifications.find(x => x.id === a.payload);
    if (n) n.read = true;
  },
  markAllNotificationsRead(state: AppState) { state.notifications.forEach(n => { n.read = true; }); },
  addNotification(state: AppState, a: PayloadAction<Notification>) { state.notifications.unshift(a.payload); },
};

```

---

## `src/store/crm/reducers/salesReducers.ts`

```ts
/** Sales recorded by the Quality role. */
import type { PayloadAction } from '@reduxjs/toolkit';
import type { Sale } from '@/domain/types';
import type { AppState } from '@/store/state/AppState';

export const salesReducers = {
  recordSale(state: AppState, a: PayloadAction<Sale>) {
    if (state.users.find(u => u.id === state.currentUserId)?.role !== 'quality') return;
    // A sale must belong to a real lead: the lead (not the company name) is what identifies it
    const lead = state.leads.find(l => l.id === a.payload.leadId);
    if (!lead) return;
    state.sales.unshift({ ...a.payload, leadName: lead.companyName });
  },
  deleteSale(state: AppState, a: PayloadAction<string>) {
    if (state.users.find(u => u.id === state.currentUserId)?.role !== 'quality') return;
    state.sales = state.sales.filter(x => x.id !== a.payload);
  },
};

```

---

## `src/store/crm/reducers/schedulerReducers.ts`

```ts
/** The scheduler tick (runs every 30 seconds while the app is open). */
import { AUTO_EMAIL_ENABLED } from '@/domain/workflow/workflowRules';
import { runAutoEmailJob } from '@/store/crm/scheduler/autoEmailJob';
import { runLeadExpiryJob } from '@/store/crm/scheduler/leadExpiryJob';
import { runMeetingDayEndJob } from '@/store/crm/scheduler/meetingDayEndJob';
import { runMeetingReminderJob } from '@/store/crm/scheduler/meetingReminderJob';
import type { AppState } from '@/store/state/AppState';

export const schedulerReducers = {
  runScheduledJobs(state: AppState) {
    const now = Date.now();
    runMeetingDayEndJob(state);
    runLeadExpiryJob(state, now);
    runMeetingReminderJob(state, now);
    if (AUTO_EMAIL_ENABLED) runAutoEmailJob(state, now);
  },
};

```

---

## `src/store/crm/reducers/sessionReducers.ts`

```ts
/** Who is signed in, applying data saved by another browser tab, and resetting to the demo data. */
import type { PayloadAction } from '@reduxjs/toolkit';
import { createInitialState } from '@/store/seed/createInitialState';
import type { AppState } from '@/store/state/AppState';

export const sessionReducers = {
  setCurrentUser(state: AppState, a: PayloadAction<string>) { state.currentUserId = a.payload; },
  /** Another browser tab saved newer data: take it, but keep THIS tab's logged-in user. */
  applyStateFromOtherTab(state: AppState, a: PayloadAction<AppState>) { return { ...a.payload, currentUserId: state.currentUserId }; },
  resetToSeedData() { return createInitialState(); },
};

```

---

## `src/store/crm/reducers/taskReducers.ts`

```ts
/** Tasks assigned by managers. */
import type { PayloadAction } from '@reduxjs/toolkit';
import type { Task } from '@/domain/types';
import type { AppState } from '@/store/state/AppState';

export const taskReducers = {
  createTask(state: AppState, a: PayloadAction<Task>) { state.tasks.unshift(a.payload); },
  toggleTaskCompletion(state: AppState, a: PayloadAction<{ taskId: string; userId: string }>) {
    const t = state.tasks.find(x => x.id === a.payload.taskId); if (!t) return;
    t.completedBy = t.completedBy.includes(a.payload.userId)
      ? t.completedBy.filter(id => id !== a.payload.userId)
      : [...t.completedBy, a.payload.userId];
  },
};

```

---

## `src/store/crm/reducers/teamReducers.ts`

```ts
/** Moving an agent from one team to another (Operation Manager only). */
import type { PayloadAction } from '@reduxjs/toolkit';
import { findCurrentUser } from '@/store/crm/helpers/currentUserGuards';
import type { AppState } from '@/store/state/AppState';

export const teamReducers = {
  /**
   * The agent changes team (and so Team Leader). ONLY the team membership changes:
   * the agent's leads, call logs, touch points, meetings, emails and sales are not touched, so nothing is lost
   * and the agent simply continues with the same work under the new Team Leader.
   */
  moveAgentToTeam(state: AppState, a: PayloadAction<{ agentId: string; toTeamId: string }>) {
    const actor = findCurrentUser(state);
    if (!actor || actor.role !== 'operation_manager') return;
    const agent = state.users.find(u => u.id === a.payload.agentId && u.role === 'agent');
    const to = state.teams.find(t => t.id === a.payload.toTeamId);
    if (!agent || !to || to.managerId !== actor.id) return;                    // only into a team this manager runs
    const from = state.teams.find(t => t.agentIds.includes(agent.id));
    if (from && from.managerId !== actor.id) return;                           // and only out of a team this manager runs
    if (from?.id === to.id) return;

    state.teams.forEach(t => { t.agentIds = t.agentIds.filter(id => id !== agent.id); });
    to.agentIds.push(agent.id);
    agent.teamId = to.id;

    const now = new Date().toISOString();
    const note = (userId: string, title: string, message: string) =>
      state.notifications.unshift({ id: crypto.randomUUID(), type: 'update', title, message, timestamp: now, read: false, userId });
    note(agent.id, 'You moved to a new team', `You are now in ${to.name}${from ? ` (was ${from.name})` : ''}. Your leads and history stay with you.`);
    note(to.leaderId, 'New agent in your team', `${agent.name} joined ${to.name}${from ? ` from ${from.name}` : ''}.`);
    if (from) note(from.leaderId, 'An agent left your team', `${agent.name} moved from ${from.name} to ${to.name}.`);
  },
};

```

---

## `src/store/crm/reducers/teamUpdateReducers.ts`

```ts
/** Team updates (announcements) and their acknowledgement. */
import type { PayloadAction } from '@reduxjs/toolkit';
import type { TeamUpdate } from '@/domain/types';
import type { AppState } from '@/store/state/AppState';

export const teamUpdateReducers = {
  postTeamUpdate(state: AppState, a: PayloadAction<TeamUpdate>) { state.updates.unshift(a.payload); },
  acknowledgeTeamUpdate(state: AppState, a: PayloadAction<{ updateId: string; userId: string }>) {
    const u = state.updates.find(x => x.id === a.payload.updateId);
    if (u && !u.acknowledgedBy.includes(a.payload.userId)) u.acknowledgedBy.push(a.payload.userId);
  },
};

```

---

## `src/store/crm/reducers/touchPointReducers.ts`

```ts
/** Completing, skipping and restoring a single touch point. */
import type { PayloadAction } from '@reduxjs/toolkit';
import { isOpenTouchPoint } from '@/domain/workflow/touchPoints';
import { findLeadById, isLeadWorkable, isOwnedByCurrentUser } from '@/store/crm/helpers/currentUserGuards';
import { createUserHistoryEntry } from '@/store/crm/helpers/leadHistory';
import { pointLeadAtFirstOpenTouchPoint } from '@/store/crm/helpers/touchPointScheduling';
import type { AppState } from '@/store/state/AppState';

export const touchPointReducers = {
  completeTouchPoint(state: AppState, a: PayloadAction<{ leadId: string; order: number }>) {
    const l = findLeadById(state, a.payload.leadId);
    if (!l || !isOwnedByCurrentUser(state, l) || !isLeadWorkable(l)) return;      // a stopped / expired lead cannot move forward
    const tp = l.touchPoints.find(t => t.order === a.payload.order);
    if (!tp || !isOpenTouchPoint(tp)) return;                      // a double click must not complete a step twice
    tp.status = 'completed';
    tp.completedAt = new Date().toISOString();
    pointLeadAtFirstOpenTouchPoint(l);
    l.history.push(createUserHistoryEntry(state, l, 'mark_complete', `Touch point ${a.payload.order + 1} completed`, tp));
  },
  skipTouchPoint(state: AppState, a: PayloadAction<{ leadId: string; order: number }>) {
    const l = findLeadById(state, a.payload.leadId); if (!l || !isOwnedByCurrentUser(state, l) || l.removedFromQueue) return;
    const tp = l.touchPoints.find(t => t.order === a.payload.order);
    if (!tp || !isOpenTouchPoint(tp)) return;
    tp.status = 'skipped';
    tp.skippedAt = new Date().toISOString();
    pointLeadAtFirstOpenTouchPoint(l);
    l.history.push(createUserHistoryEntry(state, l, 'touchpoint_skipped', `Touch point ${tp.order + 1} (${tp.label}) skipped`, tp));
  },
  restoreSkippedTouchPoint(state: AppState, a: PayloadAction<{ leadId: string; order: number }>) {
    const l = findLeadById(state, a.payload.leadId); if (!l || !isOwnedByCurrentUser(state, l) || l.removedFromQueue) return;
    const tp = l.touchPoints.find(t => t.order === a.payload.order);
    if (!tp || tp.status !== 'skipped') return;
    tp.status = 'pending';
    tp.skippedAt = null;
    pointLeadAtFirstOpenTouchPoint(l);
    l.history.push(createUserHistoryEntry(state, l, 'touchpoint_restored', `Touch point ${tp.order + 1} (${tp.label}) restored`, tp));
  },
};

```

---

## `src/store/crm/scheduler/autoEmailJob.ts`

```ts
/** Job: sends an email touch point automatically when it comes due. */
import { fillEmailTemplate } from '@/domain/email/fillEmailTemplate';
import { effectiveCallType } from '@/domain/workflow/callClassification';
import { isOpenTouchPoint } from '@/domain/workflow/touchPoints';
import { createSystemHistoryEntry } from '@/store/crm/helpers/leadHistory';
import { pointLeadAtFirstOpenTouchPoint } from '@/store/crm/helpers/touchPointScheduling';
import type { AppState } from '@/store/state/AppState';

/**
 * Email touch point came due -> the system sends it. Discovery template if the lead reached Discovery, otherwise
 * the No Response template. A call step is never skipped: if the lead is waiting on a call, nothing is sent.
 * No email address -> nothing is sent and the step stays open. (Sending is simulated: it is logged, not delivered.)
 */
export function runAutoEmailJob(state: AppState, now: number) {
  const nowIso = new Date(now).toISOString();
  for (const l of state.leads) {
    if (l.stopped || l.removedFromQueue || l.expiredAt || !l.email) continue;
    const tp = l.touchPoints.find(t => t.order === l.currentTouchPoint);
    if (!tp || tp.type !== 'email' || !isOpenTouchPoint(tp)) continue;
    if (!tp.dueDate || new Date(tp.dueDate).getTime() > now) continue;

    const key = `auto|${l.id}|${l.round ?? 1}|${tp.order}`;
    if (state.emailLogs.some(e => e.idempotencyKey === key)) continue;

    const type = effectiveCallType(l) === 'discovery' ? 'discovery' : 'no_response';
    const tpl = state.emailTemplates.find(t => t.type === type);
    if (!tpl) continue;
    const agent = state.users.find(u => u.id === l.agentId);
    const agentName = agent?.name ?? '';
    const emailId = crypto.randomUUID();

    state.emailLogs.unshift({
      id: emailId, leadId: l.id, leadName: l.companyName, to: l.email,
      subject: fillEmailTemplate(tpl.subject, l, agentName), body: fillEmailTemplate(tpl.body, l, agentName),
      templateType: type, sentAt: nowIso, sentBy: l.agentId, sentByName: agentName,
      auto: true, idempotencyKey: key,
    });
    tp.status = 'completed';
    tp.completedAt = nowIso;
    pointLeadAtFirstOpenTouchPoint(l);
    l.history.push(createSystemHistoryEntry(l, 'auto_email_sent', `${tpl.name} sent to ${l.email}`, tp, { emailLogId: emailId, templateType: type }));
    state.notifications.unshift({
      id: crypto.randomUUID(), type: 'email', title: 'Email sent automatically',
      message: `${l.companyName}: ${tp.label}`, timestamp: nowIso, read: false, leadId: l.id, userId: l.agentId,
    });
  }
}

```

---

## `src/store/crm/scheduler/leadExpiryJob.ts`

```ts
/** Job: the 15-day rule. */
import { expiryReferenceMs } from '@/domain/workflow/leadExpiry';
import { isOpenTouchPoint } from '@/domain/workflow/touchPoints';
import { LEAD_EXPIRY_DAYS } from '@/domain/workflow/workflowRules';
import { localDay } from '@/shared/lib/dates';
import { createSystemHistoryEntry } from '@/store/crm/helpers/leadHistory';
import type { AppState } from '@/store/state/AppState';

/** 15-day rule: no progress (same touch point or stopped) for 15 calendar days -> out of the queue, TL reassigns. */
export function runLeadExpiryJob(state: AppState, now: number) {
  const today = localDay(now);
  for (const l of state.leads) {
    if (l.expiredAt || l.removedFromQueue) continue;
    if (!l.stopped && !l.touchPoints.some(isOpenTouchPoint)) continue;                    // finished workflow
    if (state.meetings.some(m => m.leadId === l.id && m.status === 'arranged' && m.date >= today)) continue; // paused by a meeting
    if (now - expiryReferenceMs(l) < LEAD_EXPIRY_DAYS * 86400000) continue;
    l.expiredAt = new Date(now).toISOString();
    const agent = state.users.find(u => u.id === l.agentId);
    l.history.push(createSystemHistoryEntry(l, 'expired_15_days', `No progress for ${LEAD_EXPIRY_DAYS} days - removed from ${agent?.name ?? 'the agent'}'s queue, waiting for the Team Leader to reassign`));
  }
}

```

---

## `src/store/crm/scheduler/meetingDayEndJob.ts`

```ts
/** Job: a meeting day ended with no result -> lead goes back to its queue. */
import { returnLeadToQueueWhenMeetingEnds } from '@/store/crm/helpers/meetingState';
import type { AppState } from '@/store/state/AppState';

// ----- scheduler jobs (run every 30 s while the app is open; a real backend would run them as background jobs) -----
export function runMeetingDayEndJob(state: AppState) {
  for (const l of state.leads) {
    if (l.status === 'arranged_meeting') returnLeadToQueueWhenMeetingEnds(state, l, 'Meeting day ended with no result', false);
  }
}

```

---

## `src/store/crm/scheduler/meetingReminderJob.ts`

```ts
/** Job: 15-minute meeting reminders. */
import { meetingStartMs } from '@/domain/meeting/meetingTime';
import { MEETING_REMINDER_MINUTES } from '@/domain/workflow/workflowRules';
import type { AppState } from '@/store/state/AppState';

export function runMeetingReminderJob(state: AppState, now: number) {
  const nowIso = new Date(now).toISOString();
  for (const m of state.meetings) {
    if (m.status !== 'arranged' || m.reminderSentAt) continue;
    const start = meetingStartMs(m);
    if (isNaN(start) || now < start - MEETING_REMINDER_MINUTES * 60000) continue;
    m.reminderSentAt = nowIso;                              // marked first, so it can never be sent twice
    if (now >= start + m.duration * 60000) continue;        // the meeting is already over - no point notifying
    const mins = Math.ceil((start - now) / 60000);
    for (const userId of new Set([...m.participantIds, m.createdBy])) {
      state.notifications.unshift({
        id: crypto.randomUUID(), type: 'meeting',
        title: mins > 0 ? `Meeting in ${mins} minute${mins === 1 ? '' : 's'}` : 'Meeting starting now',
        message: `${m.title} at ${m.time}`,
        timestamp: nowIso, read: false, leadId: m.leadId, meetingId: m.id, userId,
      });
    }
  }
}

```

---

## `src/store/hooks.ts`

```ts
import { useDispatch, useSelector, type TypedUseSelectorHook } from 'react-redux';
import type { RootState, AppDispatch } from '@/store';

export const useAppDispatch: () => AppDispatch = useDispatch;
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;

/** Convenience: the whole CRM state + dispatch (components can migrate to granular selectors over time). */
export function useStore() {
  const state = useAppSelector(s => s.crm);
  const dispatch = useAppDispatch();
  return { state, dispatch };
}

```

---

## `src/store/index.ts`

```ts
import { configureStore } from '@reduxjs/toolkit';
import crmReducer from '@/store/crm/crmSlice';
import { startStatePersistence } from '@/store/persistence/startStatePersistence';

export const store = configureStore({
  reducer: { crm: crmReducer },
});

// localStorage is the "database": see store/persistence/startStatePersistence.ts
startStatePersistence(store);

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
export type { AppState } from '@/store/state/AppState';
export * from '@/store/crm/crmSlice';
export * from '@/store/hooks';
export { PERSIST_FAILED_EVENT, PERSIST_OK_EVENT } from '@/store/persistence/persistenceEvents';

```

---

## `src/store/persistence/loadInitialState.ts`

```ts
/** What the app starts with: the saved state if there is one, otherwise the demo data. */
import { STORAGE_KEY } from '@/store/persistence/storageKey';
import { parseStoredState } from '@/store/persistence/storedStateParser';
import { createInitialState } from '@/store/seed/createInitialState';
import type { AppState } from '@/store/state/AppState';

export function loadInitialState(): AppState {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const state = parseStoredState(stored);
      if (state) return state;
      // the saved text is damaged: keep a copy for recovery instead of silently overwriting it
      try { localStorage.setItem(`${STORAGE_KEY}-corrupt-${Date.now()}`, stored); } catch { /* storage is full */ }
    }
  } catch { /* storage is blocked (private mode) - run in memory */ }
  return createInitialState();
}

```

---

## `src/store/persistence/persistState.ts`

```ts
/** Writes the state to localStorage. */
import { STORAGE_KEY } from '@/store/persistence/storageKey';
import type { AppState } from '@/store/state/AppState';

/** Saves the state. Returns false when the browser refused (storage full / blocked) so the UI can warn the user. */
export const persistState = (state: AppState): boolean => {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); return true; }
  catch (err) { console.error('Could not save the data to localStorage', err); return false; }
};

```

---

## `src/store/persistence/persistenceEvents.ts`

```ts
/** Window events the storage layer fires so the UI can warn the user when the browser refuses to save. */
export const PERSIST_FAILED_EVENT = 'crm:persist-failed';
export const PERSIST_OK_EVENT = 'crm:persist-ok';

```

---

## `src/store/persistence/startStatePersistence.ts`

```ts
import type { Store } from '@reduxjs/toolkit';
import type { AppState } from '@/store/state/AppState';
import { applyStateFromOtherTab } from '@/store/crm/crmSlice';
import { STORAGE_KEY } from '@/store/persistence/storageKey';
import { parseStoredState } from '@/store/persistence/storedStateParser';
import { persistState } from '@/store/persistence/persistState';
import { PERSIST_FAILED_EVENT, PERSIST_OK_EVENT } from '@/store/persistence/persistenceEvents';

/**
 * Keeps localStorage in sync with the store (this is the "database" of the app).
 *  - debounced, so rapid dispatches don't thrash it
 *  - flushed when the tab is hidden / closed, so the last 150 ms of work is never lost
 *  - tells the UI when the browser refuses to save (storage full), instead of failing silently
 *  - another tab's changes are picked up, so two open tabs don't overwrite each other
 */
export function startStatePersistence(store: Store<{ crm: AppState }>) {
  let timer: ReturnType<typeof setTimeout> | undefined;
  let dirty = false;
  let applyingRemote = false;

  function flush() {
    clearTimeout(timer);
    if (!dirty) return;          // nothing new here: never overwrite another tab's newer data with an old copy
    dirty = false;
    const ok = persistState(store.getState().crm);
    window.dispatchEvent(new Event(ok ? PERSIST_OK_EVENT : PERSIST_FAILED_EVENT));
  }

  store.subscribe(() => {
    if (applyingRemote) return;  // this change CAME from storage; writing it back would ping-pong between tabs
    dirty = true;
    clearTimeout(timer);
    timer = setTimeout(flush, 150);
  });

  if (typeof window !== 'undefined') {
    window.addEventListener('pagehide', flush);
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flush(); });

    window.addEventListener('storage', e => {
      if (e.key !== STORAGE_KEY || !e.newValue) return;
      const next = parseStoredState(e.newValue);
      if (!next) return;
      clearTimeout(timer);
      dirty = false;
      applyingRemote = true;
      try { store.dispatch(applyStateFromOtherTab(next)); } finally { applyingRemote = false; }
    });
  }
}

```

---

## `src/store/persistence/storageKey.ts`

```ts
/** The localStorage key the whole state is saved under. */
export const STORAGE_KEY = 'sales-mgmt-state-v4';

```

---

## `src/store/persistence/storedStateParser.ts`

```ts
/** Reads a saved state defensively and upgrades data saved by older versions. */
import { migrateSale } from '@/domain/sales/saleMigration';
import type { Lead, Sale } from '@/domain/types';
import { createInitialState } from '@/store/seed/createInitialState';
import type { AppState } from '@/store/state/AppState';

const ARRAY_KEYS = [
  'users', 'teams', 'workflows', 'leads', 'meetings', 'updates', 'tasks',
  'emailTemplates', 'emailLogs', 'notifications', 'sales',
] as const;

/**
 * Reads a saved state defensively. Returns null when the text is not a usable state (so the caller falls back to
 * a fresh one instead of crashing). Missing lists are filled from the defaults, and old data is upgraded.
 */
export function parseStoredState(raw: string): AppState | null {
  try {
    const parsed = JSON.parse(raw) as Partial<AppState> | null;
    if (!parsed || typeof parsed !== 'object' || !Array.isArray(parsed.leads) || !Array.isArray(parsed.users)) return null;
    const fresh = createInitialState();
    const state = { ...fresh, ...parsed } as AppState;
    const bag = state as unknown as Record<string, unknown>;
    for (const k of ARRAY_KEYS) if (!Array.isArray(bag[k])) bag[k] = fresh[k];
    if (typeof state.currentUserId !== 'string') state.currentUserId = '';

    // a lead missing one of its lists would crash every screen that reads it
    state.leads = state.leads.map(l => ({
      ...l,
      touchPoints: l.touchPoints ?? [],
      callLogs: l.callLogs ?? [],
      history: l.history ?? [],
    }));
    // Older sales had an optional leadId: link them by company name when possible (leadId is required now)
    state.sales = state.sales.map((x: Sale) =>
      x.leadId ? x : { ...x, leadId: state.leads.find((l: Lead) => l.companyName === x.leadName)?.id ?? '' });
    // Older sales had other sale types and a "what the customer got" text: convert them
    state.sales = state.sales.map(migrateSale);
    // Older saved data: add the Quality user so nothing breaks after an upgrade.
    if (!state.users.some(u => u.role === 'quality')) state.users.push(...fresh.users.filter(u => u.role === 'quality'));
    // same for the Admin (the only role that creates leads)
    if (!state.users.some(u => u.role === 'admin')) state.users.unshift(...fresh.users.filter(u => u.role === 'admin'));
    return state;
  } catch {
    return null;
  }
}

```

---

## `src/store/seed/createInitialState.ts`

```ts
import type { AppState } from '@/store/state/AppState';
import { createSeedUsers } from '@/store/seed/seedUsers';
import { createSeedTeams } from '@/store/seed/seedTeams';
import { createSeedWorkflows } from '@/store/seed/seedWorkflows';
import { createSeedLeads } from '@/store/seed/seedLeads';
import { createSeedEmailTemplates } from '@/store/seed/seedEmailTemplates';

/** The demo data the app starts with when nothing is saved yet (nobody signed in, all other lists empty). */
export function createInitialState(): AppState {
  const users = createSeedUsers();
  const workflows = createSeedWorkflows();
  const leads = createSeedLeads(users, workflows);

  return {
    currentUserId: '',
    users, teams: createSeedTeams(), workflows, leads,
    meetings: [], updates: [], tasks: [],
    emailTemplates: createSeedEmailTemplates(),
    emailLogs: [], notifications: [], sales: [],
  };
}

```

---

## `src/store/seed/seedEmailTemplates.ts`

```ts
import type { EmailTemplate } from '@/domain/types';

/** The two email templates the system uses (Discovery / No Response). */
export function createSeedEmailTemplates(): EmailTemplate[] {
  return [
    { id: 'et-1', name: 'Discovery Follow-up', type: 'discovery', subject: 'Following up on our conversation', body: 'Dear [Name],\n\nThank you for your interest in our services. Following up on our recent conversation, I have attached additional details about our activation plan.\n\nBest regards,\n[Agent Name]' },
    { id: 'et-2', name: 'No Response Follow-up', type: 'no_response', subject: 'Reaching out - [Company Name]', body: 'Dear [Name],\n\nI hope this email finds you well. I tried reaching you recently regarding our services. I would love to connect at your convenience.\n\nBest regards,\n[Agent Name]' },
  ];
}

```

---

## `src/store/seed/seedLeads.ts`

```ts
import type { Lead, User, Workflow } from '@/domain/types';

/**
 * Demo leads: a few already taken by every agent at different workflow stages, plus 40 waiting in the shared pool.
 */
export function createSeedLeads(users: User[], workflows: Workflow[]): Lead[] {
  const today = new Date();
  const day = (offset: number) => {
    const d = new Date(today);
    d.setDate(d.getDate() + offset);
    return d.toISOString();
  };

  function makeTouchPoints(wf: Workflow, completed: number) {
    return wf.touchPoints.map(tp => {
      if (tp.order < completed) {
        return { ...tp, status: 'completed' as const, completedAt: day(-5 + tp.order), dueDate: day(-5 + tp.order) };
      }
      const dueOffset = completed === 0 ? 0 : tp.dayOffset - wf.touchPoints[completed - 1].dayOffset;
      const due = day(dueOffset);
      return { ...tp, status: new Date(due) < today ? 'overdue' as const : 'pending' as const, completedAt: null, dueDate: due };
    });
  }

  // ---- demo data (old sample data removed) ----
  const COMPANIES = [
    'Red Sea Shipping', 'Oasis Farms', 'Memphis Textiles', 'Nubian Dairy', 'Delta Steel Works', 'Cairo Print House',
    'Pharaoh Foods', 'Aswan Ceramics', 'Sinai Mining', 'Giza Plastics', 'Nile Pharma', 'Alex Marine Services',
    'Luxor Tours', 'Suez Logistics', 'Tanta Cotton Mills', 'Mansoura Electronics', 'Hurghada Diving Co', 'Fayoum Olive Oil',
    'Siwa Dates', 'Port Said Trading', 'Ismailia Cement', 'Sharm Resorts Supply', 'Zamalek Design Studio', 'Maadi Software House',
    'Heliopolis Dental Group', 'Nasr City Auto Parts', 'October Furniture', 'Obour Packaging', 'Shorouk Real Estate', 'Rehab Catering',
    'Damietta Furniture', 'Minya Sugar', 'Assiut Cables', 'Sohag Textiles', 'Qena Pottery', 'Beni Suef Cement',
    'Kafr El Sheikh Rice', 'Beheira Poultry', 'Sadat Industrial Group', 'Borg El Arab Steel',
  ];
  const CONTACTS = ['Karim Nabil', 'Dina Fathy', 'Adel Samir', 'Salma Reda', 'Hossam Aly', 'Mariam Zaki', 'Tarek Fawzy', 'Heba Lotfy', 'Wael Saad', 'Nada Emad'];
  const mkLead = (i: number): Omit<Lead, 'agentId' | 'touchPoints' | 'currentTouchPoint' | 'callLogs' | 'history' | 'assignedAt'> => ({
    id: `l-${i + 1}`,
    leadCode: `LD${String(i + 1).padStart(3, '0')}`,
    campaignCode: i % 2 === 0 ? 'ACT-001' : 'RET-002',
    companyName: COMPANIES[i % COMPANIES.length],
    contactName: CONTACTS[i % CONTACTS.length],
    phone: `+20 1${(i % 3) } ${String(100 + i).padStart(3, '0')} ${String(1000 + i * 37).slice(-4)}`,
    email: `contact${i + 1}@${COMPANIES[i % COMPANIES.length].toLowerCase().replace(/[^a-z]/g, '')}.com`,
    status: 'new', stopped: false, removedFromQueue: false, removedAt: null,
  });

  // A few leads already taken by every agent, at different stages of the workflow
  const agentIds = users.filter(u => u.role === 'agent').map(u => u);
  const STAGES: { done: number; call?: { type: 'nvm' | 'lvm' | 'discovery'; text: string } }[] = [
    { done: 0 },
    { done: 1, call: { type: 'lvm', text: 'Left a voicemail, asked for a call back.' } },
    { done: 2, call: { type: 'discovery', text: 'Interested, asked for more details.' } },
  ];
  const leads: Lead[] = [];
  let n = 0;
  agentIds.forEach(agent => {
    STAGES.forEach((stage, k) => {
      const base = mkLead(n++);
      const wf = workflows.find(w => w.campaignCode === base.campaignCode)!;
      const assigned = day(-(k + 2));
      const tps = makeTouchPoints(wf, stage.done);
      leads.push({
        ...base, agentId: agent.id, assignedAt: assigned,
        status: stage.call ? stage.call.type : 'new',
        touchPoints: tps,
        currentTouchPoint: tps.find(t => t.status === 'pending' || t.status === 'overdue')?.order ?? -1,
        callLogs: stage.call ? [{
          id: `cl-${n}`, type: stage.call.type, description: stage.call.text, timestamp: day(-(k + 1)),
          touchPointOrder: 0, agentId: agent.id, agentName: agent.name, touchPointLabel: wf.touchPoints[0].label, round: 1,
        }] : [],
        history: [{ id: `h-${n}`, action: 'taken_from_pool', timestamp: assigned, userId: agent.id, userName: agent.name, detail: `Taken from the pool by ${agent.name}`, round: 1, agentId: agent.id }],
        discoveryReached: stage.call?.type === 'discovery',
        lastActivityAt: assigned,
      });
    });
  });

  // The shared pool: created by the Admin, nobody owns them yet
  for (let i = 0; i < 40; i++) {
    const base = mkLead(n++);
    leads.push({
      ...base, agentId: '', assignedAt: day(-1), touchPoints: [], currentTouchPoint: -1, callLogs: [],
      history: [{ id: `h-pool-${i + 1}`, action: 'created', timestamp: day(-1), userId: 'u-admin', userName: 'System Admin', detail: 'Lead created by the Admin (in the pool)' }],
    });
  }
  return leads;
}

```

---

## `src/store/seed/seedTeams.ts`

```ts
import type { Team } from '@/domain/types';

/** The demo teams (each has one leader, two agents and the same operation manager). */
export function createSeedTeams(): Team[] {
  return [
    { id: 't-1', name: 'Team Alpha', leaderId: 'u-tl1', agentIds: ['u-a1', 'u-a2'], managerId: 'u-om' },
    { id: 't-2', name: 'Team Beta', leaderId: 'u-tl2', agentIds: ['u-a3', 'u-a4'], managerId: 'u-om' },
  ];
}

```

---

## `src/store/seed/seedUsers.ts`

```ts
import type { User } from '@/domain/types';

/** The demo people: one of each role plus four agents in two teams. */
export function createSeedUsers(): User[] {
  return [
    { id: 'u-admin', username: 'admin', name: 'System Admin', email: 'admin@company.com', role: 'admin', initials: 'SA', color: '#475569', dailyCallTarget: 0 },
    { id: 'u-om', username: 'ahmed.om', name: 'Ahmed Hassan', email: 'om@company.com', role: 'operation_manager', initials: 'AH', color: '#1e40af', dailyCallTarget: 0 },
    { id: 'u-tl1', username: 'sara.tl', name: 'Sara Mahmoud', email: 'sara@company.com', role: 'team_leader', teamId: 't-1', initials: 'SM', color: '#0d9488', dailyCallTarget: 0 },
    { id: 'u-tl2', username: 'omar.tl', name: 'Omar Khaled', email: 'omar@company.com', role: 'team_leader', teamId: 't-2', initials: 'OK', color: '#0891b2', dailyCallTarget: 0 },
    { id: 'u-a1', username: 'mona.agent', name: 'Mona Ali', email: 'mona@company.com', role: 'agent', teamId: 't-1', initials: 'MA', color: '#e11d48', dailyCallTarget: 90 },
    { id: 'u-a2', username: 'khaled.agent', name: 'Khaled Mostafa', email: 'khaled@company.com', role: 'agent', teamId: 't-1', initials: 'KM', color: '#ea580c', dailyCallTarget: 90 },
    { id: 'u-a3', username: 'nour.agent', name: 'Nour Ibrahim', email: 'nour@company.com', role: 'agent', teamId: 't-2', initials: 'NI', color: '#0284c7', dailyCallTarget: 90 },
    { id: 'u-a4', username: 'yousef.agent', name: 'Yousef Adel', email: 'yousef@company.com', role: 'agent', teamId: 't-2', initials: 'YA', color: '#16a34a', dailyCallTarget: 90 },
    { id: 'u-q1', username: 'hana.quality', name: 'Hana Samy', email: 'hana@company.com', role: 'quality', initials: 'HS', color: '#7c3aed', dailyCallTarget: 0 },
  ];
}

```

---

## `src/store/seed/seedWorkflows.ts`

```ts
import type { Workflow } from '@/domain/types';

/** One workflow per campaign: the ordered touch point TEMPLATE every new lead of that campaign gets. */
export function createSeedWorkflows(): Workflow[] {
  return [
    {
      id: 'w-1', campaignCode: 'ACT-001', name: 'Activation Campaign',
      touchPoints: [
        { order: 0, type: 'call', label: 'Initial Call', dayOffset: 0 },
        { order: 1, type: 'email', label: 'Follow-up Email', dayOffset: 1 },
        { order: 2, type: 'call', label: 'Second Call', dayOffset: 2 },
        { order: 3, type: 'email', label: 'Second Email', dayOffset: 4 },
        { order: 4, type: 'call', label: 'Final Call', dayOffset: 5 },
        { order: 5, type: 'email', label: 'Final Email', dayOffset: 7 },
      ],
    },
    {
      id: 'w-2', campaignCode: 'RET-002', name: 'Retention Campaign',
      touchPoints: [
        { order: 0, type: 'call', label: 'Outreach Call', dayOffset: 0 },
        { order: 1, type: 'email', label: 'Welcome Email', dayOffset: 1 },
        { order: 2, type: 'call', label: 'Check-in Call', dayOffset: 3 },
        { order: 3, type: 'email', label: 'Offer Email', dayOffset: 5 },
      ],
    },
  ];
}

```

---

## `src/store/state/AppState.ts`

```ts
/** The ONE object that holds all the data of the app (this is what is saved in localStorage). */
import type { EmailLog, EmailTemplate, Lead, Meeting, Notification, Sale, Task, Team, TeamUpdate, User, Workflow } from '@/domain/types';

export interface AppState {
  currentUserId: string;
  users: User[];
  teams: Team[];
  workflows: Workflow[];
  leads: Lead[];
  meetings: Meeting[];
  updates: TeamUpdate[];
  tasks: Task[];
  emailTemplates: EmailTemplate[];
  emailLogs: EmailLog[];
  notifications: Notification[];
  sales: Sale[];
}

```

---

## `src/vite-env.d.ts`

```ts
/// <reference types="vite/client" />

```

